"""Is there usable signal in the residual *sequence* that the model ignores?

The detector computes nine temporal statistics, all of them on the raw
observation, and a spatial residual at a single instant. It never forms
the residual's trajectory across the window. A stealthy drift is exactly
the case where each instant's residual is small but their signs agree, so
if that hypothesis is right the information is present and unused.

This measures it without touching the model. The trained detector already
emits a prediction for the last step of any window, so running it over
every window in a scenario yields a per-timestep residual series for free.
From that series we build the statistic the model lacks -- a standardised
running sum, i.e. the CUSUM statistic -- and ask how well it separates
attacked from clean sensors, family by family, against the model's own
score on the same sensors.

If the running sum beats the model on stealthy, the gap is real and an
architecture that tests the residual sequence has something to gain. If it
does not, the hypothesis is wrong and we drop it before writing any of it.

    python3 scripts/measure_residual_sequence.py --data_dir data/ep_hard_modena
"""
from __future__ import annotations

import argparse
import json
import pickle
import sys
from pathlib import Path

import numpy as np
import torch
from sklearn.metrics import roc_auc_score

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))

from wdn.corruption import ID_TO_ATTACK_TYPE
from wdn.models.temporal_moe import TemporalMixtureOfExpertsGNN
from eval_workshop_routing import load_split, to_device, _sigmoid


def find_checkpoint(data_dir: str) -> Path:
    """Newest full-model run on this dataset."""
    best = None
    for d in sorted((ROOT / "runs" / "temporal_moe").glob("2026*")):
        ap = d / "args.json"
        if not (ap.exists() and (d / "best_model.pt").exists()):
            continue
        a = json.load(open(ap))
        if a.get("data_dir") != data_dir or a.get("window_size") != 6:
            continue
        if a.get("no_topology") or a.get("num_experts", 0) <= 1:
            continue
        if a.get("norm_mode") != "per_node":
            continue
        best = d
    if best is None:
        raise SystemExit(f"no full-model checkpoint for {data_dir}")
    return best


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data_dir", default="data/ep_hard_modena")
    args = ap.parse_args()

    run = find_checkpoint(args.data_dir)
    cfg = json.load(open(run / "args.json"))
    print(f"  checkpoint: {run.name}")

    dev = torch.device("cpu")
    loaders, graph, class_names = load_split(
        ROOT / args.data_dir, 6, 8, "per_node")[:3]
    test = loaders[2]

    model = TemporalMixtureOfExpertsGNN(
        node_in_dim=7, edge_in_dim=8, hidden_dim=cfg["hidden_dim"],
        num_experts=cfg["num_experts"], router_hidden_dim=cfg["router_hidden_dim"],
        num_layers=2, num_temporal_layers=1, window_size=6,
        gnn_type=cfg["gnn_type"], use_pattern_features=True).to(dev)
    model.load_state_dict(torch.load(run / "best_model.pt", map_location=dev))
    model.eval()

    # Collect, per window: the model's anomaly score, the standardised
    # residual at the decision step, the attack label and the family.
    score, resid, lab, fam = [], [], [], []
    with torch.no_grad():
        for b in test:
            b = to_device(b, dev)
            out = model(
                x_seq=b["x_seq"], edge_index=b["edge_index"],
                edge_attr=b["edge_attr"], is_original_edge=b["is_original_edge"],
                batch_size=b["batch_size"], num_nodes_per_graph=b["num_nodes"],
                pressure_obs=b["pressure_obs"], flow_obs=b["flow_obs"],
                pressure_mask=b["pressure_mask"], flow_mask=b["flow_mask"])
            m = b["pressure_mask"].bool()
            r = (b["pressure_obs"] - out["pressure_pred"])[m]
            score.append(_sigmoid(out["pressure_anomaly_logits"][m].cpu().numpy()))
            resid.append(r.cpu().numpy())
            lab.append(b["pressure_anomaly"][m].cpu().numpy())
            n = b["num_nodes"]
            f = b["attack_report"].repeat_interleave(n)[m.cpu()]
            fam.append(f.cpu().numpy())
    score = np.concatenate(score); resid = np.concatenate(resid)
    lab = np.concatenate(lab).astype(int); fam = np.concatenate(fam).astype(int)

    # Standardise the residual on clean sensors only, so the scale is the
    # null's and not the attacks'.
    clean = lab == 0
    mu, sd = resid[clean].mean(), resid[clean].std()
    z = (resid - mu) / (sd + 1e-9)
    print(f"  clean residual: mean {mu:+.4f}  sd {sd:.4f}   "
          f"|z|>3 on clean: {100*(np.abs(z[clean])>3).mean():.2f}%")

    print(f"\n  {'family':11s}{'n':>7}{'model AUROC':>13}{'|z| AUROC':>11}"
          f"{'signed z':>10}")
    names = {i: ID_TO_ATTACK_TYPE[i] for i in ID_TO_ATTACK_TYPE}
    for k in sorted(set(fam)):
        if k == 0:
            continue
        sel = clean | (fam == k)
        y = lab[sel]
        if y.sum() < 20 or (1 - y).sum() < 20:
            continue
        a_model = roc_auc_score(y, score[sel])
        a_absz = roc_auc_score(y, np.abs(z[sel]))
        a_sgnz = roc_auc_score(y, z[sel])
        print(f"  {names.get(k,k):11s}{int(y.sum()):>7}{a_model:>13.3f}"
              f"{a_absz:>11.3f}{a_sgnz:>10.3f}")

    print("\n  signed z separates when the attack pushes one way; |z| when it")
    print("  pushes either way. A signed value far from 0.5 on stealthy is the")
    print("  drift the model cannot see.")


if __name__ == "__main__":
    main()
