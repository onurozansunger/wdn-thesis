#!/usr/bin/env bash
# The near-threshold regime on L-Town, to test whether the regime-dependent
# ablation verdict is a property of the regime or a quirk of Modena.
#
# data/hard_ltown is calibrated to sit at the same point on the regime axis
# as data/hard_modena -- see configs/generate_hard_ltown.yaml, and verify
# with scripts/measure_attack_sigma.py before trusting any comparison.
#
# Same four configurations as the regime table, ten seeds each.
set -u
ROOT="/Users/ozanbabac5/wdn_thesis"; cd "$ROOT"; export PYTHONPATH=src
LOG="/tmp/wdn_ltown"; mkdir -p "$LOG"
B="--data_dir data/hard_ltown --gnn_type GraphSAGE --hidden_dim 64 \
   --router_hidden_dim 24 --epochs 60 --batch_size 8 --lr 0.001 --norm_mode per_node"
for s in 1 2 3 4 5 6 7 8 9 10; do
  for cfg in final notopo notemporal nomixture; do
    tag="${cfg}_s${s}"; [ -f "$LOG/$tag.done" ] && continue
    case $cfg in
      final)      X="--window_size 6" ;;
      notopo)     X="--window_size 6 --no_topology" ;;
      notemporal) X="--window_size 1" ;;
      nomixture)  X="--window_size 6 --num_experts 1" ;;
    esac
    echo "[ltown] $(date +%H:%M:%S) $tag"
    PYTHONUNBUFFERED=1 python3 -u -m wdn.train_temporal_moe $B $X --seed $s \
        > "$LOG/$tag.log" 2>&1 && touch "$LOG/$tag.done"
  done
  echo "[ltown] --- seed $s complete $(date +%H:%M:%S) ---"
done
echo "[ltown] ALL DONE $(date +%H:%M:%S)"
