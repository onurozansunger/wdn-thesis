#!/usr/bin/env bash
# Everything downstream of training: routing study, significance tests,
# cascade diagnosis, baselines, unseen-attack generalisation, the traced
# alarm figure, then tables/macros and the compiled paper.
#
# Safe to re-run at any point -- each step works with whatever seeds have
# finished, so it can be used to preview partial results.
set -u
ROOT="/Users/ozanbabac5/wdn_thesis"; cd "$ROOT"
export PYTHONPATH=src
step () { echo; echo "=== $* ==="; }

step "routing study (Modena)"
python3 scripts/eval_workshop_routing.py --data_dir data/v2_modena \
    --out runs/temporal_moe/workshop_routing_v2.json 2>&1 | tail -7

step "paired significance tests"
python3 scripts/paired_tests.py runs/temporal_moe/workshop_routing_v2.json \
    2>&1 | tail -8

step "cascade diagnosis (margin sweep + router degradation)"
python3 scripts/eval_cascade_diagnosis.py --data_dir data/v2_modena \
    --out runs/temporal_moe/cascade_diagnosis_v2.json 2>&1 | tail -18

step "learning-free baselines"
for d in v2_modena v2_ltown; do
    [ -d "data/$d" ] && python3 scripts/eval_baselines_heuristic.py \
        --data_dir "data/$d" 2>&1 | tail -6
done

step "unseen-attack generalisation"
for d in v2_modena v2_ltown; do
    [ -d "data/$d" ] && python3 scripts/eval_unseen_attacks.py \
        --data_dir "data/$d" 2>&1 | tail -6
done

step "traced-alarm figure"
python3 scripts/make_interpretability_figure.py --data_dir data/v2_modena \
    --target stealthy 2>&1 | tail -12

step "tables, figures, macros"
python3 scripts/build_v2_results.py 2>&1 | tail -14

step "compile"
( cd thesis/workshop \
  && latexmk -pdf -interaction=nonstopmode main.tex >/dev/null 2>&1 \
  && latexmk -pdf -interaction=nonstopmode main.tex >/dev/null 2>&1
  echo "pages: $(pdfinfo main.pdf | awk '/Pages/{print $2}')"
  echo "unresolved '??': $(pdftotext main.pdf - 2>/dev/null | grep -c '??')" )

echo; echo "[analysis] DONE $(date +%H:%M:%S)"
