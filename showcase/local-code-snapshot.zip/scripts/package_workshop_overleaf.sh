#!/usr/bin/env bash
# Package thesis/workshop/ as an Overleaf-ready zip.
#
# Overleaf's "New Project -> Upload Project" expects a zip whose *root*
# contains main.tex, so we zip the contents of the directory rather than
# the directory itself. Build artifacts and the compiled PDF are left out;
# Overleaf rebuilds them.
#
#   bash scripts/package_workshop_overleaf.sh
#   -> thesis/workshop_overleaf.zip
set -eu
ROOT="/Users/ozanbabac5/wdn_thesis"
SRC="$ROOT/thesis/workshop"
OUT="$ROOT/thesis/workshop_overleaf.zip"

# Refresh figures, tables and the number macros from the current runs.
python3 "$ROOT/scripts/build_v2_results.py" >/dev/null

rm -f "$OUT"
cd "$SRC"
zip -q -r "$OUT" \
    main.tex architecture.tex README.md tables figures \
    -x '*.aux' '*.log' '*.out' '*.fls' '*.fdb_latexmk' '*.synctex.gz' \
       '*.DS_Store' '*.png'

echo "wrote $OUT"
unzip -l "$OUT" | tail -n +4 | head -20
