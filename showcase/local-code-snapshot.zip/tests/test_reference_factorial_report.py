"""Small synthetic checks for paired aggregation and complete-result integrity."""
from __future__ import annotations

from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path

import numpy as np
import pytest


@pytest.fixture(scope="module")
def reporting():
    path = Path(__file__).resolve().parents[1] / "thesis_v2/experiments/reference_factorial/report.py"
    spec = importlib.util.spec_from_file_location("reference_factorial_report_tested", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def design(r):
    return {"study": "synthetic test only", "networks": list(r.NETWORKS), "model_seeds": list(r.SEEDS),
            "conditions": dict.fromkeys(r.CONDITIONS, {}),
            "data": {"evaluation_sources": {"modena": list(range(101, 107)), "ltown": list(range(201, 207))}},
            "calibration": {"primary": {"objective": "pooled", "clean_fpr_cap": .0005},
                            "secondary": [{"objective": o, "clean_fpr_cap": c} for c, o in r.POLICIES
                                          if (c, o) != (.0005, "pooled")]},
            "metrics": {"contrasts": {"interaction": "M11-M10-M01+M00"}}, "limits": ["synthetic fixture"]}


def cells(r):
    out = []
    d = design(r)
    for condition, base in {"e0r0": .3, "e0r1": .4, "e1r0": .45, "e1r1": .6}.items():
        for network in r.NETWORKS:
            for j, source in enumerate(d["data"]["evaluation_sources"][network]):
                for k, seed in enumerate(r.SEEDS):
                    value = base + .01 * j + .001 * k
                    if condition == "e1r1":
                        value += .001 * j + .002 * k
                    for cap, objective in r.POLICIES:
                        out.append({"condition": condition, "network": network, "model_seed": seed,
                                    "source_seed": source, "cap": cap, "objective": objective,
                                    "metrics": {m: value for m in r.METRIC_NAMES}})
    return out


def test_pair_within_seed_then_average_sources_and_describe_spread(reporting):
    r = reporting
    groups, effects, sources, source_effects = r.aggregate(cells(r), design(r))
    assert (len(groups), len(effects), len(sources), len(source_effects)) == (32, 56, 192, 336)
    effect = next(v for v in effects if v["network"] == "modena" and v["primary"] and v["effect"] == "interaction")
    assert effect["mean"]["pooled_f1"] == pytest.approx(.0545)
    assert [p["mean"]["pooled_f1"] for p in effect["per_source"]] == pytest.approx([.052 + .001 * j for j in range(6)])
    assert effect["source_sd"]["pooled_f1"] == pytest.approx(np.std(np.arange(6) * .001, ddof=1))
    assert effect["paired_cells"] == 18 and effect["sources"] == 6


def test_mean_worst_family_is_not_minimum_of_family_means(reporting):
    r = reporting
    values = cells(r)
    pairs = {701: (.2, .8), 702: (.8, .2), 703: (.5, .5)}
    for cell in values:
        cell["metrics"].update({name: .9 for name in r.metrics.FAMILIES.values()})
        replay, drift = pairs[cell["model_seed"]]
        cell["metrics"].update(replay=replay, drift=drift, worst_family_f1=min(replay, drift))
    groups, *_ = r.aggregate(values, design(r))
    assert groups[0]["mean"]["worst_family_f1"] == pytest.approx(.3)
    assert min(groups[0]["mean"][k] for k in r.metrics.FAMILIES.values()) == pytest.approx(.5)


@pytest.mark.parametrize("defect", ["missing", "duplicate"])
def test_aggregation_refuses_partial_or_duplicate_cells(reporting, defect):
    r = reporting
    values = cells(r)
    if defect == "missing":
        values.pop()
    else:
        values.append(deepcopy(values[0]))
    with pytest.raises(RuntimeError, match="576|Duplicate"):
        r.aggregate(values, design(r))


def metric_report(r):
    f = np.repeat(np.arange(6), 2)
    y = (f > 0) & (np.arange(len(f)) % 2 == 0)
    return r.metrics.report(y, {"labels": y, "families": f})


@pytest.mark.parametrize("defect", ["f1", "clean_fpr", "worst_family", "partition"])
def test_counts_and_nonlinear_summaries_are_checked(reporting, defect):
    r = reporting
    value = metric_report(r)
    r.validate_report(value)
    if defect == "f1":
        value["replay"]["f1"] = .3
    elif defect == "clean_fpr":
        value["_overall"]["clean_fpr"] = .1
    elif defect == "worst_family":
        value["_overall"]["worst_family_f1"] = .2
    else:
        value["replay"]["tn"] += 1
    with pytest.raises(RuntimeError):
        r.validate_report(value)


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value))


@pytest.fixture
def complete_tree(reporting, tmp_path):
    """All 144 small JSON cells, with tiny opaque score/model identity files."""
    r = reporting
    root, run = tmp_path, tmp_path / "runs/factorial"
    d = design(r)
    parity = run / "control_parity_approved.json"
    save(parity, {"status": "approved"})
    score_parity = run / "control_score_parity.json"
    save(score_parity, {"status": "approved", "cases": 2})
    save(run / "protocol_design.json", d)
    protocol = {"design": d, "design_sha256": hashlib.sha256(r.canonical(d)).hexdigest(),
                "code_sha256": {}, "input_sha256": {}, "control_parity_sha256": r.sha(parity),
                "control_score_parity_sha256": r.sha(score_parity)}
    save(run / "protocol_frozen.json", protocol)
    protocol_hash = r.sha(run / "protocol_frozen.json")
    report = metric_report(r)
    threshold = {b: [1.] * len(r.metrics.LAMBDAS) for b in r.metrics.BRANCHES}
    reports = [report for _ in r.metrics.LAMBDAS]
    selected = r.metrics.select(reports, threshold)
    selections, models, pending = {}, {}, []
    def blob(name):
        path = root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(b"synthetic identity only")
        return {"path": name, "sha256": r.sha(path)}
    for condition in r.CONDITIONS:
        for network in r.NETWORKS:
            for seed in r.SEEDS:
                folder = run / "results" / condition / network / f"seed{seed}"
                model = blob(f"models/{condition}/{network}/{seed}.bin")
                model_hashes = {model["path"]: model["sha256"]}
                models.update(model_hashes)
                score_identity = {"condition": condition, "network": network, "model_seed": seed,
                                  "protocol_sha256": protocol_hash, "model_sha256": model_hashes}
                calibration = {"condition": condition, "network": network, "model_seed": seed,
                               "protocol_sha256": protocol_hash, "model_sha256": model_hashes,
                               "original_rule_sha256": {}, "score_inputs": [{
                                   **blob(f"scores/cal_{condition}_{network}_{seed}.bin"),
                                   **score_identity, "role": "calibration"}],
                               "path_thresholds": threshold, "path_calibration": reports, "selected": selected,
                               "reserved_test_scenarios_scored": False, "evaluation_outcomes_read_for_selection": False}
                path = folder / "calibration_selection.json"
                save(path, calibration)
                selections[r.relative(root, path)] = r.sha(path)
                for source in d["data"]["evaluation_sources"][network]:
                    value = {"condition": condition, "network": network, "model_seed": seed,
                             "source_seed": source, "protocol_sha256": protocol_hash,
                             "calibration_selection_sha256": r.sha(path),
                             "score_input": {**blob(f"scores/eval_{condition}_{network}_{seed}_{source}.bin"),
                                             **score_identity, "role": "evaluation", "source_seed": source},
                             "selected": [{**{k: p[k] for k in ("cap", "objective", "lambda", "lambda_index")},
                                           "metrics": reports[p["lambda_index"]]} for p in selected],
                             "path_evaluation": reports, "reserved_test_scenarios_scored": False}
                    pending.append((folder / f"evaluation_source{source}.json", value))
    save(run / "evaluation_frozen.json", {"protocol_sha256": protocol_hash,
         "calibration_selection_sha256": selections, "model_sha256": models,
         "expected_condition_model_fits": 24, "expected_evaluation_cells": 144})
    freeze_hash = r.sha(run / "evaluation_frozen.json")
    for path, value in pending:
        save(path, {**value, "evaluation_freeze_sha256": freeze_hash})
    return root, run


def test_full_synthetic_report_validates_and_is_idempotent(reporting, complete_tree):
    r = reporting
    root, run = complete_tree
    result = r.generate(root, run)
    assert result["status"] == "complete" and result["counts"]["evaluation_cells"] == 144
    assert {k: v["rows"] for k, v in result["tables"].items()} == {
        "cells.csv": 576, "source_metrics.csv": 192, "condition_summary.csv": 32,
        "source_effects.csv": 336, "effect_summary.csv": 56}
    assert r.generate(root, run) == result


@pytest.mark.parametrize("defect", ["missing_cell", "model_hash", "calibration_hash", "selected_path", "score_hash"])
def test_full_report_rejects_incomplete_or_changed_evidence(reporting, complete_tree, defect):
    r = reporting
    root, run = complete_tree
    cell = next((run / "results").glob("*/*/seed*/evaluation_source*.json"))
    if defect == "missing_cell":
        cell.unlink()
    elif defect == "model_hash":
        next((root / "models").rglob("*.bin")).write_bytes(b"changed model")
    elif defect == "calibration_hash":
        path = next((run / "results").glob("*/*/seed*/calibration_selection.json"))
        path.write_text(path.read_text() + " ")
    elif defect == "score_hash":
        value = r.read(cell)
        (root / value["score_input"]["path"]).write_bytes(b"changed score")
    else:
        value = r.read(cell)
        value["selected"][0]["lambda_index"] = 1
        save(cell, value)
    with pytest.raises(RuntimeError):
        r.generate(root, run)
    assert not (run / "report/summary.json").exists()
