#!/usr/bin/env bash
# Topology ablation in the near-threshold regime. The graph was the only
# component that paid off in the conventional regime; this asks whether it
# still carries the model once the task is contested.
set -u
ROOT="/Users/ozanbabac5/wdn_thesis"; cd "$ROOT"; export PYTHONPATH=src
LOG="/tmp/wdn_pilot"; mkdir -p "$LOG"
for s in 1 2 3; do
  tag="notopo_s${s}"; [ -f "$LOG/$tag.done" ] && continue
  echo "[notopo] $(date +%H:%M:%S) $tag"
  PYTHONUNBUFFERED=1 python3 -u -m wdn.train_temporal_moe \
      --data_dir data/hard_modena --gnn_type GraphSAGE --hidden_dim 64 \
      --router_hidden_dim 24 --epochs 60 --batch_size 8 --lr 0.001 \
      --norm_mode per_node --window_size 6 --no_topology --seed $s \
      > "$LOG/$tag.log" 2>&1 && touch "$LOG/$tag.done"
done
echo "[notopo] ALL DONE $(date +%H:%M:%S)"
