#!/usr/bin/env bash
# Full v2 experiment queue: five-family threat model (replay restored) on
# two topologies, plus the leave-one-out ablations and the topology-free
# baseline.
#
# Ordered by importance, so an interruption still leaves the headline
# results complete:
#   1. Modena final          headline numbers
#   2. L-Town final          second topology (router-degradation regime)
#   3. Modena globalnorm/nopattern  the two components replay should revive
#   4. Modena remaining ablations
#   5. topology-free baseline (both networks)
set -u
ROOT="/Users/ozanbabac5/wdn_thesis"; cd "$ROOT"
export PYTHONPATH=src
LOG="/tmp/wdn_v2"; mkdir -p "$LOG"

BASE="--gnn_type GraphSAGE --hidden_dim 64 --router_hidden_dim 24 \
  --window_size 6 --epochs 60 --batch_size 8 --lr 0.001"

run () {   # run <tag> <data_dir> <extra-flags...>
    local tag="$1" data="$2"; shift 2
    for s in $(seq 1 10); do
        if [ -f "$LOG/${tag}_s${s}.done" ]; then continue; fi
        echo "[$tag] $(date +%H:%M:%S) start seed$s"
        PYTHONUNBUFFERED=1 python3 -u -m wdn.train_temporal_moe \
            $BASE --data_dir "$data" --seed "$s" "$@" \
            > "$LOG/${tag}_s${s}.log" 2>&1 && touch "$LOG/${tag}_s${s}.done"
        echo "[$tag] $(date +%H:%M:%S) done  seed$s"
    done
    echo "[$tag] COMPLETE $(date +%H:%M:%S)"
}

# 1-2: headline, both topologies
run md_final  data/v2_modena --norm_mode per_node
run lt_final  data/v2_ltown  --norm_mode per_node

# 3: the components replay is expected to revive
run md_globalnorm data/v2_modena --norm_mode global
run md_nopattern  data/v2_modena --norm_mode per_node --no_pattern_features

# 4: remaining leave-one-out ablations
run md_noexpert   data/v2_modena --norm_mode per_node --lambda_expert 0.0
run md_notemporal data/v2_modena --norm_mode per_node --window_size 1
run md_nomixture  data/v2_modena --norm_mode per_node --num_experts 1

# 5: topology-free baseline
run md_notopo data/v2_modena --norm_mode per_node --no_topology
run lt_notopo data/v2_ltown  --norm_mode per_node --no_topology

echo "[v2] ALL DONE $(date +%H:%M:%S)"
