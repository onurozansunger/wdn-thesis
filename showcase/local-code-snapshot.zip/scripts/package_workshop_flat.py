"""Package the workshop paper as flat files for an *existing* Overleaf project.

Overleaf only expands a zip when it creates a new project; dropping one
into a project that already exists just adds the zip as a file. And
uploading into subfolders means creating each folder by hand first. So for
a shared project the path of least resistance is a flat set of files that
can be dragged straight into the file tree.

This writes ``thesis/workshop_flat/`` (and a zip of it) in which every
``\\input`` and graphics path has been rewritten to be folder-free.

    python3 scripts/package_workshop_flat.py
"""
from __future__ import annotations

import re
import shutil
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "thesis" / "workshop"
OUT = ROOT / "thesis" / "workshop_flat"

# Paths inside main.tex that have to lose their directory component.
REWRITES = [
    (r"\\graphicspath\{\{figures/\}\}", r"\\graphicspath{{./}}"),
    (r"\\input\{tables/([A-Za-z_]+)\}", r"\\input{\1}"),
]


def main():
    subprocess.run(["python3", str(ROOT / "scripts" / "build_v2_results.py")],
                   check=True, capture_output=True)

    if OUT.exists():
        shutil.rmtree(OUT)
    OUT.mkdir(parents=True)

    text = (SRC / "main.tex").read_text()
    for pat, rep in REWRITES:
        text, n = re.subn(pat, rep, text)
        if n == 0:
            raise SystemExit(f"path rewrite matched nothing: {pat!r} — "
                             f"main.tex layout changed, update this script")
    (OUT / "main.tex").write_text(text)

    # The architecture figure was cut in the five-page version; ship it
    # only if the paper still inputs it.
    if "\\input{architecture}" in text:
        shutil.copy(SRC / "architecture.tex", OUT)
    # Copy only what the paper actually references, so a shared Overleaf
    # project does not accumulate figures from superseded drafts.
    src_text = (SRC / "main.tex").read_text()
    # Tables come in via \input, figures via \includegraphics; match each
    # against its own reference kind so a table and a figure that happen to
    # share a stem (per_attack.tex vs per_attack.pdf) are not confused.
    inputs = {Path(r).stem for r in
              re.findall(r"\\input\{([^}]+)\}", src_text)} | {"numbers"}
    graphics = {Path(r).stem for r in re.findall(
        r"\\includegraphics(?:\[[^\]]*\])?\{([^}]+)\}", src_text)}
    copied = []
    for f in sorted((SRC / "tables").glob("*.tex")):
        if f.stem in inputs:
            shutil.copy(f, OUT); copied.append(f.name)
    for f in sorted((SRC / "figures").glob("*.pdf")):
        if f.stem in graphics:
            shutil.copy(f, OUT); copied.append(f.name)

    (OUT / "UPLOAD-NOTES.md").write_text(UPLOAD_NOTES)

    zip_path = ROOT / "thesis" / "workshop_flat.zip"
    if zip_path.exists():
        zip_path.unlink()
    subprocess.run(["zip", "-q", "-r", str(zip_path), "."], cwd=OUT, check=True)

    files = sorted(p.name for p in OUT.iterdir())
    print(f"wrote {OUT} ({len(files)} files) and {zip_path}")
    for f in files:
        print("   ", f)


UPLOAD_NOTES = """\
# Uploading into an existing (shared) Overleaf project

Select **every file in this folder** and drag them into the Overleaf file
tree, or use the upload button (the arrow icon above the file list) and
select them all at once. There are no subfolders, so nothing else needs
setting up.

Then check two settings in the Overleaf menu:

* **Compiler:** pdfLaTeX
* **Main document:** `main.tex`

## Before you upload: check for a name clash

If the shared project already contains a `main.tex`, Overleaf will ask to
overwrite it. If that file is someone else's work, cancel, rename the one
here to `waterdeal.tex` first, upload, and then set **Main document** to
`waterdeal.tex`.

## Do not retype the numbers

No result is hard-coded in `main.tex`. The prose uses macros such as
`\\FinalFone`, all defined in `numbers.tex`, which is generated from the
training runs together with the figures. Edit the prose freely; to refresh
results, replace `numbers.tex`, `per_attack.tex`, `ablation.tex` and the
`.pdf` figures. Any macro showing `??` is a configuration whose runs had
not finished when this was packaged.
"""


if __name__ == "__main__":
    main()
