"""Aggregate the workshop runs into the paper's tables and figures.

Reads every completed run under ``runs/temporal_moe`` that was trained on
the four-attack Modena dataset, groups them by configuration (derived from
each run's own ``args.json``, so nothing has to be tagged by hand), and
writes:

    thesis/workshop/figures/*.pdf     vector figures for the paper
    thesis/workshop/tables/*.tex      booktabs table bodies
    thesis/workshop/numbers.json      every number the text quotes

Run after the training grid completes:

    python3 scripts/build_workshop_results.py
"""
from __future__ import annotations

import json
import statistics as st
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parent.parent
RUNS = ROOT / "runs" / "temporal_moe"
OUT = ROOT / "thesis" / "workshop"
FIG, TAB = OUT / "figures", OUT / "tables"
for d in (FIG, TAB):
    d.mkdir(parents=True, exist_ok=True)

DATA_DIR = "data/workshop_modena"
ATTACKS = ["random", "stealthy", "noise", "targeted"]
CLASSES = ["clean"] + ATTACKS
ALABEL = {"clean": "Clean", "random": "Random", "stealthy": "Stealthy",
          "noise": "Noise", "targeted": "Targeted"}

BLUE, ORANGE, GREEN, PURPLE = "#2563eb", "#ea580c", "#059669", "#7c3aed"
RED, CYAN, MUTED, INK = "#dc2626", "#0891b2", "#6b7280", "#1f2937"
ACOLOR = {"clean": MUTED, "random": BLUE, "stealthy": ORANGE,
          "noise": CYAN, "targeted": GREEN}

# Figures are sized for an IEEE two-column page: 3.4 in wide for a single
# column, 7.16 in for a full-width one. Fonts are set so that the figure
# text lands at roughly the caption size after LaTeX places it at 1:1.
plt.rcParams.update({
    "figure.facecolor": "white", "savefig.facecolor": "white",
    "axes.facecolor": "white", "axes.edgecolor": "#b9c0cc",
    "text.color": INK, "axes.labelcolor": INK,
    "xtick.color": "#4a5568", "ytick.color": "#4a5568",
    "font.family": "serif", "font.serif": ["Times New Roman", "Times",
                                           "DejaVu Serif"],
    "font.size": 8, "axes.labelsize": 8, "axes.titlesize": 8.5,
    "xtick.labelsize": 7.5, "ytick.labelsize": 7.5, "legend.fontsize": 7.5,
    "axes.grid": True, "axes.axisbelow": True, "grid.color": "#e8ebf0",
    "grid.linewidth": 0.6, "axes.spines.top": False,
    "axes.spines.right": False, "legend.frameon": False,
    "axes.linewidth": 0.7, "savefig.bbox": "tight", "savefig.pad_inches": 0.02,
})
COL, DCOL = 3.4, 7.16


# ---------------------------------------------------------------------------
# Load and group runs
# ---------------------------------------------------------------------------

def config_of(a: dict) -> str | None:
    """Name the configuration a run belongs to, from its own arguments.

    Configurations are the full model plus one-component-removed variants;
    each is identified purely from the recorded arguments, so nothing has
    to be tagged by hand.
    """
    if a.get("data_dir") != DATA_DIR or a.get("epochs") != 60:
        return None
    ne, win = a.get("num_experts"), a.get("window_size")
    if ne == 1:                                   # single expert = no mixture
        return "nomixture" if win == 6 else None
    if win == 1:                                  # one snapshot = no GRU
        return "notemporal"
    if a.get("no_pattern_features"):
        return "nopattern"
    if a.get("norm_mode") == "global":
        return "globalnorm"
    if a.get("lambda_expert") == 0.0:
        return "noexpert"
    return "final"


def load_runs() -> dict[str, list[dict]]:
    groups: dict[str, dict[int, dict]] = {}
    for d in sorted(RUNS.glob("2026*")):
        ap, tp = d / "args.json", d / "test_results.json"
        if not (ap.exists() and tp.exists()):
            continue
        a = json.load(open(ap))
        cfg = config_of(a)
        if cfg is None:
            continue
        r = json.load(open(tp))
        r["_args"] = a
        r["_dir"] = d
        # One run per (config, seed); a later re-run of the same seed wins.
        groups.setdefault(cfg, {})[a["seed"]] = r
    return {k: [v[s] for s in sorted(v)] for k, v in groups.items()}


def f1s(runs):
    return [r["anomaly_detection"]["pressure"]["f1"] for r in runs]


def aurocs(runs):
    return [r["anomaly_detection"]["pressure"]["auroc"] for r in runs]


def agg(vals):
    if not vals:
        return {"mean": float("nan"), "std": float("nan"), "n": 0}
    return {"mean": st.mean(vals),
            "std": st.stdev(vals) if len(vals) > 1 else 0.0,
            "n": len(vals)}


def per_attack(runs, key="f1"):
    out = {}
    for c in CLASSES:
        vals = [r["per_attack_pressure"][c][key] for r in runs
                if c in r.get("per_attack_pressure", {})]
        if vals:
            out[c] = agg(vals)
    return out


# ---------------------------------------------------------------------------
# Figures
# ---------------------------------------------------------------------------

def _build_model():
    """Instantiate the paper's model with the exact configuration."""
    import sys as _sys
    _sys.path.insert(0, str(ROOT / "src"))
    from wdn.models.temporal_moe import TemporalMixtureOfExpertsGNN
    return TemporalMixtureOfExpertsGNN(
        node_in_dim=7, edge_in_dim=8, hidden_dim=64, num_experts=len(CLASSES),
        router_hidden_dim=24, num_layers=2, num_temporal_layers=1,
        window_size=6, gnn_type="GraphSAGE", use_pattern_features=True)


def tab_architecture(numbers):
    """Layer-by-layer parameter budget of the final model.

    Introspects the instantiated model so the counts are exact and cannot
    fall out of step with the code.
    """
    m = _build_model()
    nparam = lambda mod: sum(p.numel() for p in mod.parameters())
    K = len(CLASSES)
    router = m.router
    exp = m.experts[0]

    # Per-expert component breakdown.
    comp = [
        ("Node encoder (linear $7\\!\\to\\!64$)", "$N\\times64$",
         nparam(exp.node_encoder)),
        ("GraphSAGE $\\times2$ (spatial)", "$N\\times64$",
         nparam(exp.temporal_gnn.spatial)),
        ("GRU, 1 layer (temporal)", "$N\\times64$",
         nparam(exp.temporal_gnn.gru)),
        ("Pressure / flow recon. heads", "$N,\\,N_E$",
         nparam(exp.pressure_head) + nparam(exp.flow_head)),
        ("Anomaly heads (node, link)", "$N,\\,N_E$",
         nparam(exp.pressure_anomaly_head) + nparam(exp.flow_anomaly_head)),
    ]
    exp_total = nparam(exp)
    rows = [f"\\quad {name} & {out} & {p:,}" for name, out, p in comp]
    rows = [f"\\textbf{{Expert}} (one of $K{{=}}{K}$) & & \\textbf{{{exp_total:,}}}"] \
        + rows
    rows.append(f"Experts, total ($\\times{K}$) & & {exp_total*K:,}")
    rows.append(f"Router (small GNN, width 24) & {K} logits & {nparam(router):,}")
    rows.append(f"\\textbf{{Full model}} & & \\textbf{{{nparam(m):,}}}")
    # Named arch_params, not architecture, so it never collides with the
    # TikZ diagram file architecture.tex when paths are flattened for a
    # shared Overleaf project.
    write_table(TAB / "arch_params.tex", "@{}lcr@{}",
                ["\\textbf{Component}", "\\textbf{Output}",
                 "\\textbf{Params}"], rows)
    numbers["architecture"] = {"expert_params": exp_total,
                               "router_params": nparam(router),
                               "total_params": nparam(m), "K": K}


# The per-sensor anomaly head is the interpretable part of the model, so
# its inputs are documented explicitly. Rows: (feature, group, what it
# captures / which attack it targets).
ANOM_FEATURES = [
    ("node embedding $h_i\\in\\mathbb R^{64}$", "context",
     "spatio-temporal state from the GNN+GRU"),
    ("observed value $\\tilde p_i$", "base", "the reading under test"),
    ("reconstruction $\\hat p_i$", "base", "value the model expects"),
    ("residual $|\\tilde p_i-\\hat p_i|$", "base",
     "disagreement --- gross falsification"),
    ("mask $m_i$", "base", "whether the sensor reported"),
    ("one-step delta", "stability", "jump against the previous step"),
    ("window std / range", "stability", "spread over the window"),
    ("$\\log$ window std", "stability", "collapses for a too-smooth series"),
    ("half-window drift", "stability", "first vs.\\ second half --- stealthy"),
    ("\\# step changes", "stability", "genuine changes inside the window"),
    ("lag-1 autocorrelation", "pattern", "smoothness: missing sensor noise"),
    ("diff-std", "pattern", "std of consecutive differences"),
    ("noise ratio", "pattern", "var(diff)/var(series) --- noise injection"),
]


def tab_anomaly_features(numbers):
    rows = [f"{f} & \\textit{{{g}}} & {d}" for f, g, d in ANOM_FEATURES]
    write_table(TAB / "anomaly_features.tex", "@{}ll>{\\raggedright\\arraybackslash}p{3.2cm}@{}",
                ["\\textbf{Feature}", "\\textbf{Group}",
                 "\\textbf{What it captures}"], rows)


def tab_recon(groups, numbers):
    """Reconstruction quality of the final model, over all seeds.

    Pressure is reported in metres and flow in litres per second (the raw
    value is in m$^3$/s, of order $10^{-4}$), so both columns read at a
    human scale.
    """
    runs = groups["final"]
    def cell(part, metric):
        return agg([r["reconstruction"][part][metric] for r in runs])
    rows = [
        ("Pressure, all nodes", "pressure_all", 1.0),
        ("Pressure, unobserved", "pressure_unobs", 1.0),
        ("Flow, all pipes", "flow_all", 1000.0),
        ("Flow, unobserved", "flow_unobs", 1000.0),
    ]
    out = []
    for label, part, scale in rows:
        mae, rmse = cell(part, "mae")["mean"] * scale, cell(part, "rmse")["mean"] * scale
        out.append(f"{label} & ${mae:.3f}$ & ${rmse:.3f}$")
    write_table(TAB / "recon.tex", "@{}lcc@{}",
                ["\\textbf{Quantity}", "\\textbf{MAE}$^\\dagger$",
                 "\\textbf{RMSE}$^\\dagger$"], out)
    numbers["reconstruction"] = {
        "p_mae_unobs": cell("pressure_unobs", "mae"),
        "q_mae_unobs_Lps": {"mean": cell("flow_unobs", "mae")["mean"] * 1000}}


def fig_per_attack(groups, numbers):
    """Per-attack F1 with the clean class shown as a false-positive rate."""
    runs = groups["final"]
    pf1, pfpr = per_attack(runs, "f1"), per_attack(runs, "fpr")
    fig, ax = plt.subplots(figsize=(COL, 1.95))
    xs = np.arange(len(ATTACKS))
    m = [pf1[a]["mean"] for a in ATTACKS]
    s = [pf1[a]["std"] for a in ATTACKS]
    ax.bar(xs, m, color=[ACOLOR[a] for a in ATTACKS], width=0.6, yerr=s,
           capsize=2.5, error_kw=dict(ecolor="#7b8494", lw=0.8))
    for i, (mi, si) in enumerate(zip(m, s)):
        ax.text(i, mi + si + 0.015, f"{mi:.3f}", ha="center", va="bottom",
                fontsize=7, fontweight="bold")
    ax.set_xticks(xs)
    ax.set_xticklabels([ALABEL[a] for a in ATTACKS])
    ax.set_ylabel("Detection F1")
    ax.set_ylim(0, 1.12)
    if "clean" in pfpr:
        ax.text(0.5, 0.04,
                f"false positives on attack-free windows: "
                f"{pfpr['clean']['mean']*100:.2f}\\%",
                transform=ax.transAxes, ha="center", fontsize=6.8,
                color=MUTED)
    fig.savefig(FIG / "per_attack.pdf")
    plt.close(fig)
    numbers["per_attack_f1"] = pf1
    numbers["per_attack_fpr"] = pfpr


def fig_routing(routing, numbers):
    """Routing schemes: is the interpretable rule as good as the opaque one?"""
    if not routing:
        return
    order = [("soft", "Soft\nmixture"), ("router_top1", "Router\ntop-1"),
             ("cascade", "Cascade\n(feedback)"), ("oracle", "Oracle\n(ceiling)")]
    cols = [BLUE, MUTED, PURPLE, GREEN]
    means = [np.mean([r[k]["f1"] for r in routing]) for k, _ in order]
    stds = [np.std([r[k]["f1"] for r in routing], ddof=1) for k, _ in order]
    fig, ax = plt.subplots(figsize=(COL, 1.95))
    x = np.arange(4)
    ax.bar(x, means, color=cols, width=0.6, yerr=stds, capsize=2.5,
           error_kw=dict(ecolor="#7b8494", lw=0.8))
    for i, (m, s) in enumerate(zip(means, stds)):
        ax.text(i, m + s + 0.006, f"{m:.3f}", ha="center", va="bottom",
                fontsize=7, fontweight="bold")
    ax.set_xticks(x)
    ax.set_xticklabels([l for _, l in order], fontsize=7)
    ax.set_ylabel("Detection F1")
    ax.set_ylim(min(means) - 0.06, max(means) + max(stds) + 0.035)
    fig.savefig(FIG / "routing.pdf")
    plt.close(fig)
    numbers["routing"] = {k: {"f1": m, "std": s}
                          for (k, _), m, s in zip(order, means, stds)}
    numbers["cascade_diagnostics"] = {
        "mean_attempts": float(np.mean(
            [r["diagnostics"]["mean_attempts"] for r in routing])),
        "accepted_first_rate": float(np.mean(
            [r["diagnostics"]["accepted_first_rate"] for r in routing])),
        "router_top1_acc": float(np.mean(
            [r["diagnostics"]["router_top1_acc"] for r in routing])),
    }


def fig_router_confusion(routing, numbers):
    """Where the router sends each attack class."""
    if not routing:
        return
    conf = np.array([r["diagnostics"]["router_confusion"] for r in routing],
                    dtype=float).sum(axis=0)
    rows = conf.sum(1, keepdims=True)
    rows[rows == 0] = 1
    norm = conf / rows
    K = conf.shape[0]
    fig, ax = plt.subplots(figsize=(COL, 2.1))
    ax.imshow(norm, cmap="Blues", vmin=0, vmax=1)
    names = [ALABEL[c] for c in CLASSES[:K]]
    ax.set_xticks(range(K)); ax.set_xticklabels(names, rotation=35, ha="right")
    ax.set_yticks(range(K)); ax.set_yticklabels(names)
    for i in range(K):
        for j in range(K):
            ax.text(j, i, f"{norm[i, j]:.2f}", ha="center", va="center",
                    fontsize=6.5,
                    color="white" if norm[i, j] > 0.55 else INK)
    ax.set_xlabel("expert selected"); ax.set_ylabel("true attack class")
    ax.grid(False)
    fig.savefig(FIG / "router_confusion.pdf")
    plt.close(fig)
    numbers["router_confusion"] = conf.tolist()


def fig_learning(groups, numbers):
    """Convergence and seed spread for the final configuration."""
    runs = groups["final"]
    curves = []
    for r in runs:
        h = json.load(open(r["_dir"] / "history.json"))
        curves.append([e.get("val_p_anomaly_f1", np.nan) for e in h])
    n = min(len(c) for c in curves)
    arr = np.array([c[:n] for c in curves], dtype=float)
    ep = np.arange(1, n + 1)
    fig, ax = plt.subplots(figsize=(COL, 1.9))
    ax.fill_between(ep, np.nanmin(arr, 0), np.nanmax(arr, 0), color=PURPLE,
                    alpha=0.16, lw=0)
    ax.plot(ep, np.nanmean(arr, 0), color=PURPLE, lw=1.4)
    ax.set_xlabel("epoch"); ax.set_ylabel("validation F1")
    ax.set_ylim(min(0.6, float(np.nanmin(arr))), 1.0)
    fig.savefig(FIG / "learning_curve.pdf")
    plt.close(fig)
    numbers["epochs_to_95pct"] = int(
        np.argmax(np.nanmean(arr, 0) >= 0.95 * np.nanmax(np.nanmean(arr, 0))) + 1)


# ---------------------------------------------------------------------------
# Tables
# ---------------------------------------------------------------------------

def write_table(path: Path, colspec: str, header: list[str], rows: list[str]):
    """Write a complete ``tabular`` environment.

    The whole environment is emitted, not just the rows: ``\\input`` of a
    fragment *inside* a tabular makes TeX open a cell before it reads the
    file, which breaks the alignment. Captions and labels stay in the
    paper, so only the numbers live here.
    """
    body = [f"\\begin{{tabular}}{{{colspec}}}", "\\toprule",
            " & ".join(header) + " \\\\", "\\midrule"]
    body += [r.rstrip().rstrip("\\").rstrip() + " \\\\" for r in rows]
    body += ["\\bottomrule", "\\end{tabular}"]
    path.write_text("\n".join(body) + "\n")


def tab_main(groups, numbers):
    runs = groups["final"]
    a = runs[0]["anomaly_detection"]["pressure"]
    prec = agg([r["anomaly_detection"]["pressure"]["precision"] for r in runs])
    rec = agg([r["anomaly_detection"]["pressure"]["recall"] for r in runs])
    f1 = agg(f1s(runs))
    au = agg(aurocs(runs))
    pmae = agg([r["reconstruction"]["pressure_unobs"]["mae"] for r in runs])
    numbers["final"] = {"precision": prec, "recall": rec, "f1": f1,
                        "auroc": au, "p_mae_unobs": pmae,
                        "n_params": runs[0]["n_params"],
                        "n_seeds": len(runs)}
    pf1, pfpr = per_attack(runs, "f1"), per_attack(runs, "fpr")
    lines = []
    for c in CLASSES:
        if c not in pf1:
            continue
        # The clean class contains no positives, so F1 and AUROC are both
        # undefined there; it is characterised by its false alarm rate.
        au_c = agg([r["per_attack_pressure"][c]["auroc"] for r in runs])
        f = au = "---"
        if c != "clean":
            f = f"${pf1[c]['mean']:.3f} \\pm {pf1[c]['std']:.3f}$"
            au = f"${au_c['mean']:.3f}$"
        lines.append(
            f"{ALABEL[c]} & {f} & {au} & ${pfpr[c]['mean']*100:.2f}$")
    write_table(TAB / "per_attack.tex", "@{}lccc@{}",
                ["\\textbf{Class}", "\\textbf{F1}", "\\textbf{AUROC}",
                 "\\textbf{False alarms (\\%)}"], lines)


def tab_ablation(groups, routing, numbers):
    rows = []
    base = agg(f1s(groups["final"]))
    def row(name, key):
        if not groups.get(key):
            return
        v = agg(f1s(groups[key]))
        d = v["mean"] - base["mean"]
        rows.append(f"{name} & ${v['mean']:.3f} \\pm {v['std']:.3f}$ & "
                    f"${d:+.3f}$")
        numbers.setdefault("ablation", {})[key] = {**v, "delta": d}
    rows.append(f"\\textbf{{Full model}} & $\\mathbf{{{base['mean']:.3f} \\pm "
                f"{base['std']:.3f}}}$ & ---")
    row("$-$ direct expert supervision", "noexpert")
    row("$-$ per-sensor normalisation", "globalnorm")
    row("$-$ temporal recurrence (GRU)", "notemporal")
    row("$-$ expert mixture (single net)", "nomixture")
    row("$-$ pattern features", "nopattern")
    write_table(TAB / "ablation.tex", "@{}lcc@{}",
                ["\\textbf{Configuration}", "\\textbf{F1}",
                 "\\textbf{$\\Delta$}"], rows)


def tab_calibration(groups, numbers):
    runs = groups["final"]
    cal = agg(f1s(runs))
    unc = agg([r["uncalibrated"]["pressure_f1"] for r in runs
               if r.get("uncalibrated")])
    thr = agg([r["threshold"] for r in runs])
    numbers["calibration"] = {"calibrated": cal, "uncalibrated": unc,
                              "threshold": thr}


def write_macros(numbers):
    """Emit every number the prose quotes as a LaTeX macro.

    The paper never hard-codes a result: it says ``\\FinalFone``, which is
    defined here from the runs. Re-running this script after more seeds
    updates the text and the figures together, so they cannot drift apart.
    """
    # Every macro the paper can reference is defined up front as "??", so a
    # partially-complete grid still compiles and the gaps are visible in the
    # PDF instead of failing the build.
    m: dict[str, str] = {k: "??" for k in [
        "FinalFone", "FinalFoneStd", "FinalAUROC", "FinalPrec", "FinalRec",
        "FinalPMAE", "FinalParams", "ExpertParams", "RouterParams",
        "NSeeds", "CleanFPR",
        "AttRandom", "AttStealthy", "AttNoise", "AttTargeted",
        "RoutSoft", "RoutTopOne", "RoutCascade",
        "RoutOracle", "RouterAcc", "CascadeKeptFirst", "RoutGap",
        "ThrCal", "FoneUncal",
        "AblMixture", "AblPattern", "AblNorm", "AblTemporal", "AblExpert",
        "DelMixture", "DelPattern", "DelNorm", "DelTemporal", "DelExpert",
    ]}

    def put(name, value, fmt="{:.3f}"):
        m[name] = fmt.format(value) if isinstance(value, float) else str(value)

    f = numbers["final"]
    put("FinalFone", f["f1"]["mean"])
    put("FinalFoneStd", f["f1"]["std"])
    put("FinalAUROC", f["auroc"]["mean"])
    put("FinalPrec", f["precision"]["mean"])
    put("FinalRec", f["recall"]["mean"])
    put("FinalPMAE", f["p_mae_unobs"]["mean"])
    put("FinalParams", f"{f['n_params']:,}")
    put("NSeeds", f["n_seeds"])

    arch = numbers.get("architecture", {})
    if arch:
        put("ExpertParams", f"{arch['expert_params']:,}")
        put("RouterParams", f"{arch['router_params']:,}")

    for c, v in numbers.get("per_attack_f1", {}).items():
        if c != "clean":            # no positives there, so no F1
            put(f"Att{c.capitalize()}", v["mean"])
    if "clean" in numbers.get("per_attack_fpr", {}):
        put("CleanFPR", numbers["per_attack_fpr"]["clean"]["mean"] * 100,
            "{:.2f}")

    # Control sequences cannot contain digits, so configuration keys are
    # mapped to explicit alphabetic macro names rather than mangled.
    rout_name = {"soft": "Soft", "router_top1": "TopOne",
                 "cascade": "Cascade", "oracle": "Oracle"}
    rout = numbers.get("routing", {})
    for k, v in rout.items():
        put("Rout" + rout_name[k], v["f1"])
    if "soft" in rout and "cascade" in rout:
        put("RoutGap", rout["soft"]["f1"] - rout["cascade"]["f1"])
    cd = numbers.get("cascade_diagnostics", {})
    if cd:
        put("RouterAcc", cd["router_top1_acc"] * 100, "{:.1f}")
        put("CascadeKeptFirst", cd["accepted_first_rate"] * 100, "{:.1f}")

    abl_name = {"noexpert": "Expert", "nopattern": "Pattern",
                "globalnorm": "Norm", "notemporal": "Temporal",
                "nomixture": "Mixture"}
    for k, v in numbers.get("ablation", {}).items():
        put("Abl" + abl_name[k], v["mean"])
        put("Del" + abl_name[k], abs(v["delta"]))

    cal = numbers.get("calibration", {})
    if cal and cal["uncalibrated"]["n"]:
        put("FoneUncal", cal["uncalibrated"]["mean"])
        put("ThrCal", cal["threshold"]["mean"], "{:.2f}")

    lines = ["% Generated by scripts/build_workshop_results.py — do not edit.",
             "% Every result quoted in the text resolves through these macros."]
    lines += [f"\\newcommand{{\\{k}}}{{{v}}}" for k, v in sorted(m.items())]
    (TAB / "numbers.tex").write_text("\n".join(lines) + "\n")
    return m


# ---------------------------------------------------------------------------

def main():
    groups = load_runs()
    print("Runs found:")
    for k, v in sorted(groups.items()):
        print(f"  {k:<14} {len(v)} seeds  F1={agg(f1s(v))['mean']:.4f}")
    if "final" not in groups:
        raise SystemExit("no runs for the final configuration yet")

    rp = RUNS / "workshop_routing.json"
    routing = json.load(open(rp))["runs"] if rp.exists() else []
    if not routing:
        print("  (no routing study yet — run eval_workshop_routing.py)")

    numbers: dict = {"n_seeds": {k: len(v) for k, v in groups.items()}}
    tab_main(groups, numbers)
    tab_architecture(numbers)
    tab_anomaly_features(numbers)
    tab_recon(groups, numbers)
    tab_ablation(groups, routing, numbers)
    tab_calibration(groups, numbers)
    fig_per_attack(groups, numbers)
    fig_routing(routing, numbers)
    fig_router_confusion(routing, numbers)
    fig_learning(groups, numbers)

    write_macros(numbers)
    json.dump(numbers, open(OUT / "numbers.json", "w"), indent=2, default=str)
    print(f"\nWrote figures -> {FIG}\n      tables  -> {TAB}"
          f"\n      numbers -> {OUT / 'numbers.json'}")


if __name__ == "__main__":
    main()
