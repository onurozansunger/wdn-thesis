#!/usr/bin/env bash
# Complete the near-threshold picture:
#   (a) the topology ablation, which was the only component that paid off
#       in the conventional regime and is untested here;
#   (b) seeds 4-10 for every configuration, so the near-threshold table
#       carries the same 10-seed weight as the conventional one. The
#       mixture effect in particular is borderline at three seeds.
set -u
ROOT="/Users/ozanbabac5/wdn_thesis"; cd "$ROOT"; export PYTHONPATH=src
LOG="/tmp/wdn_pilot"; mkdir -p "$LOG"
B="--data_dir data/hard_modena --gnn_type GraphSAGE --hidden_dim 64 \
   --router_hidden_dim 24 --epochs 60 --batch_size 8 --lr 0.001 --norm_mode per_node"

flags () {
  case $1 in
    final)      echo "--window_size 6" ;;
    nomixture)  echo "--window_size 6 --num_experts 1" ;;
    notemporal) echo "--window_size 1" ;;
    notopo)     echo "--window_size 6 --no_topology" ;;
  esac
}

run () {  # run <cfg> <seeds...>
  local c="$1"; shift
  for s in "$@"; do
    tag="${c}_s${s}"; [ -f "$LOG/$tag.done" ] && continue
    echo "[ext] $(date +%H:%M:%S) $tag"
    PYTHONUNBUFFERED=1 python3 -u -m wdn.train_temporal_moe $B $(flags $c) \
        --seed "$s" > "$LOG/$tag.log" 2>&1 && touch "$LOG/$tag.done"
  done
}

# Bring every configuration to ten seeds (notopo 1-3 is run separately,
# by run_pilot_notopo.sh, so the qualitative answer lands first).
for s in 4 5 6 7 8 9 10; do
  for c in final nomixture notemporal notopo; do run $c $s; done
done
echo "[ext] ALL DONE $(date +%H:%M:%S)"
