#!/usr/bin/env bash
# Pilot: do the mixture and the GRU earn their keep once the task is hard
# but possible? Same data, same budget; only the architecture differs.
#   final       full model
#   nomixture   single expert, no router
#   notemporal  one snapshot, no GRU
set -u
ROOT="/Users/ozanbabac5/wdn_thesis"; cd "$ROOT"; export PYTHONPATH=src
LOG="/tmp/wdn_pilot"; mkdir -p "$LOG"
B="--data_dir data/hard_modena --gnn_type GraphSAGE --hidden_dim 64 \
   --router_hidden_dim 24 --epochs 60 --batch_size 8 --lr 0.001 --norm_mode per_node"
for s in 1 2 3; do
  for cfg in final nomixture notemporal; do
    tag="${cfg}_s${s}"; [ -f "$LOG/$tag.done" ] && continue
    case $cfg in
      final)      X="--window_size 6" ;;
      nomixture)  X="--window_size 6 --num_experts 1" ;;
      notemporal) X="--window_size 1" ;;
    esac
    echo "[pilot] $(date +%H:%M:%S) $tag"
    PYTHONUNBUFFERED=1 python3 -u -m wdn.train_temporal_moe $B $X --seed $s \
        > "$LOG/$tag.log" 2>&1 && touch "$LOG/$tag.done"
  done
  echo "[pilot] --- seed $s complete $(date +%H:%M:%S) ---"
done
echo "[pilot] ALL DONE $(date +%H:%M:%S)"
