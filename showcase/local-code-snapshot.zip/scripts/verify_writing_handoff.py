"""Verify archived bytes, writing links and frozen evidence without evaluation."""
from pathlib import Path
import hashlib
import json
import os
import re

ROOT = Path(__file__).resolve().parents[1]
ARCHIVE = ROOT/'archive/2026-09-08-writing-handoff'
FINAL = ROOT/'runs/operational/early_warning_multiseed_v1/final_ten_model_seeds_v1'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main():
    manifest = json.loads((ARCHIVE/'move_manifest.json').read_text())
    count = 0
    for record in manifest['records']:
        dest = ROOT/record['archived']
        assert dest.exists(), dest
        for entry in record['files']:
            path = dest if entry['relative'] == '.' else dest/entry['relative']
            if 'symlink' in entry:
                assert path.is_symlink() and os.readlink(path) == entry['symlink'], path
            else:
                assert path.stat().st_size == entry['bytes'] and sha(path) == entry['sha256'], path
            count += 1
        if record['compatibility_link']:
            original = ROOT/record['original']
            assert original.is_symlink() and original.resolve() == dest.resolve(), original
    print('Archived entries verified:', count, flush=True)

    frozen = {}
    for filename, key in [('protocol_frozen.json', 'input_code_sha256'),
                          ('evaluation_frozen.json', 'model_rule_sha256'),
                          ('evaluation_input_frozen.json', 'input_sha256')]:
        for relative, digest in json.loads((FINAL/filename).read_text())[key].items():
            if relative in frozen:
                assert frozen[relative] == digest
            frozen[relative] = digest
    audit = json.loads((FINAL/'final_artifact_audit.json').read_text())
    assert audit['status'] == 'verified'
    for network in audit['artifact_index'].values():
        for model in network.values():
            for artifact in model.values():
                relative = str(Path(artifact['path']).relative_to(ROOT))
                if relative in frozen:
                    assert frozen[relative] == artifact['sha256']
                frozen[relative] = artifact['sha256']
    for relative, digest in frozen.items():
        assert sha(ROOT/relative) == digest, f'Frozen evidence changed: {relative}'
    print('Frozen evidence paths verified:', len(frozen), flush=True)

    links = 0
    for p in (ROOT/'TEZ_YAZIMI').rglob('*'):
        if p.is_symlink():
            assert p.exists(), p
            links += 1
    docs = [ROOT/'README.md', ROOT/'REPRODUCE.md', ARCHIVE/'README.md',
            *(ROOT/'TEZ_YAZIMI').glob('*.md'),
            ROOT/'thesis_v2/README.md', ROOT/'thesis_v2/STATUS.md', ROOT/'thesis_v2/CLAIMS_LEDGER.md']
    for p in docs:
        for target in re.findall(r'\]\(([^)]+)\)', p.read_text()):
            if not target.startswith(('http:', 'https:', '#')):
                assert (p.parent/target.split('#')[0]).exists(), (p, target)
    result = {'status': 'verified', 'deleted_files': 0,
              'archived_entries_verified': count, 'frozen_evidence_paths_verified': len(frozen),
              'writing_shortcuts_verified': links, 'writing_document_links_verified': True,
              'training_calibration_evaluation_rerun': False,
              'raw_locked_test_contents_read': False,
              'final_result_json_sha256': sha(FINAL/'final_results.json'),
              'scope': 'Read-only hash verification of previously frozen artifacts; no metric recomputation.'}
    (ARCHIVE/'verification.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
