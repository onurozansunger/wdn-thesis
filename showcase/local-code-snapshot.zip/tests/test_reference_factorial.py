from copy import deepcopy
import pickle

import numpy as np
import pytest

from wdn.models.blind_reference import BlindPressureReference
from wdn.models.reference_factorial import ReferenceFactorial
from wdn.models.robust_reference import RobustBlindReference


@pytest.fixture(scope="module")
def fitted_anchor():
    rng = np.random.default_rng(307)
    latent = rng.normal(size=(80, 3))
    loadings = rng.normal(size=(20, 3))
    values = 30. + latent @ loadings.T + rng.normal(0., .08, size=(80, 20))
    observed = rng.random(values.shape) > .25
    base = BlindPressureReference(rank=3, groups=4, iterations=4).fit(values, observed)
    anchor = RobustBlindReference(base).calibrate_scale(values, observed)
    return anchor, values, observed


def arm(anchor, exclusion, robust):
    return ReferenceFactorial(anchor, exclude_target_group=exclusion,
                              robust_reweighting=robust)


def test_enabled_enabled_reproduces_anchor_exactly(fitted_anchor):
    anchor, values, observed = fitted_anchor
    candidate = arm(anchor, True, True)
    for actual, expected in zip(candidate.predict_details(values, observed),
                                anchor.predict_details(values, observed)):
        np.testing.assert_array_equal(actual, expected)
    for actual, expected in zip(candidate.predict(values, observed),
                                anchor.predict(values, observed)):
        np.testing.assert_array_equal(actual, expected)


@pytest.mark.parametrize("robust", [False, True])
def test_exclusion_hides_target_group_values_and_masks(fitted_anchor, robust):
    anchor, values, observed = fitted_anchor
    candidate = arm(anchor, True, robust)
    target = anchor.reference.group_ == 2
    changed_values = values.copy()
    changed_values[:, target] += np.linspace(-17., 19., len(values))[:, None]
    changed_mask = observed.copy()
    changed_mask[:, target] = ~changed_mask[:, target]
    before = candidate.predict_details(values, observed)
    after = candidate.predict_details(changed_values, changed_mask)
    for original, perturbed in zip(before, after):
        np.testing.assert_array_equal(original[:, target], perturbed[:, target])


@pytest.mark.parametrize("robust", [False, True])
def test_inclusive_arm_responds_to_target_observations(fitted_anchor, robust):
    anchor, values, observed = fitted_anchor
    candidate = arm(anchor, False, robust)
    target = anchor.reference.group_ == 2
    changed = values.copy()
    changed[:, target] += .05
    before = candidate.predict_details(values, observed)
    after = candidate.predict_details(changed, observed)
    assert np.max(np.abs(before[0][:, target] - after[0][:, target])) > 1e-5
    # Support is the same non-target availability channel in every arm.
    np.testing.assert_array_equal(before[1], after[1])


@pytest.mark.parametrize("robust", [False, True])
def test_inclusion_preserves_non_target_view_membership(fitted_anchor, robust):
    anchor, _, _ = fitted_anchor
    included = arm(anchor, False, robust)
    rng = np.random.default_rng(anchor.seed)
    for group in range(anchor.reference.groups):
        outside = anchor.reference.group_ != group
        for view in range(anchor.views):
            expected = np.ones(len(outside), dtype=bool) if view == 0 else rng.random(len(outside)) < .8
            if np.count_nonzero(expected & outside) <= anchor.reference.rank:
                expected[:] = True
            np.testing.assert_array_equal(included.subsets_[group][view], expected)
            np.testing.assert_array_equal(included.subsets_[group][view][outside],
                                          anchor.subsets_[group][view][outside])


def test_original_small_subset_fallback_is_shared(fitted_anchor):
    _, values, observed = fitted_anchor
    # Fifteen visible sensors and rank fourteen force some sampled views to
    # fall back, while retaining at least one sensor per target group.
    base = BlindPressureReference(rank=14, groups=4, iterations=2).fit(values, observed)
    anchor = RobustBlindReference(base).calibrate_scale(values, observed)
    included = arm(anchor, False, False)
    rng = np.random.default_rng(anchor.seed)
    fallbacks = 0
    for group in range(base.groups):
        outside = base.group_ != group
        for view in range(1, anchor.views):
            draw = rng.random(len(outside)) < .8
            if np.count_nonzero(draw & outside) <= base.rank:
                fallbacks += 1
                np.testing.assert_array_equal(included.subsets_[group][view], True)
                np.testing.assert_array_equal(anchor.subsets_[group][view], outside)
    assert fallbacks > 0


@pytest.mark.parametrize("exclusion", [False, True])
def test_reweighting_off_matches_independent_whitened_ridge_solution(fitted_anchor, exclusion):
    anchor, values, observed = fitted_anchor
    candidate = arm(anchor, exclusion, False)
    ref = anchor.reference
    sigma = ref.noise_scale_
    design = ref.basis_ * ref.scale_[:, None] / sigma[:, None]
    expected_prediction = np.empty_like(values)
    expected_spread = np.empty_like(values)
    expected_support = np.empty_like(values)
    for group in range(ref.groups):
        target = ref.group_ == group
        for timestep in range(len(values)):
            estimates = []
            for subset in candidate.subsets_[group]:
                visible = observed[timestep] & subset
                matrix = design[visible]
                response = (values[timestep, visible] - ref.mean_[visible]) / sigma[visible]
                latent = np.linalg.solve(matrix.T @ matrix + ref.ridge * np.eye(ref.rank),
                                         matrix.T @ response)
                estimates.append((design[target] @ latent) * sigma[target] + ref.mean_[target])
            estimates = np.asarray(estimates)
            center = np.median(estimates, axis=0)
            expected_prediction[timestep, target] = center
            expected_spread[timestep, target] = np.median(np.abs(estimates - center), axis=0)
            expected_support[timestep, target] = np.mean(observed[timestep, ~target])
    actual = candidate.predict_details(values, observed)
    np.testing.assert_allclose(actual[0], expected_prediction, rtol=1e-12, atol=1e-12)
    np.testing.assert_array_equal(actual[1], expected_support)
    np.testing.assert_allclose(actual[2], expected_spread, rtol=1e-12, atol=1e-12)
    assert candidate.steps == 1


@pytest.mark.parametrize("exclusion,robust", [(True, True), (True, False), (False, True), (False, False)])
def test_scales_and_anchor_stay_unchanged(fitted_anchor, exclusion, robust):
    anchor, values, observed = fitted_anchor
    serialized = pickle.dumps(anchor)
    candidate = arm(anchor, exclusion, robust)
    np.testing.assert_array_equal(candidate.noise_scale_, anchor.noise_scale_)
    for name in ("mean_", "scale_", "basis_", "group_", "noise_scale_"):
        np.testing.assert_array_equal(getattr(candidate.reference, name), getattr(anchor.reference, name))
        assert not np.shares_memory(getattr(candidate.reference, name), getattr(anchor.reference, name))
    assert candidate.reference is not anchor.reference
    assert not np.shares_memory(candidate.noise_scale_, anchor.noise_scale_)
    for name in ("rank", "groups", "iterations", "ridge", "robust_steps"):
        assert getattr(candidate.reference, name) == getattr(anchor.reference, name)
    for name in ("views", "cutoff", "seed"):
        assert getattr(candidate, name) == getattr(anchor, name)
    candidate.predict_details(values[:8], observed[:8])
    with pytest.raises(RuntimeError, match="frozen"):
        candidate.calibrate_scale(values, observed)
    candidate.noise_scale_[0] *= 2
    candidate.reference.mean_[0] += 1
    candidate.subsets_[0][0][0] = not candidate.subsets_[0][0][0]
    assert pickle.dumps(anchor) == serialized


@pytest.mark.parametrize("exclusion,robust", [(True, True), (True, False), (False, True), (False, False)])
def test_unavailable_values_never_affect_predictions(fitted_anchor, exclusion, robust):
    anchor, values, observed = fitted_anchor
    candidate = arm(anchor, exclusion, robust)
    unavailable = values.copy()
    unavailable[~observed] = np.nan
    for a, b in zip(candidate.predict_details(values, observed),
                    candidate.predict_details(unavailable, observed)):
        np.testing.assert_array_equal(a, b)


def test_incompatible_or_modified_anchor_is_rejected(fitted_anchor):
    anchor, _, _ = fitted_anchor
    modified = deepcopy(anchor)
    modified.subsets_[0][1][1] = not modified.subsets_[0][1][1]
    with pytest.raises(ValueError, match="view masks"):
        arm(modified, True, True)
    with pytest.raises(ValueError, match="original frozen anchor"):
        arm(arm(anchor, False, False), True, True)
    with pytest.raises(TypeError, match="booleans"):
        arm(anchor, "False", True)
