#!/usr/bin/env bash
# Block until all six workshop configurations have 10 seeds, then rebuild
# the tables, figures and macros, recompile the PDF, and repackage for
# Overleaf. Writes /tmp/wdn_workshop_DONE on success so the caller knows
# the clean, gap-free deliverable is ready.
set -u
cd /Users/ozanbabac5/wdn_thesis
export PYTHONPATH=src
rm -f /tmp/wdn_workshop_DONE

ready() {
python3 - <<'PY'
import json, glob, os, sys
from collections import Counter
want = {
 (5,6,'per_node',0.5,False),   # final
 (5,6,'per_node',0.0,False),   # noexpert
 (5,6,'per_node',0.5,True),    # nopattern
 (5,6,'global',0.5,False),     # globalnorm
 (5,1,'per_node',0.5,False),   # notemporal
 (1,6,'per_node',0.5,False),   # nomixture
}
c = Counter()
for d in glob.glob("runs/temporal_moe/2026*"):
    p, t = d+"/args.json", d+"/test_results.json"
    if not (os.path.exists(p) and os.path.exists(t)): continue
    a = json.load(open(p))
    if a.get("data_dir")!="data/workshop_modena" or a.get("epochs")!=60: continue
    k=(a.get("num_experts"),a.get("window_size"),a.get("norm_mode"),
       a.get("lambda_expert"),bool(a.get("no_pattern_features")))
    if k in want: c[k]+=1
sys.exit(0 if all(c[k]>=10 for k in want) else 1)
PY
}

echo "[watch] $(date +%H:%M:%S) waiting for all six configs to reach 10 seeds"
while ! ready; do sleep 180; done
echo "[watch] $(date +%H:%M:%S) all configs complete — rebuilding"

python3 scripts/build_workshop_results.py
python3 scripts/package_workshop_flat.py
bash scripts/package_workshop_overleaf.sh
( cd thesis/workshop && latexmk -pdf -interaction=nonstopmode main.tex >/dev/null 2>&1 \
                     && latexmk -pdf -interaction=nonstopmode main.tex >/dev/null 2>&1 )

PAGES=$(pdfinfo thesis/workshop/main.pdf 2>/dev/null | awk '/Pages/{print $2}')
QMARKS=$(pdftotext thesis/workshop/main.pdf - 2>/dev/null | grep -c '??')
echo "[watch] final PDF: ${PAGES} pages, ${QMARKS} literal '??' in text" \
     > /tmp/wdn_workshop_STATUS
touch /tmp/wdn_workshop_DONE
echo "[watch] $(date +%H:%M:%S) DONE — deliverables refreshed (${PAGES} pages)"
