"""Compare routing schemes over already-trained experts (workshop study).

The cascade is a *decision procedure*, not a different model: the router
ranks the experts, the top-ranked one runs, a label-free feedback signal
accepts or rejects it, and on rejection the next candidate runs. So one
checkpoint can be scored under every scheme with no retraining, which
isolates the effect of the routing rule itself.

Four schemes:
    soft         the trained model's own router-weighted mixture
    router_top1  hard-select the router's argmax, no feedback
    cascade      router ranks, feedback accepts/re-routes
    oracle       hard-select the expert owning the *true* class (ceiling)

Differences from the older ``eval_cascade.py``:
  * the scenario split is rebuilt exactly as the training script builds it
    (shuffled with seed 42), instead of a sequential split that leaked
    training scenarios into the reported test set;
  * attack ids are compacted the same way training compacts them, so this
    works on datasets that cover a subset of the attack vocabulary;
  * each scheme's decision threshold is calibrated on validation, matching
    how the headline numbers are produced.

Usage:
    python3 scripts/eval_workshop_routing.py \
        --data_dir data/workshop_modena \
        --runs runs/temporal_moe/2026* \
        --out runs/temporal_moe/workshop_routing.json
"""
from __future__ import annotations

import argparse
import json
import pickle
import sys
from pathlib import Path

import numpy as np
import torch
from sklearn.metrics import f1_score, roc_auc_score

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from wdn.corruption import active_attack_classes, compact_id_map
from wdn.models.temporal_moe import (
    TemporalMixtureOfExpertsGNN, cascade_route, expert_feedback_scores,
)
from wdn.temporal_dataset import create_temporal_dataloaders


def load_split(data_dir: Path, window_size: int, batch_size: int,
               norm_mode: str):
    """Rebuild the train/val/test split used by ``wdn.train_temporal_moe``."""
    snaps = pickle.load(open(data_dir / "snapshots.pkl", "rb"))
    corr = pickle.load(open(data_dir / "corrupted.pkl", "rb"))
    graph = pickle.load(open(data_dir / "graph.pkl", "rb"))

    class_names = active_attack_classes(corr)
    attack_id_map = compact_id_map(class_names)

    scenarios = sorted({s.scenario_id for s in snaps})
    rng = np.random.default_rng(42)
    shuffled = scenarios.copy()
    rng.shuffle(shuffled)
    n_train = int(len(shuffled) * 0.70)
    n_val = int(len(shuffled) * 0.15)
    train_scen = set(shuffled[:n_train])
    val_scen = set(shuffled[n_train:n_train + n_val])
    test_scen = set(shuffled[n_train + n_val:])

    def _f(scen_set):
        keep = [i for i, s in enumerate(snaps) if s.scenario_id in scen_set]
        return [snaps[i] for i in keep], [corr[i] for i in keep]

    trs, trc = _f(train_scen)
    vas, vac = _f(val_scen)
    tes, tec = _f(test_scen)
    loaders = create_temporal_dataloaders(
        trs, trc, vas, vac, tes, tec,
        window_size=window_size, batch_size=batch_size, num_workers=0,
        norm_mode=norm_mode, attack_id_map=attack_id_map,
    )
    return loaders, graph, class_names


def to_device(batch, device):
    return {k: (v.to(device) if torch.is_tensor(v)
                else [t.to(device) for t in v] if isinstance(v, list) else v)
            for k, v in batch.items()}


@torch.no_grad()
def collect(model, loader, device, incidence, tau, max_attempts):
    """Score every routing scheme over one loader."""
    model.eval()
    soft_logit, casc_logit, labels, atk = [], [], [], []
    top1_logit, oracle_logit = [], []
    diag = {"n_attempts": [], "accepted_first": [], "chosen": [], "true": [],
            "top1": []}

    for raw in loader:
        b = to_device(raw, device)
        out = model(
            x_seq=b["x_seq"], edge_index=b["edge_index"],
            edge_attr=b["edge_attr"], is_original_edge=b["is_original_edge"],
            batch_size=b["batch_size"], num_nodes_per_graph=b["num_nodes"],
            pressure_obs=b["pressure_obs"], flow_obs=b["flow_obs"],
            pressure_mask=b["pressure_mask"], flow_mask=b["flow_mask"],
        )
        casc = cascade_route(out, b, incidence, tau=tau,
                             max_attempts=max_attempts)

        m = b["pressure_mask"] > 0
        soft_logit.append(out["pressure_anomaly_logits"][m].cpu())
        casc_logit.append(casc["pressure_anomaly_logits"][m].cpu())
        labels.append(b["pressure_anomaly"][m].cpu())

        N = b["num_nodes"]
        stack = out["expert_pressure_anomaly_logits"]              # (B*N, K)

        def _pick(sel_per_graph):
            idx = sel_per_graph.repeat_interleave(N).unsqueeze(-1)
            return stack.gather(-1, idx).squeeze(-1)

        top1 = out["router_probs"].argmax(dim=-1)
        top1_logit.append(_pick(top1)[m].cpu())
        true_e = b["attack_type"].clamp(max=stack.shape[-1] - 1).long()
        oracle_logit.append(_pick(true_e)[m].cpu())

        atk.append(b["attack_type"].repeat_interleave(N)[m].cpu())
        diag["n_attempts"].append(casc["n_attempts"].cpu())
        diag["accepted_first"].append(casc["accepted_first"].cpu())
        diag["chosen"].append(casc["chosen_expert"].cpu())
        diag["true"].append(b["attack_type"].cpu())
        diag["top1"].append(top1.cpu())

    cat = lambda xs: torch.cat(xs).numpy()
    variants = {
        "soft": cat(soft_logit),
        "router_top1": cat(top1_logit),
        "cascade": cat(casc_logit),
        "oracle": cat(oracle_logit),
    }
    return (variants, cat(labels), cat(atk),
            {k: cat(v) for k, v in diag.items()})


def _sigmoid(x):
    """Overflow-free logistic — large negative logits are routine here."""
    return np.where(x >= 0, 1 / (1 + np.exp(-np.abs(x))),
                    np.exp(-np.abs(x)) / (1 + np.exp(-np.abs(x))))


def best_threshold(logit, label, grid=None):
    """Threshold maximising F1 — call on validation, apply to test."""
    prob = _sigmoid(logit)
    if grid is None:
        grid = np.linspace(0.02, 0.98, 97)
    best_t, best_f1 = 0.5, -1.0
    for t in grid:
        f1 = f1_score(label, (prob > t).astype(int), zero_division=0)
        if f1 > best_f1:
            best_f1, best_t = f1, float(t)
    return best_t


def metrics(logit, label, atk, class_names, threshold):
    prob = _sigmoid(logit)
    pred = (prob > threshold).astype(int)
    out = {
        "threshold": float(threshold),
        "f1": float(f1_score(label, pred, zero_division=0)),
        "auroc": float(roc_auc_score(label, prob)) if label.max() > 0 else 0.5,
    }
    per = {}
    for aid, name in enumerate(class_names):
        sel = atk == aid
        if sel.sum() == 0:
            continue
        pos = label[sel] > 0.5
        per[name] = {
            "f1": float(f1_score(label[sel], pred[sel], zero_division=0)),
            "fpr": float((pred[sel][~pos] == 1).mean()) if (~pos).sum() else 0.0,
            "n": int(sel.sum()),
        }
    out["per_attack"] = per
    return out


def calibrate_tau(model, loader, device, incidence, quantile):
    """Acceptance threshold for the feedback signal, from validation.

    We take the score the *best* expert reaches on each validation graph
    and use a quantile of that distribution: a candidate is accepted when
    it looks about as good as a typical good expert does.
    """
    model.eval()
    best = []
    with torch.no_grad():
        for raw in loader:
            b = to_device(raw, device)
            out = model(
                x_seq=b["x_seq"], edge_index=b["edge_index"],
                edge_attr=b["edge_attr"],
                is_original_edge=b["is_original_edge"],
                batch_size=b["batch_size"], num_nodes_per_graph=b["num_nodes"],
                pressure_obs=b["pressure_obs"], flow_obs=b["flow_obs"],
                pressure_mask=b["pressure_mask"], flow_mask=b["flow_mask"],
            )
            best.append(expert_feedback_scores(
                out, b, incidence).min(dim=-1).values.cpu())
    return float(np.quantile(torch.cat(best).numpy(), quantile))


def discover_final_runs(data_dir: str) -> list[Path]:
    """Every completed run of the paper's final configuration.

    Selecting from each run's own ``args.json`` avoids having to paste run
    directories on the command line, where a partially-written run can slip
    in while the training grid is still going.
    """
    out = []
    for d in sorted((ROOT / "runs" / "temporal_moe").glob("2026*")):
        ap = d / "args.json"
        if not (ap.exists() and (d / "best_model.pt").exists()
                and (d / "test_results.json").exists()):
            continue
        a = json.load(open(ap))
        # The full model: one expert per class present in the data, over a
        # 6-step window, with per-sensor normalisation, direct expert
        # supervision, pattern features and message passing. Matching
        # window_size==6 is essential -- the notemporal ablation shares
        # every other field but uses window_size==1, and mixing its
        # window-1 checkpoints into a window-6 routing study yields
        # garbage. num_experts is left free so the same selector works
        # whether or not replay is in the threat model.
        if (a.get("data_dir") == data_dir and a.get("epochs") == 60
                and a.get("num_experts", 0) > 1
                and a.get("window_size") == 6
                and a.get("lambda_expert") == 0.5
                and a.get("norm_mode") == "per_node"
                and not a.get("no_pattern_features")
                and not a.get("no_topology")):
            out.append(d)
    return out


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--data_dir", default="data/workshop_modena")
    p.add_argument("--runs", nargs="+", default=None,
                   help="Run directories. Omit to auto-select every "
                        "completed run of the final configuration.")
    p.add_argument("--out", default="runs/temporal_moe/workshop_routing.json")
    p.add_argument("--max_attempts", type=int, default=2)
    p.add_argument("--tau_quantile", type=float, default=0.7)
    args = p.parse_args()

    device = torch.device("mps" if torch.backends.mps.is_available() else "cpu")
    data_dir = ROOT / args.data_dir

    runs = args.runs or discover_final_runs(args.data_dir)
    if not args.runs:
        print(f"Auto-selected {len(runs)} runs of the final configuration")

    results = []
    class_names = []
    loaders = None
    for run in runs:
        run = Path(run)
        ck, ap = run / "best_model.pt", run / "args.json"
        if not (ck.exists() and ap.exists()):
            print(f"  skip {run.name}: incomplete run")
            continue
        a = json.load(open(ap))

        if loaders is None:
            (train_l, val_l, test_l, norm), graph, class_names = load_split(
                data_dir, a["window_size"], a["batch_size"], a["norm_mode"])
            incidence = torch.tensor(graph.incidence_matrix,
                                     dtype=torch.float32).to(device)
            sample = test_l.dataset[0]
            loaders = True

        model = TemporalMixtureOfExpertsGNN(
            node_in_dim=sample["x_seq"][0].shape[1],
            edge_in_dim=sample["edge_attr"].shape[1],
            hidden_dim=a["hidden_dim"], num_experts=a["num_experts"],
            window_size=a["window_size"], gnn_type=a["gnn_type"],
            router_hidden_dim=a["router_hidden_dim"],
            use_pattern_features=not a.get("no_pattern_features", False),
        ).to(device)
        model.load_state_dict(torch.load(ck, map_location=device))

        tau = calibrate_tau(model, val_l, device, incidence, args.tau_quantile)
        # Thresholds come from validation, then are applied to test.
        v_var, v_lab, _, _ = collect(
            model, val_l, device, incidence, tau, args.max_attempts)
        thr = {k: best_threshold(lg, v_lab) for k, lg in v_var.items()}

        variants, lab, atk, diag = collect(
            model, test_l, device, incidence, tau, args.max_attempts)
        r = {
            "run": run.name,
            "seed": a.get("seed"),
            "tau": tau,
            **{k: metrics(lg, lab, atk, class_names, thr[k])
               for k, lg in variants.items()},
            "diagnostics": {
                "mean_attempts": float(diag["n_attempts"].mean()),
                "accepted_first_rate": float(diag["accepted_first"].mean()),
                "attempts_hist": np.bincount(
                    diag["n_attempts"],
                    minlength=args.max_attempts + 1).tolist(),
                "cascade_matches_true": float(
                    (diag["chosen"] == diag["true"]).mean()),
                "router_top1_acc": float(
                    (diag["top1"] == diag["true"]).mean()),
                # Rows = true class, columns = expert the router picked.
                "router_confusion": np.bincount(
                    diag["true"] * len(class_names) + diag["top1"],
                    minlength=len(class_names) ** 2,
                ).reshape(len(class_names), len(class_names)).tolist(),
            },
        }
        results.append(r)
        print(f"  {run.name} seed={r['seed']}  soft={r['soft']['f1']:.3f}  "
              f"top1={r['router_top1']['f1']:.3f}  "
              f"cascade={r['cascade']['f1']:.3f}  "
              f"oracle={r['oracle']['f1']:.3f}")

    out = ROOT / args.out
    out.parent.mkdir(parents=True, exist_ok=True)
    json.dump({"class_names": class_names, "runs": results},
              open(out, "w"), indent=2)

    if results:
        print(f"\n  {'scheme':<14}{'F1 mean':>10}{'std':>8}")
        for k in ("soft", "router_top1", "cascade", "oracle"):
            v = [r[k]["f1"] for r in results]
            print(f"  {k:<14}{np.mean(v):>10.3f}{np.std(v, ddof=1):>8.3f}")
    print(f"\nWrote {out}")


if __name__ == "__main__":
    main()
