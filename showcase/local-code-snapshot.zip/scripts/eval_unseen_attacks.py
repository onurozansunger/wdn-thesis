"""Generalisation to attack families that were never trained on.

The attacks in the training distribution come from our own generative
process, so strong in-distribution numbers risk being circular: the
detector may only have learned the quirks of that generator. This script
tests the detector on perturbations it has never seen, injected into
otherwise *clean* test windows so the label is unambiguous.

Three unseen families:
    sinusoidal   a periodic signal added to the reported value; no
                 training family is oscillatory
    swap         two sensors exchange their readings; each value stays
                 individually plausible and only the pairing is wrong
    slowdrift    a drift an order of magnitude slower than the stealthy
                 family seen in training -- the same attack type pushed
                 outside its trained parameter range

Usage:
    python3 scripts/eval_unseen_attacks.py --data_dir data/v2_modena
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch
from sklearn.metrics import f1_score, roc_auc_score

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))

from wdn.models.temporal_moe import TemporalMixtureOfExpertsGNN
from eval_workshop_routing import load_split, to_device, _sigmoid

# Column layout of x_seq rows: [...static(5), pressure_obs, mask]
COL_P, COL_M = -2, -1


def inject(batch, kind, k, rng):
    """Apply an unseen attack to k sensors of every graph in the batch.

    Only windows that carry no training attack are perturbed, so every
    positive label in the returned batch comes from the unseen family.
    """
    x = [t.clone() for t in batch["x_seq"]]
    B, N, T = batch["batch_size"], batch["num_nodes"], len(batch["x_seq"])
    anom = torch.zeros_like(batch["pressure_anomaly"])

    for b in range(B):
        off = b * N
        sensors = rng.choice(N, size=k, replace=False)

        if kind == "sinusoidal":
            omega, amp = 2 * np.pi / T, 1.5
            for s in sensors:
                phi = rng.uniform(0, 2 * np.pi)
                for t in range(T):
                    x[t][off + s, COL_P] += float(amp * np.sin(omega * t + phi))
                    x[t][off + s, COL_M] = 1.0
                anom[off + s] = 1.0

        elif kind == "swap":
            pairs = sensors[: 2 * (len(sensors) // 2)]
            for i in range(0, len(pairs), 2):
                a, c = pairs[i], pairs[i + 1]
                va = x[-1][off + a, COL_P].clone()
                vc = x[-1][off + c, COL_P].clone()
                x[-1][off + a, COL_P], x[-1][off + c, COL_P] = vc, va
                x[-1][off + a, COL_M] = x[-1][off + c, COL_M] = 1.0
                anom[off + a] = anom[off + c] = 1.0

        elif kind == "slowdrift":
            # Drift ~10x slower than the trained stealthy family, applied
            # linearly across the window.
            for s in sensors:
                rate = rng.uniform(0.02, 0.06)
                for t in range(T):
                    x[t][off + s, COL_P] += float(rate * t)
                    x[t][off + s, COL_M] = 1.0
                anom[off + s] = 1.0
        else:
            raise ValueError(kind)

    out = {**batch, "x_seq": x,
           "pressure_obs": x[-1][:, COL_P],
           "pressure_mask": x[-1][:, COL_M],
           "pressure_anomaly": anom}
    return out


@torch.no_grad()
def run(model, loader, device, kind, k, seed, clean_id=0):
    """Score the detector on unseen attacks injected into clean windows."""
    model.eval()
    rng = np.random.default_rng(seed)
    S, Y = [], []
    for raw in loader:
        # Restrict to windows with no training attack.
        keep = (raw["attack_type"] == clean_id).nonzero(as_tuple=True)[0]
        if keep.numel() == 0:
            continue
        N = raw["num_nodes"]
        sub = {k2: v for k2, v in raw.items()}
        node_idx = torch.cat([torch.arange(i * N, (i + 1) * N) for i in keep])
        sub["x_seq"] = [t[node_idx] for t in raw["x_seq"]]
        for f in ("pressure_obs", "pressure_mask", "pressure_anomaly",
                  "y_pressure"):
            sub[f] = raw[f][node_idx]
        sub["batch_size"] = int(keep.numel())
        # Edges: reuse the first graph's block, tiled for the kept graphs.
        E = raw["edge_index"].shape[1] // raw["batch_size"]
        eidx, eattr, eorig = [], [], []
        for j, g in enumerate(keep.tolist()):
            e = raw["edge_index"][:, g * E:(g + 1) * E] - g * N + j * N
            eidx.append(e)
            eattr.append(raw["edge_attr"][g * E:(g + 1) * E])
            eorig.append(raw["is_original_edge"][g * E:(g + 1) * E])
        sub["edge_index"] = torch.cat(eidx, 1)
        sub["edge_attr"] = torch.cat(eattr, 0)
        sub["is_original_edge"] = torch.cat(eorig, 0)
        NE = raw["flow_obs"].shape[0] // raw["batch_size"]
        fidx = torch.cat([torch.arange(g * NE, (g + 1) * NE) for g in keep])
        for f in ("flow_obs", "flow_mask", "y_flow", "flow_anomaly"):
            sub[f] = raw[f][fidx]

        b = to_device(inject(sub, kind, k, rng), device)
        out = model(
            x_seq=b["x_seq"], edge_index=b["edge_index"],
            edge_attr=b["edge_attr"], is_original_edge=b["is_original_edge"],
            batch_size=b["batch_size"], num_nodes_per_graph=b["num_nodes"],
            pressure_obs=b["pressure_obs"], flow_obs=b["flow_obs"],
            pressure_mask=b["pressure_mask"], flow_mask=b["flow_mask"],
        )
        m = b["pressure_mask"] > 0
        S.append(torch.sigmoid(out["pressure_anomaly_logits"][m]).cpu())
        Y.append(b["pressure_anomaly"][m].cpu())

    s = torch.cat(S).numpy()
    y = torch.cat(Y).numpy()
    return s, y


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data_dir", default="data/v2_modena")
    ap.add_argument("--tag", default="md_final")
    ap.add_argument("--k", type=int, default=20)
    ap.add_argument("--max_runs", type=int, default=10)
    ap.add_argument("--out", default=None)
    args = ap.parse_args()

    device = torch.device("mps" if torch.backends.mps.is_available() else "cpu")

    runs = []
    for d in sorted((ROOT / "runs" / "temporal_moe").glob("2026*")):
        ap_, tp = d / "args.json", d / "test_results.json"
        if not (ap_.exists() and tp.exists() and (d / "best_model.pt").exists()):
            continue
        a = json.load(open(ap_))
        if (a.get("data_dir") == args.data_dir and a.get("epochs") == 60
                and a.get("window_size") == 6 and a.get("num_experts", 0) > 1
                and a.get("norm_mode") == "per_node"
                and a.get("lambda_expert") == 0.5
                and not a.get("no_pattern_features")
                and not a.get("no_topology")):
            runs.append((d, a))
    runs = runs[: args.max_runs]
    print(f"Evaluating {len(runs)} checkpoints on unseen attacks")
    if not runs:
        raise SystemExit("no checkpoints yet for " + args.data_dir)

    loaders = None
    res = {k: [] for k in ("sinusoidal", "swap", "slowdrift")}
    for d, a in runs:
        if loaders is None:
            (tr, va, te, nm), graph, names = load_split(
                ROOT / args.data_dir, a["window_size"], a["batch_size"],
                a["norm_mode"])
            sample = te.dataset[0]
            loaders = True
        model = TemporalMixtureOfExpertsGNN(
            node_in_dim=sample["x_seq"][0].shape[1],
            edge_in_dim=sample["edge_attr"].shape[1],
            hidden_dim=a["hidden_dim"], num_experts=a["num_experts"],
            window_size=a["window_size"], gnn_type=a["gnn_type"],
            router_hidden_dim=a["router_hidden_dim"],
        ).to(device)
        model.load_state_dict(torch.load(d / "best_model.pt",
                                         map_location=device))
        thr = json.load(open(d / "test_results.json")).get("threshold", 0.5)

        for kind in res:
            s, y = run(model, te, device, kind, args.k, a["seed"])
            res[kind].append({
                "seed": a["seed"],
                "f1": float(f1_score(y, (s > thr).astype(int), zero_division=0)),
                "auroc": float(roc_auc_score(y, s)) if y.max() > 0 else 0.5,
                "recall": float(((s > thr) & (y > 0.5)).sum() / max((y > 0.5).sum(), 1)),
            })

    print(f"\n  {'family':<12}{'F1':>16}{'AUROC':>16}{'recall':>10}")
    summary = {}
    for kind, rr in res.items():
        f = np.array([x["f1"] for x in rr])
        au = np.array([x["auroc"] for x in rr])
        rc = np.array([x["recall"] for x in rr])
        summary[kind] = {"f1_mean": f.mean(), "f1_std": f.std(ddof=1) if len(f) > 1 else 0.0,
                         "auroc_mean": au.mean(), "recall_mean": rc.mean(),
                         "n_seeds": len(rr)}
        print(f"  {kind:<12}{f.mean():>9.3f}+-{f.std(ddof=1) if len(f)>1 else 0:.3f}"
              f"{au.mean():>13.3f}{rc.mean():>13.3f}")

    out = ROOT / (args.out or
                  f"runs/temporal_moe/unseen_{Path(args.data_dir).name}.json")
    json.dump({"data_dir": args.data_dir, "k": args.k,
               "summary": summary, "runs": res}, open(out, "w"), indent=2)
    print(f"\nWrote {out}")


if __name__ == "__main__":
    main()
