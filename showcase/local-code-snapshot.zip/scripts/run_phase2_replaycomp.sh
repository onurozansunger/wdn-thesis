#!/usr/bin/env bash
# Phase 2.1: do the replay-specific components pay once replay is
# detectable? VI-D asserts they fail at conventional settings because
# replay is undetectable there; that explanation is untested. The
# near-threshold regime has delta/sigma = 4.9, where Table IX shows replay
# IS detectable, so the same ablation there tests the assertion directly.
set -u
ROOT="/Users/ozanbabac5/wdn_thesis"; cd "$ROOT"; export PYTHONPATH=src
LOG="/tmp/wdn_pilot"; mkdir -p "$LOG"
B="--data_dir data/hard_modena --gnn_type GraphSAGE --hidden_dim 64 \
   --router_hidden_dim 24 --epochs 60 --batch_size 8 --lr 0.001 --window_size 6"
for s in $(seq 1 10); do
  for c in globalnorm nopattern; do
    tag="hard_${c}_s${s}"; [ -f "$LOG/$tag.done" ] && continue
    case $c in
      globalnorm) X="--norm_mode global" ;;
      nopattern)  X="--norm_mode per_node --no_pattern_features" ;;
    esac
    echo "[p2.1] $(date +%H:%M:%S) $tag"
    PYTHONUNBUFFERED=1 python3 -u -m wdn.train_temporal_moe $B $X --seed $s \
        > "$LOG/$tag.log" 2>&1 && touch "$LOG/$tag.done"
  done
done
echo "[p2.1] ALL DONE $(date +%H:%M:%S)"
