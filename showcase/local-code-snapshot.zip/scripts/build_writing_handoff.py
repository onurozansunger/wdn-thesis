"""Build writing indexes from existing evidence; never run model evaluation."""
from pathlib import Path
import json
import os

ROOT = Path(__file__).resolve().parents[1]
W = ROOT / 'TEZ_YAZIMI'
A = ROOT / 'archive/2026-09-08-writing-handoff'
FINAL = ROOT / 'runs/operational/early_warning_multiseed_v1/final_ten_model_seeds_v1'


def write(relative, content):
    p = ROOT / relative
    assert not p.is_symlink(), f'Do not modify archived evidence: {p}'
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content.rstrip() + '\n')


def link(path, target):
    target = ROOT / target
    assert target.exists(), target
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_symlink():
        assert path.resolve() == target.resolve(), path
    else:
        assert not path.exists(), path
        path.symlink_to(os.path.relpath(target, path.parent), target_is_directory=target.is_dir())


def main():
    sources = [
        ('01_ilk_tez', 'thesis', 'GraphSAGE–GRU ve altı uzman: eski taslak, şekiller ve ilk araştırma soruları.'),
        ('02_episode_ablation', 'thesis_v2/evidence/episode_ablation', '40 model-seed koşusunun args/results kayıtları; tek veri kümesi sınırlaması.'),
        ('03_tarihsel_iddialar.md', str((A/'thesis_v2/CLAIMS_LEDGER.md').relative_to(ROOT)), 'Önceki kabul ve retler; özellikle self-play iddiasının sınırı.'),
        ('04_benchmark_workshop', 'thesis/workshop', 'Konvansiyonel/near-threshold ve pre-noise/recorded replay araştırması; numbers.json ve LaTeX tabloları.'),
        ('05_eski_reproduction.md', str((A/'REPRODUCE.md').relative_to(ROOT)), 'Eski benchmark konfigürasyonları, seed listeleri ve sonuç üretici scriptleri.'),
        ('06_detectability', 'thesis_v2/evidence/existing', 'Detectability ve magnitude-matched deney JSON kayıtları; eski rejim kanıtı.'),
        ('07_episode_protokolu.md', 'thesis_v2/EXPERIMENT_PROTOCOL.md', 'Episode ve IID kontrolünün özgün protokolü; son benchmark protokolünden ayrı.'),
        ('08_spatial_temporal.md', 'thesis_v2/outputs/tables/spatiotemporal_confirmation.md', 'İki ağda eşlenmiş spatial/temporal karşılaştırması.'),
        ('09_moe.md', 'thesis_v2/outputs/tables/modena_moe_confirmation.md', 'Modena MoE katkısı; kendi veri ve model-seed tasarımı.'),
        ('10_iid_kontrol.md', 'thesis_v2/outputs/tables/modena_iid_control.md', 'Temporal katkıyı episode persistence ile ilişkilendiren negatif kontrol.'),
        ('11_modena_topology.md', 'thesis_v2/outputs/tables/modena_topology_confirmation.md', 'Modena topology-aware/topology-free kontrolü.'),
        ('12_ltown_topology.md', 'thesis_v2/outputs/tables/ltown_topology_confirmation.md', 'L-Town topology-aware/topology-free kontrolü.'),
        ('13_operasyonel_gelisim.md', 'thesis_v2/ALL_FAMILIES_080_RESULTS.md', 'Residual uzmanlar, gecikme ve aile korumaları yönündeki tarihsel ilerleme.'),
        ('14_uc_dal_protokolu.md', 'thesis_v2/EARLY_WARNING_MULTISEED_PROTOCOL.md', 'General/Drift/Noise aşaması ve değerlendirme protokolü.'),
        ('15_uc_dal_sonuclari.md', 'thesis_v2/EARLY_WARNING_MULTISEED_RESULTS.md', 'Stage-E ve önceki değerlendirmeler; son on-seed tablonun yerine geçmez.'),
        ('16_router.md', 'thesis_v2/ROUTER_RECALIBRATION_RESULTS.md', 'Router 0.6461→0.6757 ve yanlış-alarm bütçesi negatif sonucu.'),
        ('17_reddedilen_residual_history.md', 'thesis_v2/SHARED_HISTORY_PILOT.md', '56 ek residual-history özelliği: TRAIN tanılamasında reddedilen aday.'),
        ('18_received_history_pilot.md', 'thesis_v2/OBSERVED_HISTORY_PILOT.md', '42 received-pressure-history özelliği: ilk TRAIN pilotu, rounding kapsamı.'),
        ('19_history_train_tekrari.md', 'thesis_v2/outputs/tables/ltown_observed_history_train_replication.md', 'Replay kazanımının tekrarı ve noise-protection başarısızlığı.'),
        ('20_korumali_history_protokolu.md', 'thesis_v2/experiments/early_warning/PROTECTED_HISTORY_SYSTEM.md', 'Ayrı tam-sistem geliştirme protokolü; full/selective seçim ve fresh-confirmation korumaları.'),
        ('21_history_confirmation.md', 'thesis_v2/outputs/tables/ltown_protected_history_confirmation.md', '5 seed × 6 yeni source ile history confirmation; eşlenmiş baseline 0.706383.'),
        ('22_trajectory.md', 'thesis_v2/outputs/tables/ltown_received_trajectory_experiment.md', 'Trajectory/hard-negative geliştirme; nihai model değildir.'),
        ('23_flow_fusion.md', 'thesis_v2/outputs/tables/ltown_flow_fusion_experiment.md', 'Korunan kalibrasyon noktası bulunamayan adaylar.'),
        ('24_joint.md', 'thesis_v2/outputs/tables/ltown_received_joint_075.md', 'Joint adayın sınırlı kalibrasyon kazanımı ve confirmation-readiness başarısızlığı.'),
        ('25_son_rapor.md', 'thesis_v2/outputs/tables/final_modena_ltown_ten_model_seeds.md', 'Yazımda kullanılacak son on-model-seed raporu.'),
    ]
    lines = ['# Kanıt haritası', '', 'Bu harita gelişim öyküsünün kaynaklarını bir araya getirir. Geçmiş raporlar kendi deney kapsamlarında geçerlidir; tarihsel metinlerdeki “current/final/deployed” ifadeleri bugünkü model seçimini belirlemez.', '', '| Kanıt | Özgün konum | Yazımdaki rolü |', '|---|---|---|']
    for name, target, role in sources:
        link(W/'kanitlar'/name, target)
        lines.append(f'| [{name}](kanitlar/{name}) | `{target}` | {role} |')
    lines += ['', '## Kod ve ham kanıtı bulma', '',
              '- İlk mimari: `src/wdn/models/temporal_multitask.py`, `temporal_moe.py`; altı uzman tanımı ve GRU/GraphSAGE bileşenleri. Tarihsel sonuçları bugünkü kodla yeniden üretmeden önce ilgili run args ve sürüm bilgisi kontrol edilmeli.',
              '- Workshop sayıları: `thesis/workshop/numbers.json`, `thesis/workshop/tables/`, `scripts/build_v2_results.py`; konfigürasyonlar `configs/` altında.',
              '- Kontrollü mimari deneyleri: `thesis_v2/experiments/build_spatiotemporal_report.py`, `build_moe_confirmation_report.py`, `build_topology_confirmation_report.py`; kaynak çalışma kayıtları `thesis_v2/outputs/runs/` altında.',
              '- Operasyonel üç dal: `thesis_v2/experiments/early_warning/run_campaign.py`; `src/wdn/reliable_general_mixture.py`, `src/wdn/observed_history.py` ve delay/router/feedback modülleri.',
              '- Replay geliştirme: `runs/operational/early_warning_multiseed_v1/` altındaki `shared_history_pilot_v1`, `observed_history_pilot_v1`, `observed_history_replication_v1`, `protected_history_system_v1`.',
              '- Son model: `nihai_kanit/final_artifact_audit.json` her model ve seçilmiş kural için tam yol ve SHA-256 içerir. `final_results.json` bütün model/source sonuçlarını ve dağılım özetlerini içerir.',
              '', '## Teze aktarılmaması gereken karışıklıklar', '',
              '- 0.7432 TRAIN pilotu ve 0.7826 internal replay component skoru, bağımsız tam-sistem skoru değildir.',
              '- Önceki 0.6757 ile yeni 0.7303 farklı confirmation kaynaklarına aittir; aralarındaki fark tek başına eşlenmiş etki değildir.',
              '- `accepted_modena_ltown_results_20260908.md` eski joint kabul kaydıdır. Son seçim için `final_design_selection.json` ve on-seed rapor esas alınır.',
              '- Önceki modellerin düşük F1 değerleri ile son sistemin F1 değerleri, rejim/split/bilgi bütçesi eşitliği gösterilmeden mimari üstünlük kanıtı olarak çıkarılamaz.',
              '- Başarısız noise koruması, başarısız calibration kapısı veya hedefin karşılanmaması silinmez. Sonuç ve karar birlikte anlatılır.']
    write('TEZ_YAZIMI/KANIT_HARITASI.md', '\n'.join(lines))
    link(W/'manuscript', 'thesis_v2/manuscript')
    for p in ['final_results.json', 'final_artifact_audit.json', 'final_design_selection.json',
              'protocol_frozen.json', 'evaluation_frozen.json', 'input_audit.json']:
        link(W/'nihai_kanit'/p, str((FINAL/p).relative_to(ROOT)))

    data = json.loads((FINAL/'final_results.json').read_text())
    audit = json.loads((FINAL/'final_artifact_audit.json').read_text())
    assert data['status'] == 'finalized' and audit['status'] == 'verified'
    families = ('random', 'replay', 'drift', 'noise', 'targeted')
    rows = ['# Nihai tez sonuçları — 10 model seed', '',
            'Son seçim: **Modena confirmed Stage-E** ve **L-Town confirmed full received-pressure-history**. Bu belge özgün `final_results.json` üzerinden üretilmiştir; modeller veya eşikler değiştirilmedi.', '',
            '| Metrik | Modena | L-Town history |', '|---|---:|---:|']
    for metric in (*families, 'family_macro_f1', 'pooled_f1', 'clean_fpr'):
        values = []
        for n in ('modena', 'ltown'):
            m = data['networks'][n]['mean']
            values.append(sum(m[f] for f in families)/5 if metric == 'family_macro_f1' else m[metric])
        rows.append(f'| {metric} | {values[0]:.6f} | {values[1]:.6f} |')
    rows += ['', 'F1 değerleri 0–1 ölçeğinde; clean FPR bir orandır ve düşük olması iyidir. Family macro F1 beş aileyi eşit ağırlıklandırır. Pooled F1, her değerlendirme hücresindeki toplu kararlardan hesaplanır ve ardından 60 hücre üzerinde ortalanır.', '',
             '- Model seed: 701–710; her ağda aynı altı source; toplam 60 model/source hücresi. Bunlar 60 bağımsız veri kümesi veya bir ensemble değildir.',
             '- Son beş model seed özgün confirmation kaynakları üzerinde değerlendirilmiştir. Bu, mevcut confirmation deneyinin model rastgeleliğine karşı genişletmesidir; yeni bağımsız confirmation değildir.',
             '- Modena bütün aile ortalamaları 0.80 üzerinde. L-Town replay 0.731161 ile 0.75 hedefinin altında; diğer aile ortalamaları 0.80 üzerinde. Ortalamalar her koşunun hedefi geçtiği anlamına gelmez.',
             '- L-Town history, kendi eşlenmiş no-history karşılaştırmasında replay için 60/60 kazanım göstermiştir; ortalama replay farkı +0.024681, pooled F1 farkı +0.008826. Aile/source/yanlış-alarm korumaları denetimde geçmiştir.',
             '- General / Drift / Noise; General içinde beş ağaç altmodeli. L-Town General: 42 received-pressure-history özelliği, toplam 158 girdi. Drift/Noise için üç saat karar gecikmesi.',
             '- Pressure ve flow missingness 0.50; severity, dağılım ve split değişmedi. Locked test okunmadı. Bu finalizasyon bir üretim deployment işlemi değildir.', '',
             '[Tam sonuçlar](nihai_kanit/final_results.json) · [Denetim ve model indeksi](nihai_kanit/final_artifact_audit.json) · [Son tasarım seçimi](nihai_kanit/final_design_selection.json)', '',
             'Yeniden üretim: `/opt/miniconda3/bin/python scripts/build_writing_handoff.py`. Bu komut yalnızca kayıtlı raporlardan yazım indekslerini oluşturur; eğitim, kalibrasyon veya evaluation çalıştırmaz.']
    write('TEZ_YAZIMI/NIHAI_SONUCLAR.md', '\n'.join(rows))

    write('README.md', '''# Water distribution network sensor-attack detection — tez yazım aşaması

**Başlangıç: [TEZ_YAZIMI](TEZ_YAZIMI/README.md).** Deneylerin gelişim çizgisi ve nihai on-seed sonuçları burada düzenlendi.

- [Araştırma hikâyesi](TEZ_YAZIMI/ARASTIRMA_HIKAYESI.md): GraphSAGE/GRU ve altı uzman → benchmark/replay teşhisi → korumalı üç dallı mimari.
- [Nihai sonuçlar](TEZ_YAZIMI/NIHAI_SONUCLAR.md): Modena confirmed ve L-Town confirmed history; her ağda 10 model seed × 6 source.
- [Kanıt haritası](TEZ_YAZIMI/KANIT_HARITASI.md) ve [yazım planı](TEZ_YAZIMI/YAZIM_PLANI.md).
- LaTeX çalışma kaynağı: `thesis_v2/manuscript/` (`TEZ_YAZIMI/manuscript` aynı klasöre bağlanır). Mevcut taslak henüz son mimariye uyarlanmadı.
- [Arşiv](archive/2026-09-08-writing-handoff/README.md): eski tez, workshop, sunumlar, notlar, geçici materyaller. `thesis/` artık arşivlenmiş ilk teze uyumluluk bağlantısıdır.

`src/`, `configs/`, `data/`, `runs/`, `tests/`, `scripts/` ve `thesis_v2/experiments/` teknik kanıttır; özgün yollarında korundu. Sonuçları yeniden ayarlamak için yeni deney başlatılmadı. Hiçbir eski dosya silinmedi.

Son L-Town replay F1 **0.7312**; 0.75 hedefi karşılanmadı. Eski README'deki self-play ve farklı benchmark sonuçları tarihsel içeriktir; son modelin sonucu değildir.
''')
    write('REPRODUCE.md', '''# Yazım ve sonuç kaynakları

Sonuçların tek kaynağı `runs/operational/early_warning_multiseed_v1/final_ten_model_seeds_v1/final_results.json` dosyasıdır. Model, veri ve kod denetimi aynı klasördeki `final_artifact_audit.json` içindedir.

Yalnızca yazım indekslerini ve son tabloyu kayıtlı sonuçlardan üretmek için:

```sh
/opt/miniconda3/bin/python scripts/build_writing_handoff.py
```

Tez kaynakları henüz son gelişim hikâyesine göre yeniden yazılmadı. Daha sonra derlemek için:

```sh
cd thesis_v2/manuscript
latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
```

Eski benchmark üretimi, eğitim ve workshop tablolarının özgün komutları [arşivdeki REPRODUCE.md](archive/2026-09-08-writing-handoff/REPRODUCE.md) içinde aynen korunmuştur. Bu komutlar geçmiş protokole aittir; yazım düzenlemesi onları çalıştırmadı. Dondurulmuş son doğrulama verileri yeni tasarım seçimi için kullanılmamalıdır.
''')
    write('thesis_v2/README.md', '''# Tez kaynakları ve deney kanıtı

Güncel yazım başlangıcı: [TEZ_YAZIMI](../TEZ_YAZIMI/README.md).

- `manuscript/`: İngilizce LaTeX taslağı; önceki mimari aşamasını anlatan metin korunmuştur ve son yönteme uyarlanacaktır.
- `experiments/`, `evidence/`, `outputs/`: kaynak kodu, geçmiş deney kanıtları ve son sonuçlar; özgün yollarında korundu.
- Üst düzey eski protokol ve rapor adları arşivdeki özgün dosyalara uyumluluk bağlantısıdır. Tarihsel içeriklerini güncel karar gibi okumayın veya düzenlemeyin.
- [Sonuçlar](../TEZ_YAZIMI/NIHAI_SONUCLAR.md), [araştırma hikâyesi](../TEZ_YAZIMI/ARASTIRMA_HIKAYESI.md), [kanıt haritası](../TEZ_YAZIMI/KANIT_HARITASI.md).

Eski README, planlar ve sunumlar [arşivde](../archive/2026-09-08-writing-handoff/README.md) korunmuştur. Yeni dosya düzeni hiçbir deney sonucunu veya frozen protocol'u değiştirmedi.
''')
    write('thesis_v2/STATUS.md', '''# Durum — 8 Eylül 2026

Deney aşaması tamamlandı; tez yazımına geçildi. Modena confirmed Stage-E ve L-Town confirmed pressure-history için model seed'leri 701–710 tamamlandı; son artifact audit geçti.

Sonuç kaynağı ve sınırlar: [NIHAI_SONUCLAR.md](../TEZ_YAZIMI/NIHAI_SONUCLAR.md).

Güncel iş: [yazım planı](../TEZ_YAZIMI/YAZIM_PLANI.md) doğrultusunda gelişim öyküsünü ve son mimariyi mevcut LaTeX taslağına geçirmek. Bu klasör düzenlemesi tam tez yeniden yazımı değildir. Yeni deney veya deployment başlatılmadı.

Eski status belgesi arşivde korunmuştur.
''')
    write('thesis_v2/CLAIMS_LEDGER.md', '''# Güncel yazım iddiaları

| İddia | Durum / kapsam | Kanıt |
|---|---|---|
| Son yöntem General, Drift ve Noise dallarına sahiptir; General içinde beş altmodel bulunur. | Son seçilmiş mimari; önceki altı GRU uzmanından ayrı. | Final protocol ve model artifact audit. |
| Her ağ için 10 model seed ve 6 source sonucu tamamlandı. | Doğrulandı; 60 bağımsız veri kümesi değildir. | `TEZ_YAZIMI/nihai_kanit/final_results.json`. |
| L-Town history replay'i diğer aileleri ve yanlış alarmları koruyarak iyileştirir. | Son eşlenmiş benchmark karşılaştırmasında 60/60 replay kazanımı; korumalar geçti. | `final_artifact_audit.json`, `final_results.json`. |
| L-Town replay 0.75 veya 0.80 hedefine ulaştı. | Desteklenmiyor; son ortalama 0.731161. | Nihai sonuçlar. |
| Son sistemin bütün aile ortalamaları iki ağda da 0.80 üzerindedir. | Yanlış: L-Town replay istisnadır. | Nihai sonuçlar. |
| Son model, eski GraphSAGE–GRU modelinden yalnızca mimarisi sayesinde daha iyidir. | Aynı rejim/bilgi bütçesiyle doğrudan karşılaştırma olmadan desteklenmiyor. | Tarihsel deneyler ayrı raporlanacak. |
| Son model saha deployment performansı veya yeni bağımsız on-seed confirmation ile doğrulandı. | Desteklenmiyor; simülasyon, mevcut altı source üzerinde model-seed genişletmesi, deployment yok. | Frozen protocol ve final audit. |

Eski topology/GRU/MoE iddiaları ve self-play retleri [tarihsel ledger](../archive/2026-09-08-writing-handoff/thesis_v2/CLAIMS_LEDGER.md) içinde aynen korunmuştur. Bunlar yalnızca özgün deney kapsamlarıyla kullanılacaktır.
''')
    # Historical scripts using __file__.resolve().parents see an equivalent root.
    for name in ['src', 'scripts', 'configs', 'data', 'runs', 'figures', 'refs', 'output']:
        link(A/name, name)
    for name in ['experiments', 'outputs', 'evidence', 'manuscript']:
        link(A/'thesis_v2'/name, f'thesis_v2/{name}')
    write(str((A/'README.md').relative_to(ROOT)), '''# Silinmeden korunan araştırma arşivi

8 Eylül 2026 yazım geçişinde eski tez, workshop sürümleri, sunumlar, teslim paketleri, eski üst düzey notlar ve geçici çalışma dosyaları buraya taşındı. Başarısız deney raporları da korundu. Hiçbir dosya silinmedi.

Yeni çalışma alanı: [TEZ_YAZIMI](../../TEZ_YAZIMI/README.md).

- `thesis/`: ilk tez, workshop/Overleaf varyantları ve eski görseller.
- `thesis_v2/`: önceki protokol, plan, sonuç ve handoff notları; eski sunumlar.
- `results_package/`, ZIP dosyaları: geçmiş teslim paketleri.
- `tmp/`, `.codex_tmp/`, `.pytest_cache/`, `temp.*`: kullanılmayan geçici çalışma materyalleri; silinmedi.
- `README.md` dışındaki kök README/REPRODUCE tarihçesi: özgün proje README'si `README.original.md` içinde, eski reproduction `REPRODUCE.md` içinde korunur.

Bazı özgün yollar sembolik bağlantıyla bu arşive yönlenir. Arşivdeki `data`, `runs`, `src` vb. bağlantılar ise büyük teknik kaynakların yerinde kalan tek kopyasına yönlenir. Bu bağlantılar yeni veri kopyası değildir; eski kodun göreli yollarını korur. Toplam disk kullanımı düşürülmedi.

`move_manifest.json` her taşınan/kopyalanan dosyanın önceki yolunu, arşiv yolunu, SHA-256 özetini ve byte boyutunu kaydeder. Manifestteki eski README yedeği daha sonra `README.original.md` olarak adlandırılmıştır. `verification.json` son doğrulamayı kaydeder.

Geri alma: manifestteki bir kaydın `original` yolundaki uyumluluk bağlantısını kaldırıp `archived` dosya/klasörünü o yola taşıyın. `backup_before_document_refresh` kayıtları güncellenen belgelerin eski içerikleridir; yeni belgeleri önce ayrıca koruyun. Yeni yazım dosyaları manifestin eski dosya kayıtlarına dahil değildir. Arşiv dokümanlarına düzenleme yapmak yerine güncel yazım alanında çalışın.
''')


if __name__ == '__main__':
    main()
