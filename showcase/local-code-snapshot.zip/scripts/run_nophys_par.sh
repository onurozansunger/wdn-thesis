#!/usr/bin/env bash
# Physics-free rebuild, four workers.
#
# The machine has 14 cores and a single run was using about half of one,
# so the sequential queue was leaving most of the box idle. Four workers
# with three threads each fit comfortably and cut the wall clock by
# roughly four.
#
# Reordered by value: the near-threshold cells carry the paper's largest
# effects, so they finish first and the conventional/recorded cell --
# whose pre-noise twin is already done without the term -- finishes last.
set -u
ROOT="/Users/ozanbabac5/wdn_thesis"; cd "$ROOT"; export PYTHONPATH=src
export OMP_NUM_THREADS=3 MKL_NUM_THREADS=3
LOG="/tmp/wdn_np"; mkdir -p "$LOG"
C="--gnn_type GraphSAGE --hidden_dim 64 --router_hidden_dim 24 --epochs 60 \
   --batch_size 8 --lr 0.001 --norm_mode per_node --lambda_physics 0"
job() {
  local D=$1 cfg=$2 s=$3
  local t="${D}_${cfg}_s${s}"; [ -f "$LOG/$t.done" ] && return
  local X
  case $cfg in
    final)      X="--window_size 6" ;;
    notopo)     X="--window_size 6 --no_topology" ;;
    notemporal) X="--window_size 1" ;;
    nomixture)  X="--window_size 6 --num_experts 1" ;;
  esac
  python3 -u -m wdn.train_temporal_moe $C --data_dir "data/$D" $X --seed $s \
      > "$LOG/$t.log" 2>&1 && touch "$LOG/$t.done"
}
export -f job; export LOG C ROOT
for D in rec_hard_modena hard_modena rec_modena; do
  for cfg in final notopo notemporal nomixture; do
    for s in 1 2 3 4 5 6 7 8 9 10; do echo "$D $cfg $s"; done
  done
done | xargs -P 4 -n 3 bash -c 'job "$0" "$1" "$2"'
echo "[np] ALL DONE $(date +%H:%M:%S)"
