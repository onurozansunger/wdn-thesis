"""Diagnose whether the label-free feedback signal is worth anything.

The headline claim is that a feedback check improves on plain top-1
routing. In the submitted numbers it does not: it re-routes 0.4% of
windows and gains 0.000 F1. Two hypotheses explain that, and they have
opposite consequences for the paper:

  H1  the *margin* is mis-set. Re-routing requires an alternative to beat
      the incumbent by 3.0 in a score that is z-scored across K=5 experts,
      where the largest possible z-score magnitude is (K-1)/sqrt(K)=1.79.
      The mechanism is then off by construction, and a calibrated margin
      would switch it on.
  H2  the feedback signal carries no usable information, in which case no
      margin helps and the contribution has to be re-framed.

This script separates them on already-trained checkpoints, with no
retraining, by scoring every routing rule from the same forward pass:

  top1            router argmax (the baseline to beat)
  cascade(m, A)   re-route within the router's top-A candidates when an
                  alternative's feedback beats the incumbent by margin m
  feedback_only   argmin of the feedback score over all K, router ignored
                  -- the direct test of whether the signal is informative
  oracle          expert owning the true class (ceiling)

It additionally reports the regime the mechanism was designed for, by
degrading the router at inference (temperature / logit noise) and
measuring the cascade's gain over top-1 as router accuracy falls.

Usage:
    python3 scripts/eval_cascade_diagnosis.py --data_dir data/workshop_modena
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch
from sklearn.metrics import f1_score

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))

from wdn.models.temporal_moe import (
    TemporalMixtureOfExpertsGNN, expert_feedback_scores,
)
from eval_workshop_routing import (
    load_split, to_device, discover_final_runs, best_threshold, _sigmoid,
)

MARGINS = [3.0, 1.0, 0.5, 0.25, 0.1, 0.0]
NOISE_LEVELS = [0.0, 0.5, 1.0, 2.0, 3.0, 5.0]


@torch.no_grad()
def gather(model, loader, device, incidence, noise=0.0, seed=0):
    """One forward pass per batch; return everything every rule needs.

    ``noise`` adds Gaussian perturbation to the router logits, which
    degrades routing accuracy without touching the experts -- the
    controlled way to ask what the feedback check is worth when the router
    is unreliable.
    """
    model.eval()
    g = torch.Generator(device="cpu").manual_seed(seed)
    A_logit, F_score, Rprob, Lab, Msk, True_c = [], [], [], [], [], []

    for raw in loader:
        b = to_device(raw, device)
        out = model(
            x_seq=b["x_seq"], edge_index=b["edge_index"],
            edge_attr=b["edge_attr"], is_original_edge=b["is_original_edge"],
            batch_size=b["batch_size"], num_nodes_per_graph=b["num_nodes"],
            pressure_obs=b["pressure_obs"], flow_obs=b["flow_obs"],
            pressure_mask=b["pressure_mask"], flow_mask=b["flow_mask"],
        )
        N = b["num_nodes"]
        stack = out["expert_pressure_anomaly_logits"]            # (B*N, K)
        B, K = b["batch_size"], stack.shape[-1]

        logits = out["router_logits"].cpu()
        if noise > 0:
            logits = logits + noise * torch.randn(
                logits.shape, generator=g)
        Rprob.append(torch.softmax(logits, dim=-1))

        F_score.append(expert_feedback_scores(out, b, incidence).cpu())
        A_logit.append(stack.view(B, N, K).cpu())
        Lab.append(b["pressure_anomaly"].view(B, N).cpu())
        Msk.append((b["pressure_mask"] > 0).view(B, N).cpu())
        True_c.append(b["attack_type"].cpu())

    return (torch.cat(A_logit), torch.cat(F_score), torch.cat(Rprob),
            torch.cat(Lab), torch.cat(Msk), torch.cat(True_c))


def pick_cascade(rprob, fscore, margin, max_attempts):
    """Router-anchored selection with a feedback override margin."""
    order = rprob.argsort(dim=-1, descending=True)
    G, K = rprob.shape
    n_try = min(max_attempts, K)
    chosen = order[:, 0].clone()
    cur = fscore.gather(1, chosen.unsqueeze(1)).squeeze(1)
    for k in range(1, n_try):
        cand = order[:, k]
        s = fscore.gather(1, cand.unsqueeze(1)).squeeze(1)
        better = s < cur - margin
        chosen = torch.where(better, cand, chosen)
        cur = torch.where(better, s, cur)
    return chosen


def score(alogit, sel, lab, msk, thr=None):
    """F1 of a per-graph expert selection, on observed sensors."""
    G, N, K = alogit.shape
    pick = alogit.gather(2, sel.view(G, 1, 1).expand(G, N, 1)).squeeze(2)
    p = _sigmoid(pick[msk].numpy())
    y = lab[msk].numpy()
    if thr is None:
        thr = best_threshold(np.log(p / (1 - p + 1e-12) + 1e-12), y)
    return float(f1_score(y, (p > thr).astype(int), zero_division=0)), thr


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data_dir", default="data/workshop_modena")
    ap.add_argument("--out", default="runs/temporal_moe/cascade_diagnosis.json")
    ap.add_argument("--max_runs", type=int, default=10)
    args = ap.parse_args()

    device = torch.device("mps" if torch.backends.mps.is_available() else "cpu")
    runs = discover_final_runs(args.data_dir)[: args.max_runs]
    print(f"Diagnosing {len(runs)} checkpoints")

    loaders = None
    results = []
    for run in runs:
        a = json.load(open(run / "args.json"))
        if loaders is None:
            (tr, va, te, nm), graph, class_names = load_split(
                ROOT / args.data_dir, a["window_size"], a["batch_size"],
                a["norm_mode"])
            incidence = torch.tensor(graph.incidence_matrix,
                                     dtype=torch.float32).to(device)
            sample = te.dataset[0]
            loaders = True

        model = TemporalMixtureOfExpertsGNN(
            node_in_dim=sample["x_seq"][0].shape[1],
            edge_in_dim=sample["edge_attr"].shape[1],
            hidden_dim=a["hidden_dim"], num_experts=a["num_experts"],
            window_size=a["window_size"], gnn_type=a["gnn_type"],
            router_hidden_dim=a["router_hidden_dim"],
        ).to(device)
        model.load_state_dict(torch.load(run / "best_model.pt",
                                         map_location=device))

        r = {"run": run.name, "seed": a["seed"], "margin_sweep": {},
             "router_degradation": {}}

        # ---- clean router: does any margin switch the mechanism on? ----
        al, fs, rp, lab, msk, tc = gather(model, te, device, incidence)
        K = rp.shape[-1]
        top1 = rp.argmax(dim=-1)
        f_top1, thr = score(al, top1, lab, msk)
        f_oracle, _ = score(al, tc.clamp(max=K - 1), lab, msk, thr)
        f_fb, _ = score(al, fs.argmin(dim=-1), lab, msk, thr)
        r["top1"] = f_top1
        r["oracle"] = f_oracle
        r["feedback_only"] = f_fb
        r["router_acc"] = float((top1 == tc).float().mean())
        r["feedback_acc"] = float((fs.argmin(dim=-1) == tc).float().mean())

        for A in (2, K):
            for m in MARGINS:
                sel = pick_cascade(rp, fs, m, A)
                f, _ = score(al, sel, lab, msk, thr)
                r["margin_sweep"][f"A{A}_m{m}"] = {
                    "f1": f, "gain_vs_top1": f - f_top1,
                    "reroute_rate": float((sel != top1).float().mean())}

        # ---- degraded router: the regime the mechanism is meant for ----
        for nz in NOISE_LEVELS:
            al2, fs2, rp2, lab2, msk2, tc2 = gather(
                model, te, device, incidence, noise=nz, seed=a["seed"])
            t2 = rp2.argmax(dim=-1)
            f_t2, thr2 = score(al2, t2, lab2, msk2)
            best = None
            for m in (1.0, 0.5, 0.25, 0.0):
                sel = pick_cascade(rp2, fs2, m, K)
                f, _ = score(al2, sel, lab2, msk2, thr2)
                if best is None or f > best[1]:
                    best = (m, f, float((sel != t2).float().mean()))
            r["router_degradation"][f"noise{nz}"] = {
                "router_acc": float((t2 == tc2).float().mean()),
                "top1_f1": f_t2, "cascade_f1": best[1],
                "gain": best[1] - f_t2, "best_margin": best[0],
                "reroute_rate": best[2]}

        results.append(r)
        best_m = max(r["margin_sweep"].items(), key=lambda kv: kv[1]["f1"])
        print(f"  seed{r['seed']:>2} top1={f_top1:.4f} oracle={f_oracle:.4f} "
              f"fb_only={f_fb:.4f} (router_acc={r['router_acc']:.3f}, "
              f"fb_acc={r['feedback_acc']:.3f}) best={best_m[0]}"
              f" {best_m[1]['f1']:.4f} ({best_m[1]['gain_vs_top1']:+.4f})")

    out = ROOT / args.out
    json.dump({"runs": results}, open(out, "w"), indent=2)

    # ---- summary ----
    print("\n=== margin sweep (mean over seeds) ===")
    keys = results[0]["margin_sweep"].keys()
    for k in keys:
        g = np.mean([r["margin_sweep"][k]["gain_vs_top1"] for r in results])
        rr = np.mean([r["margin_sweep"][k]["reroute_rate"] for r in results])
        print(f"  {k:<12} gain={g:+.4f}  reroute={rr:.3f}")
    print(f"  feedback_only  F1={np.mean([r['feedback_only'] for r in results]):.4f} "
          f"(acc={np.mean([r['feedback_acc'] for r in results]):.3f}) "
          f"vs top1 {np.mean([r['top1'] for r in results]):.4f} "
          f"(acc={np.mean([r['router_acc'] for r in results]):.3f})")

    print("\n=== router degradation (mean over seeds) ===")
    print(f"  {'noise':>6} {'router_acc':>11} {'top1':>8} {'cascade':>8} {'gain':>8}")
    for nz in NOISE_LEVELS:
        k = f"noise{nz}"
        ra = np.mean([r["router_degradation"][k]["router_acc"] for r in results])
        t = np.mean([r["router_degradation"][k]["top1_f1"] for r in results])
        c = np.mean([r["router_degradation"][k]["cascade_f1"] for r in results])
        print(f"  {nz:>6} {ra:>11.3f} {t:>8.4f} {c:>8.4f} {c-t:>+8.4f}")
    print(f"\nWrote {out}")


if __name__ == "__main__":
    main()
