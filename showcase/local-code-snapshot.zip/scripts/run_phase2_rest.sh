#!/usr/bin/env bash
# Remaining Phase 2 compute, in priority order.
#   2.2  small-attack regime 3 -> 10 seeds, and the two replay-specific
#        components there, so Table VIII covers the same six as Table VII
#   2.4  recorded-attacker curve at delta/sigma = 2.35 and 3.53, and the
#        existing recorded points raised from 3 to 10 seeds
set -u
ROOT="/Users/ozanbabac5/wdn_thesis"; cd "$ROOT"; export PYTHONPATH=src
LOG="/tmp/wdn_pilot"; mkdir -p "$LOG"
B="--gnn_type GraphSAGE --hidden_dim 64 --router_hidden_dim 24 \
   --epochs 60 --batch_size 8 --lr 0.001"

run () {  # run <tag> <data> <seeds> <flags...>
  local tag="$1" data="$2" ns="$3"; shift 3
  for s in $(seq 1 "$ns"); do
    local t="${tag}_s${s}"; [ -f "$LOG/$t.done" ] && continue
    echo "[p2] $(date +%H:%M:%S) $t"
    PYTHONUNBUFFERED=1 python3 -u -m wdn.train_temporal_moe $B \
        --data_dir "$data" --seed "$s" "$@" > "$LOG/$t.log" 2>&1 \
        && touch "$LOG/$t.done"
  done
}

# --- 2.2: small-attack regime to ten seeds, all six components ---
D=data/staticsmall_modena
run ss_final      $D 10 --window_size 6 --norm_mode per_node
run ss_notopo     $D 10 --window_size 6 --norm_mode per_node --no_topology
run ss_notemporal $D 10 --window_size 1 --norm_mode per_node
run ss_nomixture  $D 10 --window_size 6 --norm_mode per_node --num_experts 1
run ss_globalnorm $D 10 --window_size 6 --norm_mode global
run ss_nopattern  $D 10 --window_size 6 --norm_mode per_node --no_pattern_features

# --- 2.2b: the same two replay components in the conventional regime are
# --- already done (Table VII); near threshold is handled by run_phase2_replaycomp.sh

# --- 2.4: recorded-attacker curve, ten seeds at every point ---
for amp in 000 006 012 018 025; do
  run snrB${amp} data/snrB_modena_${amp} 10 --window_size 6 --norm_mode per_node
done
echo "[p2] ALL DONE $(date +%H:%M:%S)"
