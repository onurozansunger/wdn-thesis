"""Lightweight provenance, calibration-barrier and disposable-cache guards.

All campaign paths and model identities below are temporary test doubles; no
real model, campaign corpus or original experiment output is read or changed.
"""
from __future__ import annotations

import importlib.util
import json
from pathlib import Path

import pytest


@pytest.fixture(scope="module")
def driver():
    path = Path(__file__).resolve().parents[1] / "thesis_v2/experiments/reference_factorial/experiment.py"
    spec = importlib.util.spec_from_file_location("reference_factorial_experiment_tested", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value))


@pytest.fixture
def isolated(driver, monkeypatch, tmp_path):
    monkeypatch.setattr(driver, "ROOT", tmp_path)
    monkeypatch.setattr(driver, "RUN", tmp_path / "runs/operational/reference_factorial_20261008")
    monkeypatch.setattr(driver, "ORIGINAL", tmp_path / "runs/operational/original")
    monkeypatch.setattr(driver, "E10", tmp_path / "retained_scores")
    save(driver.RUN / "protocol_frozen.json", {"design": "test-only"})
    digest = driver.sha(driver.RUN / "protocol_frozen.json")
    monkeypatch.setattr(driver, "require_protocol", lambda: digest)
    monkeypatch.setattr(driver, "model_files", lambda condition, network, seed: {
        f"models/{condition}/{network}/{seed}": "unchanged-model-hash"})
    return driver


def selection_record(driver, condition, network, seed):
    return {"condition": condition, "network": network, "model_seed": seed,
            "protocol_sha256": driver.sha(driver.RUN / "protocol_frozen.json"),
            "model_sha256": driver.model_files(condition, network, seed),
            "path_thresholds": {b: [1.] * len(driver.metrics.LAMBDAS) for b in driver.BRANCHES},
            "path_calibration": [{"_overall": {"clean_fpr": 0.}}
                                 for _ in driver.metrics.LAMBDAS],
            "selected": [{"cap": cap, "objective": objective, "lambda_index": 0,
                          "lambda": 0., "thresholds": {b: 1. for b in driver.BRANCHES},
                          "calibration": {"_overall": {"clean_fpr": 0.}}}
                         for cap in driver.metrics.CAPS for objective in driver.metrics.OBJECTIVES]}


def populate_calibrations(driver):
    paths = []
    for condition in driver.CONDITIONS:
        for network in driver.NETWORKS:
            for seed in driver.SEEDS:
                path = driver.seed_root(condition, network, seed) / "calibration_selection.json"
                save(path, selection_record(driver, condition, network, seed))
                paths.append(path)
    return paths


def test_existing_selection_cannot_skip_changed_fitted_model(isolated, monkeypatch):
    d = isolated
    path = d.seed_root("e0r0", "modena", 701) / "calibration_selection.json"
    save(path, selection_record(d, "e0r0", "modena", 701))
    monkeypatch.setattr(d, "model_files", lambda *args: {"new-model": "changed"})
    monkeypatch.setattr(d, "load_scores", lambda *args: pytest.fail("Must reject before scoring"))
    with pytest.raises(RuntimeError, match="provenance"):
        d.calibrate("e0r0", "modena", 701)


def test_evaluation_barrier_requires_every_condition_network_seed(isolated):
    d = isolated
    paths = populate_calibrations(d)
    assert len(paths) == 24
    paths[-1].unlink()
    with pytest.raises((RuntimeError, FileNotFoundError)):
        d.freeze_evaluation()
    assert not (d.RUN / "evaluation_frozen.json").exists()


def test_evaluation_barrier_records_all24_selection_and_model_identities(isolated):
    d = isolated
    paths = populate_calibrations(d)
    d.freeze_evaluation()
    value = d.read(d.RUN / "evaluation_frozen.json")
    assert value["expected_condition_model_fits"] == 24
    assert value["expected_evaluation_cells"] == 144
    assert value["calibration_selection_sha256"] == {d.relative(p): d.sha(p) for p in paths}
    assert len(value["model_sha256"]) == 24


@pytest.mark.parametrize("defect", ["missing_objective", "wrong_cap", "wrong_identity"])
def test_evaluation_barrier_rejects_policy_inconsistent_selection(isolated, defect):
    d = isolated
    path = populate_calibrations(d)[0]
    value = d.read(path)
    if defect == "missing_objective":
        value["selected"].pop()
    elif defect == "wrong_cap":
        value["selected"][0]["cap"] = .05
    else:
        value["condition"] = "e0r0"
    save(path, value)
    with pytest.raises((RuntimeError, ValueError), match="selection|identity|cap|objective|policy"):
        d.freeze_evaluation()
    assert not (d.RUN / "evaluation_frozen.json").exists()


@pytest.mark.parametrize("kind", ["original", "symlink_outside", "symlink_inside", "wrong_extension"])
def test_cleanup_refuses_original_or_symlink_or_non_npz(isolated, monkeypatch, kind):
    d = isolated
    populate_calibrations(d)
    original = d.ORIGINAL / "features/train.npz"
    original.parent.mkdir(parents=True, exist_ok=True)
    original.write_bytes(b"original must survive")
    if kind == "original":
        target = original
    elif kind.startswith("symlink"):
        target = d.RUN / "disposable.npz"
        destination = original
        if kind == "symlink_inside":
            destination = d.RUN / "retained_model.npz"
            destination.write_bytes(b"retain")
        target.symlink_to(destination)
    else:
        target = d.RUN / "model.joblib"
        target.write_bytes(b"retain")
    monkeypatch.setattr(d.pipeline, "disposable_training_caches", lambda *args: [target], raising=False)
    with pytest.raises(RuntimeError, match="unsafe|Refusing"):
        d.cleanup_training("e0r0", "modena")
    assert original.read_bytes() == b"original must survive"
    assert target.exists()


def test_cleanup_requires_all_model_hashes_to_match_calibration(isolated, monkeypatch):
    d = isolated
    populate_calibrations(d)
    target = d.RUN / "features_train.npz"
    target.write_bytes(b"disposable only after verified fits")
    monkeypatch.setattr(d.pipeline, "disposable_training_caches", lambda *args: [target], raising=False)
    monkeypatch.setattr(d, "model_files", lambda *args: {"model": "changed"})
    with pytest.raises(RuntimeError, match="verified"):
        d.cleanup_training("e0r0", "modena")
    assert target.exists()


def test_metrics_small_numerical_checks():
    path = Path(__file__).resolve().parents[1] / "thesis_v2/experiments/reference_factorial/metrics.py"
    spec = importlib.util.spec_from_file_location("reference_factorial_metrics_tested", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.self_check()
