#!/usr/bin/env bash
# Workshop study: four-attack threat model on Modena (no replay), 10 seeds
# per configuration.
#
#   final       the paper's model: per-node norm + direct expert supervision
#   noexpert    ablation: drop the direct per-expert supervision term
#   nopattern   ablation: drop the pattern-detection input features
#   globalnorm  ablation: one z-score for the whole network
#
# Everything else is held fixed. Logs go to /tmp/wdn_workshop.
set -u
ROOT="/Users/ozanbabac5/wdn_thesis"; cd "$ROOT"
export PYTHONPATH=src
LOG="/tmp/wdn_workshop"; mkdir -p "$LOG"

COMMON="--data_dir data/workshop_modena --gnn_type GraphSAGE \
  --hidden_dim 64 --router_hidden_dim 24 --window_size 6 \
  --epochs 60 --batch_size 8 --lr 0.001"

run () {   # run <tag> <extra-flags...>
    local tag="$1"; shift
    for s in $(seq 1 10); do
        echo "[$tag] $(date +%H:%M:%S) start seed$s"
        PYTHONUNBUFFERED=1 python3 -u -m wdn.train_temporal_moe $COMMON \
            --seed "$s" "$@" > "$LOG/${tag}_s${s}.log" 2>&1
        echo "[$tag] $(date +%H:%M:%S) done  seed$s"
    done
}

run final      --norm_mode per_node
run noexpert   --norm_mode per_node --lambda_expert 0.0
run nopattern  --norm_mode per_node --no_pattern_features
run globalnorm --norm_mode global

echo "[workshop] ALL DONE $(date +%H:%M:%S)"
