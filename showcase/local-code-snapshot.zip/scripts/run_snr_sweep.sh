#!/usr/bin/env bash
# How far does the signal have to move before a replayed reading becomes
# detectable at all? Same network, same model, same attacks: only the
# amplitude of the diurnal demand cycle changes, which sets
#     delta/sigma = |p(t) - p(t-k)| / observation noise.
#
# Two attacker models:
#   A  replays the clean simulated value (leaves the copy noise-free)
#   B  replays what the sensor actually reported, noise included -- the
#      attacker who taps the telemetry stream, and the honest threat model
set -u
ROOT="/Users/ozanbabac5/wdn_thesis"; cd "$ROOT"; export PYTHONPATH=src
LOG="/tmp/wdn_v2"; mkdir -p "$LOG"

sweep () {   # sweep <prefix> <n_seeds> <amplitude-tags...>
    local pre="$1" nseed="$2"; shift 2
    for amp in "$@"; do
        for s in $(seq 1 "$nseed"); do
            tag="${pre}${amp}_s${s}"
            [ -f "$LOG/${tag}.done" ] && continue
            echo "[$pre$amp] $(date +%H:%M:%S) start seed$s"
            PYTHONUNBUFFERED=1 python3 -u -m wdn.train_temporal_moe \
                --data_dir "data/${pre}_modena_${amp}" --gnn_type GraphSAGE \
                --hidden_dim 64 --router_hidden_dim 24 --window_size 6 \
                --epochs 60 --batch_size 8 --lr 0.001 --seed "$s" \
                --norm_mode per_node > "$LOG/${tag}.log" 2>&1 \
                && touch "$LOG/${tag}.done"
            echo "[$pre$amp] $(date +%H:%M:%S) done  seed$s"
        done
    done
}

sweep snr  5 003 006 012 025      # attacker A, the main curve
sweep snrB 3 000 006 025          # attacker B, the realistic threat model
echo "[snr] COMPLETE $(date +%H:%M:%S)"
