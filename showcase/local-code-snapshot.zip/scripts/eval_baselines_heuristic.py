"""Learning-free detectors, to answer "0.954 --- compared with what?".

Most of the attack families write values that are implausible either
against a sensor's neighbours or against its own recent history. Before
crediting a 377k-parameter graph network, we should know how far two
cheap, entirely learning-free rules get on exactly the same data, split
and metric. Nothing here is trained: each rule produces a score and a
single threshold is calibrated on validation, as for the main model.

  spatial     |p_i - mean(p_j : j in N(i), observed)| / sigma_spatial
              a node inconsistent with its own neighbourhood. This is the
              hydraulic-plausibility check an operator would write by hand.
  temporal    |p_i^(T) - mean_t(p_i^(t<T))| / std_t(p_i^(t<T))
              a reading inconsistent with the sensor's own recent history.
  combined    max of the two z-scores.
  massbalance |B q| at each node from the observed flows, propagated to
              the incident nodes -- the physics residual, using no
              pressure information at all.

Usage:
    python3 scripts/eval_baselines_heuristic.py --data_dir data/v2_modena
"""
from __future__ import annotations

import argparse
import json
import pickle
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import torch
from sklearn.metrics import f1_score, roc_auc_score

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from wdn.corruption import active_attack_classes, compact_id_map


def build_windows(snaps, corr, ids, window=6):
    """Windows of `window` consecutive snapshots within one scenario."""
    by_scen = defaultdict(list)
    for i, s in enumerate(snaps):
        if s.scenario_id in ids:
            by_scen[s.scenario_id].append(i)
    out = []
    for sid in sorted(by_scen):
        idx = sorted(by_scen[sid], key=lambda i: snaps[i].timestep)
        for a in range(len(idx) - window + 1):
            out.append(idx[a:a + window])
    return out


def neighbours(graph):
    """Adjacency as a list of neighbour index arrays."""
    N = graph.num_nodes
    adj = [[] for _ in range(N)]
    ei = graph.edge_index
    for j in range(ei.shape[1]):
        a, b = int(ei[0, j]), int(ei[1, j])
        adj[a].append(b)
        adj[b].append(a)
    return [np.array(sorted(set(a)), dtype=np.int64) for a in adj]


def scores_for(windows, snaps, corr, adj, incidence):
    """Compute every learning-free score on the last step of each window."""
    S = {k: [] for k in ("spatial", "temporal", "combined", "massbalance")}
    lab, msk, cls = [], [], []

    for w in windows:
        last = w[-1]
        c = corr[last]
        p = c.pressure_obs.numpy().astype(np.float64)
        m = c.pressure_mask.numpy() > 0

        # --- spatial: deviation from observed neighbours ---
        sp = np.zeros_like(p)
        for i in range(len(p)):
            nb = adj[i]
            if not m[i] or nb.size == 0:
                continue
            obs = nb[m[nb]]
            if obs.size == 0:
                continue
            sp[i] = abs(p[i] - p[obs].mean())

        # --- temporal: deviation from the sensor's own history ---
        hist = np.stack([corr[t].pressure_obs.numpy() for t in w[:-1]])
        hm = np.stack([corr[t].pressure_mask.numpy() > 0 for t in w[:-1]])
        cnt = hm.sum(0)
        mu = np.where(cnt > 0, (hist * hm).sum(0) / np.maximum(cnt, 1), p)
        var = np.where(cnt > 1,
                       (((hist - mu) ** 2) * hm).sum(0) / np.maximum(cnt - 1, 1),
                       1.0)
        tp = np.abs(p - mu) / np.sqrt(np.maximum(var, 1e-9))
        tp = np.where(m & (cnt > 0), tp, 0.0)

        # Standardise each score across the observed sensors of the window
        # so a single global threshold is meaningful.
        def z(x):
            o = x[m]
            if o.size < 2:
                return x
            return np.where(m, (x - o.mean()) / (o.std() + 1e-9), 0.0)

        zs, zt = z(sp), z(tp)

        # --- mass balance: |B q| at each node from observed flows ---
        q = corr[last].flow_obs.numpy().astype(np.float64)
        qm = corr[last].flow_mask.numpy() > 0
        resid = np.abs(incidence @ (q * qm))
        zb = z(np.where(m, resid, 0.0))

        S["spatial"].append(zs[m])
        S["temporal"].append(zt[m])
        S["combined"].append(np.maximum(zs, zt)[m])
        S["massbalance"].append(zb[m])
        lab.append(c.pressure_anomaly.numpy()[m])
        msk.append(m[m])
        cls.append(np.full(m.sum(), int(getattr(c, "attack_type_id", 0))))

    return ({k: np.concatenate(v) for k, v in S.items()},
            np.concatenate(lab), np.concatenate(cls))


def calibrate(score, label):
    qs = np.quantile(score, np.linspace(0.50, 0.999, 120))
    best = (0.0, -1.0)
    for t in qs:
        f = f1_score(label, (score > t).astype(int), zero_division=0)
        if f > best[1]:
            best = (float(t), f)
    return best


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data_dir", default="data/v2_modena")
    ap.add_argument("--window", type=int, default=6)
    ap.add_argument("--out", default=None)
    args = ap.parse_args()

    d = ROOT / args.data_dir
    snaps = pickle.load(open(d / "snapshots.pkl", "rb"))
    corr = pickle.load(open(d / "corrupted.pkl", "rb"))
    graph = pickle.load(open(d / "graph.pkl", "rb"))
    names = active_attack_classes(corr)
    idmap = compact_id_map(names)

    # Same scenario split as training (shuffled with seed 42).
    scen = sorted({s.scenario_id for s in snaps})
    rng = np.random.default_rng(42)
    sh = scen.copy(); rng.shuffle(sh)
    ntr, nva = int(len(sh) * 0.70), int(len(sh) * 0.15)
    va, te = set(sh[ntr:ntr + nva]), set(sh[ntr + nva:])

    adj = neighbours(graph)
    inc = graph.incidence_matrix.astype(np.float64)

    print(f"{args.data_dir}: {graph.num_nodes} nodes, classes={names}")
    res = {}
    Sv, yv, _ = scores_for(build_windows(snaps, corr, va, args.window),
                           snaps, corr, adj, inc)
    St, yt, ct = scores_for(build_windows(snaps, corr, te, args.window),
                            snaps, corr, adj, inc)

    for k in ("spatial", "temporal", "combined", "massbalance"):
        thr, vf1 = calibrate(Sv[k], yv)
        pred = (St[k] > thr).astype(int)
        entry = {
            "threshold": thr,
            "val_f1": vf1,
            "f1": float(f1_score(yt, pred, zero_division=0)),
            "auroc": float(roc_auc_score(yt, St[k])) if yt.max() > 0 else 0.5,
            "per_attack": {},
        }
        for cid, nm in enumerate(names):
            sel = ct == [k2 for k2, v in idmap.items() if v == cid][0]
            if sel.sum() == 0:
                continue
            pos = yt[sel] > 0.5
            entry["per_attack"][nm] = {
                "f1": float(f1_score(yt[sel], pred[sel], zero_division=0)),
                "fpr": float(pred[sel][~pos].mean()) if (~pos).sum() else 0.0,
                "n": int(sel.sum()),
            }
        res[k] = entry
        pa = "  ".join(f"{n}={v['f1']:.3f}"
                       for n, v in entry["per_attack"].items() if n != "clean")
        print(f"  {k:<12} F1={entry['f1']:.4f} AUROC={entry['auroc']:.4f}  {pa}")

    out = ROOT / (args.out or
                  f"runs/temporal_moe/baselines_heuristic_{Path(args.data_dir).name}.json")
    out.parent.mkdir(parents=True, exist_ok=True)
    json.dump({"data_dir": args.data_dir, "classes": names, "results": res},
              open(out, "w"), indent=2)
    print(f"Wrote {out}")


if __name__ == "__main__":
    main()
