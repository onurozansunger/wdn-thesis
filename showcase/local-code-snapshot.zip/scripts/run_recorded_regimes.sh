#!/usr/bin/env bash
# Rebuild the regime grid against the *recorded* attacker.
#
# The main tables were built on datasets whose replay copies the pre-noise
# simulated value -- the shortcut this paper argues inflates replay AUROC by
# ~0.3. Leaving the component conclusions on that footing contradicts the
# paper's own strongest finding, so every regime is repeated here on a twin
# dataset that differs only in the attacker model.
#
# Ordered by how much each row carries: near-threshold Modena first, because
# the component claims rest on it, then conventional, then small attacks,
# then the L-Town replication. If this is cut short, what finished is still
# the part that matters.
set -u
ROOT="/Users/ozanbabac5/wdn_thesis"; cd "$ROOT"; export PYTHONPATH=src
LOG="/tmp/wdn_rec"; mkdir -p "$LOG"
COMMON="--gnn_type GraphSAGE --hidden_dim 64 --router_hidden_dim 24 \
        --epochs 60 --batch_size 8 --lr 0.001 --norm_mode per_node"
for D in rec_hard_modena rec_modena rec_small_modena rec_hard_ltown; do
  for s in 1 2 3 4 5 6 7 8 9 10; do
    for cfg in final notopo notemporal nomixture; do
      tag="${D}_${cfg}_s${s}"; [ -f "$LOG/$tag.done" ] && continue
      case $cfg in
        final)      X="--window_size 6" ;;
        notopo)     X="--window_size 6 --no_topology" ;;
        notemporal) X="--window_size 1" ;;
        nomixture)  X="--window_size 6 --num_experts 1" ;;
      esac
      echo "[rec] $(date +%H:%M:%S) $tag"
      PYTHONUNBUFFERED=1 python3 -u -m wdn.train_temporal_moe \
          $COMMON --data_dir "data/$D" $X --seed $s \
          > "$LOG/$tag.log" 2>&1 && touch "$LOG/$tag.done"
    done
  done
  echo "[rec] ===== $D complete $(date +%H:%M:%S) ====="
done
echo "[rec] ALL DONE $(date +%H:%M:%S)"
