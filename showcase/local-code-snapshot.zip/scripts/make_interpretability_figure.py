"""A single alarm, traced end to end.

The paper claims the detector is auditable: that every flag can be traced
to the statistic that raised it and the expert that produced it. That is a
claim about output, so it needs to be shown on an actual decision rather
than asserted. This script picks one attacked sensor from the test split
and renders the whole chain:

  (a) what the sensor reported over the window, against what the model
      reconstructed from the rest of the network -- the residual that
      makes the reading suspicious;
  (b) the sensor's fingerprint statistics, each standardised against the
      clean sensors of the same window, so the reader sees *which* cue
      fired rather than an opaque score;
  (c) the arbitration: the router's ranking over experts, the label-free
      feedback score of each, and which one was kept.

Usage:
    python3 scripts/make_interpretability_figure.py --data_dir data/v2_modena
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))

from wdn.models.temporal_moe import (
    TemporalMixtureOfExpertsGNN, expert_feedback_scores,
)
from eval_workshop_routing import load_split, to_device

BLUE, ORANGE, GREEN, PURPLE = "#2563eb", "#ea580c", "#059669", "#7c3aed"
RED, MUTED, INK = "#dc2626", "#6b7280", "#1f2937"

plt.rcParams.update({
    "figure.facecolor": "white", "savefig.facecolor": "white",
    "font.family": "serif", "font.serif": ["Times New Roman", "DejaVu Serif"],
    "font.size": 7.5, "axes.labelsize": 7.5, "axes.titlesize": 8,
    "xtick.labelsize": 7, "ytick.labelsize": 7, "legend.fontsize": 7,
    "axes.grid": True, "grid.color": "#e8ebf0", "grid.linewidth": 0.6,
    "axes.axisbelow": True, "axes.spines.top": False,
    "axes.spines.right": False, "legend.frameon": False, "axes.linewidth": 0.7,
    "savefig.bbox": "tight", "savefig.pad_inches": 0.02,
})

FEATS = ["window\nstd", "log\nstd", "half-window\ndrift", "# step\nchanges",
         "lag-1\nautocorr", "diff-std", "noise\nratio"]


def fingerprints(p_seq):
    """The window statistics the anomaly head sees, per sensor.

    ``p_seq`` is (T, N). Mirrors the definitions in TemporalMultiTaskGNN.
    """
    std = p_seq.std(0)
    logstd = np.log(std + 1e-3)
    half = max(1, p_seq.shape[0] // 2)
    drift = np.abs(p_seq[half:].mean(0) - p_seq[:half].mean(0))
    d = np.diff(p_seq, axis=0)
    nchg = (np.abs(d) > 1e-4).sum(0).astype(float)
    c = p_seq - p_seq.mean(0, keepdims=True)
    ac = (c[1:] * c[:-1]).sum(0) / ((c * c).sum(0) + 1e-6)
    dstd = d.std(0)
    nr = d.var(0) / (p_seq.var(0) + 1e-6)
    return np.stack([std, logstd, drift, nchg, ac, dstd, nr])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data_dir", default="data/v2_modena")
    ap.add_argument("--target", default="stealthy",
                    help="attack class to illustrate")
    ap.add_argument("--out", default="thesis/workshop/figures/interpretability.pdf")
    args = ap.parse_args()

    device = torch.device("mps" if torch.backends.mps.is_available() else "cpu")

    run = None
    for d in sorted((ROOT / "runs" / "temporal_moe").glob("2026*")):
        apth = d / "args.json"
        if not (apth.exists() and (d / "best_model.pt").exists()):
            continue
        a = json.load(open(apth))
        if (a.get("data_dir") == args.data_dir and a.get("epochs") == 60
                and a.get("window_size") == 6 and a.get("num_experts", 0) > 1
                and a.get("norm_mode") == "per_node"
                and a.get("lambda_expert") == 0.5
                and not a.get("no_pattern_features")
                and not a.get("no_topology")):
            run, cfg = d, a
    if run is None:
        raise SystemExit("no finished checkpoint for " + args.data_dir)
    print("using", run.name)

    (tr, va, te, nrm), graph, names = load_split(
        ROOT / args.data_dir, cfg["window_size"], cfg["batch_size"],
        cfg["norm_mode"])
    sample = te.dataset[0]
    model = TemporalMixtureOfExpertsGNN(
        node_in_dim=sample["x_seq"][0].shape[1],
        edge_in_dim=sample["edge_attr"].shape[1],
        hidden_dim=cfg["hidden_dim"], num_experts=cfg["num_experts"],
        window_size=cfg["window_size"], gnn_type=cfg["gnn_type"],
        router_hidden_dim=cfg["router_hidden_dim"]).to(device)
    model.load_state_dict(torch.load(run / "best_model.pt", map_location=device))
    model.eval()
    thr = json.load(open(run / "test_results.json")).get("threshold", 0.5)
    incidence = torch.tensor(graph.incidence_matrix,
                             dtype=torch.float32).to(device)
    tgt = names.index(args.target)

    # Find a confidently detected attacked sensor of the target class.
    pick = None
    with torch.no_grad():
        for raw in te:
            if (raw["attack_type"] == tgt).sum() == 0:
                continue
            b = to_device(raw, device)
            out = model(
                x_seq=b["x_seq"], edge_index=b["edge_index"],
                edge_attr=b["edge_attr"],
                is_original_edge=b["is_original_edge"],
                batch_size=b["batch_size"], num_nodes_per_graph=b["num_nodes"],
                pressure_obs=b["pressure_obs"], flow_obs=b["flow_obs"],
                pressure_mask=b["pressure_mask"], flow_mask=b["flow_mask"])
            N = b["num_nodes"]
            score = torch.sigmoid(out["pressure_anomaly_logits"]).view(-1, N)
            anom = b["pressure_anomaly"].view(-1, N)
            msk = (b["pressure_mask"] > 0).view(-1, N)
            for g in (raw["attack_type"] == tgt).nonzero(as_tuple=True)[0].tolist():
                cand = ((anom[g] > 0.5) & msk[g] & (score[g] > thr))
                if cand.any():
                    s = int(cand.nonzero()[0])
                    pick = (raw, b, out, g, s)
                    break
            if pick:
                break
    if pick is None:
        raise SystemExit(f"no detected {args.target} sensor found")

    raw, b, out, g, s = pick
    N = b["num_nodes"]
    p_seq = torch.stack([t.view(-1, N, t.shape[-1])[g, :, -2]
                         for t in b["x_seq"]]).cpu().numpy()   # (T, N)
    msk = (b["pressure_mask"].view(-1, N)[g] > 0).cpu().numpy()
    anom = (b["pressure_anomaly"].view(-1, N)[g] > 0.5).cpu().numpy()
    recon = out["pressure_pred"].view(-1, N)[g].detach().cpu().numpy()
    score = torch.sigmoid(out["pressure_anomaly_logits"]).view(-1, N)[g]
    score = score.detach().cpu().numpy()

    fp = fingerprints(p_seq)                                   # (F, N)
    clean = msk & ~anom
    mu, sd = fp[:, clean].mean(1), fp[:, clean].std(1) + 1e-9
    z = (fp[:, s] - mu) / sd

    rprob = torch.softmax(out["router_logits"], -1)[g].detach().cpu().numpy()
    fb = expert_feedback_scores(out, b, incidence)[g].detach().cpu().numpy()
    chosen = int(rprob.argmax())

    # ---------------- figure ----------------
    fig, ax = plt.subplots(1, 3, figsize=(7.16, 1.85),
                           gridspec_kw={"width_ratios": [1.05, 1.15, 1.0],
                                        "wspace": 0.33})

    T = p_seq.shape[0]
    t = np.arange(T)
    a0 = ax[0]
    a0.plot(t, p_seq[:, s], "-o", ms=2.6, lw=1.3, color=RED,
            label="reported (attacked)")
    a0.axhline(recon[s], ls="--", lw=1.1, color=BLUE, label="reconstructed")
    ok = clean.nonzero()[0][:40]
    for j in ok[:25]:
        a0.plot(t, p_seq[:, j], "-", lw=0.4, color=MUTED, alpha=0.28, zorder=0)
    a0.set_xlabel("timestep in window"); a0.set_ylabel("normalised pressure")
    a0.set_title(f"(a) sensor {s}: reported vs reconstructed", fontsize=7.5)
    a0.legend(loc="best", fontsize=6.2)

    a1 = ax[1]
    cols = [RED if abs(v) > 2 else (ORANGE if abs(v) > 1 else MUTED) for v in z]
    a1.barh(np.arange(len(z)), z, color=cols, height=0.62)
    a1.axvline(0, color=INK, lw=0.7)
    for x in (-2, 2):
        a1.axvline(x, color=MUTED, lw=0.7, ls=":")
    a1.set_yticks(np.arange(len(z)))
    a1.set_yticklabels(FEATS, fontsize=6.2)
    a1.invert_yaxis()
    a1.set_xlabel("z-score vs clean sensors in the same window")
    a1.set_title("(b) which cue fired", fontsize=7.5)

    a2 = ax[2]
    K = len(rprob)
    xs = np.arange(K)
    a2.bar(xs - 0.2, rprob, 0.38, color=BLUE, label="router prob.")
    fbn = (fb - fb.min()) / (fb.max() - fb.min() + 1e-9)
    a2.bar(xs + 0.2, 1 - fbn, 0.38, color=PURPLE,
           label="feedback (higher=better)")
    a2.set_xticks(xs)
    a2.set_xticklabels([n[:4] for n in names], fontsize=6.2, rotation=30)
    a2.set_ylim(0, 1.12)
    a2.annotate("kept", xy=(chosen, 1.02), ha="center", fontsize=6.4,
                color=GREEN, fontweight="bold")
    a2.set_title("(c) which expert ran, and why", fontsize=7.5)
    a2.legend(loc="upper left", fontsize=6.0)

    outp = ROOT / args.out
    outp.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(outp)
    plt.close(fig)

    meta = {"run": run.name, "class": args.target, "sensor": int(s),
            "anomaly_score": float(score[s]), "threshold": float(thr),
            "top_cues": [FEATS[i].replace("\n", " ")
                         for i in np.argsort(-np.abs(z))[:3]],
            "z_top": [float(v) for v in np.sort(-np.abs(z))[:3] * -1],
            "chosen_expert": names[chosen],
            "router_prob": float(rprob[chosen])}
    json.dump(meta, open(outp.with_suffix(".json"), "w"), indent=2)
    print(json.dumps(meta, indent=2))
    print("wrote", outp)


if __name__ == "__main__":
    main()
