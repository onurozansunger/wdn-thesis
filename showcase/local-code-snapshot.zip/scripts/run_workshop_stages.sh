#!/usr/bin/env bash
# Development trajectory, 10 seeds per rung. Every rung uses the same data,
# the same scenario split, the same normalisation and the same optimiser —
# only the architecture changes, so the deltas are attributable.
#
#   s1_spatial    single model, one snapshot   (no temporal context, no MoE)
#   s2_temporal   single model, 6-step window  (+ GRU)
#
# The two upper rungs are produced by run_workshop_grid.sh:
#   s3 = "noexpert" (mixture, router-weighted only)
#   s4 = "final"    (+ direct per-expert supervision)
set -u
ROOT="/Users/ozanbabac5/wdn_thesis"; cd "$ROOT"
export PYTHONPATH=src
LOG="/tmp/wdn_workshop"; mkdir -p "$LOG"

COMMON="--data_dir data/workshop_modena --gnn_type GraphSAGE \
  --hidden_dim 64 --router_hidden_dim 24 \
  --epochs 60 --batch_size 8 --lr 0.001 --norm_mode per_node"

run () {   # run <tag> <extra-flags...>
    local tag="$1"; shift
    for s in $(seq 1 10); do
        echo "[$tag] $(date +%H:%M:%S) start seed$s"
        PYTHONUNBUFFERED=1 python3 -u -m wdn.train_temporal_moe $COMMON \
            --seed "$s" "$@" > "$LOG/${tag}_s${s}.log" 2>&1
        echo "[$tag] $(date +%H:%M:%S) done  seed$s"
    done
}

run s1_spatial  --num_experts 1 --window_size 1
run s2_temporal --num_experts 1 --window_size 6

echo "[stages] ALL DONE $(date +%H:%M:%S)"
