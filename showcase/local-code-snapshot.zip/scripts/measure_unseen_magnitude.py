"""How big are the unseen attacks, next to the trained ones?

The unseen-family result (F1 0.001--0.022) has been read as a
generalisation failure: the detector learned the generator and cannot see
a sixth family. That reading is only valid if the unseen attacks are of
comparable size to the trained ones. If they are much smaller, the low
scores say nothing about generalisation -- they say the perturbation is
below the detector's floor, which no architecture would fix.

This measures the shift each family puts on an attacked sensor, in the
only unit that makes the two comparable: the sd of the model's own clean
residual on that sensor. An attack worth k of those is a k-sigma
displacement against the detector's noise, whichever family it came from.

    python3 scripts/measure_unseen_magnitude.py --data_dir data/v2_modena
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))

from wdn.models.temporal_moe import TemporalMixtureOfExpertsGNN
from wdn.corruption import ID_TO_ATTACK_TYPE
from eval_workshop_routing import load_split, to_device
from eval_unseen_attacks import inject
from test_masked_residual import forward, gather, fit

COL_P, COL_M = 5, 6


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data_dir", default="data/v2_modena")
    ap.add_argument("--k", type=int, default=20)
    args = ap.parse_args()
    device = torch.device("mps" if torch.backends.mps.is_available() else "cpu")

    run = None
    for d in sorted((ROOT / "runs" / "temporal_moe").glob("2026*")):
        apth = d / "args.json"
        if not (apth.exists() and (d / "best_model.pt").exists()):
            continue
        a = json.load(open(apth))
        if (a.get("data_dir") == args.data_dir and a.get("epochs") == 60
                and a.get("window_size") == 6 and a.get("num_experts", 0) > 1
                and a.get("norm_mode") == "per_node"
                and a.get("lambda_expert") == 0.5
                and not a.get("no_pattern_features")
                and not a.get("no_topology")):
            run = (d, a)
    if run is None:
        raise SystemExit("no checkpoint for " + args.data_dir)
    d, a = run

    (tr, va, te, nm), graph, names = load_split(
        ROOT / args.data_dir, a["window_size"], a["batch_size"], a["norm_mode"])
    sample = te.dataset[0]
    n_nodes = graph.num_nodes
    model = TemporalMixtureOfExpertsGNN(
        node_in_dim=sample["x_seq"][0].shape[1],
        edge_in_dim=sample["edge_attr"].shape[1],
        hidden_dim=a["hidden_dim"], num_experts=a["num_experts"],
        window_size=a["window_size"], gnn_type=a["gnn_type"],
        router_hidden_dim=a["router_hidden_dim"]).to(device)
    model.load_state_dict(torch.load(d / "best_model.pt", map_location=device))
    model.eval()

    # per-sensor sd of the clean residual: the yardstick
    _, cP, _, cI, cY, _ = gather(model, va, device, 1, a["seed"], clean_only=True)
    ok = cY == 0
    _, sd = fit(cP[ok], cI[ok], n_nodes)
    print(f"  clean residual sd: median over sensors {np.median(sd):.3f} "
          f"(normalised units)\n")

    # --- trained families: shift = observed minus true, at attacked sensors ---
    rows = []
    shifts = {}
    with torch.no_grad():
        for raw in te:
            b = to_device(raw, device)
            m = (b["pressure_mask"] > 0).cpu()
            N = b["num_nodes"]
            nid = torch.arange(N).repeat(b["batch_size"])
            fam = b["attack_report"].cpu().repeat_interleave(N)
            lab = b["pressure_anomaly"].cpu()
            shift = (b["pressure_obs"].cpu() - b["y_pressure"].cpu()).abs()
            sel = m & (lab > 0)
            for kf in fam[sel].unique().tolist():
                s2 = sel & (fam == kf)
                shifts.setdefault(int(kf), []).append(
                    (shift[s2] / torch.from_numpy(sd[nid[s2]]).float()).numpy())

    for kf, v in sorted(shifts.items()):
        if kf == 0:
            continue
        v = np.concatenate(v)
        rows.append((f"trained: {ID_TO_ATTACK_TYPE.get(kf, kf)}",
                     len(v), np.median(v), np.mean(v)))

    # --- unseen families: shift = injected minus original, at injected sensors ---
    rng = np.random.default_rng(a["seed"])
    for kind in ("sinusoidal", "swap", "slowdrift"):
        vals = []
        for raw in te:
            keep = (raw["attack_type"] == 0).nonzero(as_tuple=True)[0]
            if keep.numel() == 0:
                continue
            N = raw["num_nodes"]
            sub = dict(raw)
            nidx = torch.cat([torch.arange(i * N, (i + 1) * N) for i in keep])
            sub["x_seq"] = [t[nidx] for t in raw["x_seq"]]
            for f in ("pressure_obs", "pressure_mask", "pressure_anomaly",
                      "y_pressure"):
                sub[f] = raw[f][nidx]
            sub["batch_size"] = int(keep.numel())
            before = sub["pressure_obs"].clone()
            inj = inject(sub, kind, args.k, rng)
            after = inj["pressure_obs"]
            m = (sub["pressure_mask"] > 0) & (inj["pressure_anomaly"] > 0)
            nid = torch.arange(N).repeat(sub["batch_size"])
            if m.sum() == 0:
                continue
            vals.append(((after - before)[m].abs()
                         / torch.from_numpy(sd[nid[m]]).float()).numpy())
        v = np.concatenate(vals)
        rows.append((f"UNSEEN: {kind}", len(v), np.median(v), np.mean(v)))

    print(f"  {'family':28s}{'n':>8}{'median shift':>15}{'mean shift':>13}")
    print("  " + "-" * 64)
    for nm_, n, med, mn in rows:
        print(f"  {nm_:28s}{n:>8}{med:>13.2f} sd{mn:>11.2f} sd")
    print("\n  shift is |reported - true| divided by that sensor's clean")
    print("  residual sd, so it is directly comparable across families.")


if __name__ == "__main__":
    main()
