#!/usr/bin/env bash
# The cell that separates the two explanations. Going from the
# conventional data to this one changes ONLY the attack magnitude
# (30 sigma -> 1 sigma) with the signal held static; going from here to
# data/hard_modena changes ONLY the signal dynamics. Whichever step
# revives a component is the condition that component needs.
set -u
ROOT="/Users/ozanbabac5/wdn_thesis"; cd "$ROOT"; export PYTHONPATH=src
LOG="/tmp/wdn_pilot"; mkdir -p "$LOG"
B="--data_dir data/staticsmall_modena --gnn_type GraphSAGE --hidden_dim 64 \
   --router_hidden_dim 24 --epochs 60 --batch_size 8 --lr 0.001 --norm_mode per_node"
for s in 1 2 3; do
  for c in final nomixture notemporal notopo; do
    tag="ss_${c}_s${s}"; [ -f "$LOG/$tag.done" ] && continue
    case $c in
      final)      X="--window_size 6" ;;
      nomixture)  X="--window_size 6 --num_experts 1" ;;
      notemporal) X="--window_size 1" ;;
      notopo)     X="--window_size 6 --no_topology" ;;
    esac
    echo "[ss] $(date +%H:%M:%S) $tag"
    PYTHONUNBUFFERED=1 python3 -u -m wdn.train_temporal_moe $B $X --seed $s \
        > "$LOG/$tag.log" 2>&1 && touch "$LOG/$tag.done"
  done
done
echo "[ss] ALL DONE $(date +%H:%M:%S)"
