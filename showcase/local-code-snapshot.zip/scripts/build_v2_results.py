"""Build every table, figure and macro for the v2 paper.

v2 differs from the submitted draft in four ways, and this script is the
single place where each is turned into paper-ready output:

  * the five-family threat model, with replay restored;
  * two topologies (Modena, L-Town) instead of one;
  * external baselines -- learning-free hydraulic rules and a
    topology-free model -- so the headline number has a reference point;
  * an honest account of the cascade, including the router-degradation
    curve that shows the regime where the feedback check pays.

Run after the training queue completes:
    python3 scripts/build_v2_results.py
"""
from __future__ import annotations

import json
import statistics as st
import yaml
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parent.parent
RUNS = ROOT / "runs" / "temporal_moe"
OUT = ROOT / "thesis" / "workshop"
FIG, TAB = OUT / "figures", OUT / "tables"
for d in (FIG, TAB):
    d.mkdir(parents=True, exist_ok=True)

NETS = {"data/v2_modena": "Modena", "data/v2_ltown": "L-Town"}
ATTACKS = ["random", "replay", "stealthy", "noise", "targeted"]
CLASSES = ["clean"] + ATTACKS
ALABEL = {c: c.capitalize() for c in CLASSES}

BLUE, ORANGE, GREEN, PURPLE = "#2563eb", "#ea580c", "#059669", "#7c3aed"
RED, CYAN, MUTED, INK = "#dc2626", "#0891b2", "#6b7280", "#1f2937"

plt.rcParams.update({
    "figure.facecolor": "white", "savefig.facecolor": "white",
    "axes.edgecolor": "#b9c0cc", "text.color": INK, "axes.labelcolor": INK,
    "xtick.color": "#4a5568", "ytick.color": "#4a5568",
    "font.family": "serif", "font.serif": ["Times New Roman", "DejaVu Serif"],
    "font.size": 8, "axes.labelsize": 8, "axes.titlesize": 8.5,
    "xtick.labelsize": 7.5, "ytick.labelsize": 7.5, "legend.fontsize": 7.5,
    "axes.grid": True, "axes.axisbelow": True, "grid.color": "#e8ebf0",
    "grid.linewidth": 0.6, "axes.spines.top": False,
    "axes.spines.right": False, "legend.frameon": False,
    "axes.linewidth": 0.7, "savefig.bbox": "tight", "savefig.pad_inches": 0.02,
})
COL, DCOL = 3.4, 7.16


# ---------------------------------------------------------------------------
# loading
# ---------------------------------------------------------------------------

def is_reported_run(a):
    """Does this run belong to the configuration the paper reports?

    Every table filters runs, and they used to do it independently, which
    is how a global-norm/no-pattern double ablation reached one table and
    a lambda_physics probe reached another. One predicate now guards the
    settings that are fixed across the whole paper; the per-table filters
    only choose which ablation a run is.
    """
    return a.get("epochs") == 60 and a.get("lambda_physics", 0.1) == 0.1


def config_of(a: dict) -> tuple[str, str] | None:
    """(network, configuration) a run belongs to, from its own arguments."""
    net = NETS.get(a.get("data_dir"))
    if net is None or not is_reported_run(a):
        return None
    if a.get("no_topology"):
        return net, "notopo"
    if a.get("num_experts") == 1:
        return (net, "nomixture") if a.get("window_size") == 6 else None
    if a.get("window_size") == 1:
        return net, "notemporal"
    # These two must be tested jointly. The run set contains a
    # global-norm *and* no-pattern double ablation, which is not a
    # configuration this paper reports; checking no_pattern_features
    # first silently labelled it "nopattern" and, because load_runs keys
    # by seed, it overwrote the real single-component runs. That put
    # +0.011 in Table V where the same ablation reads +0.006 in
    # Table VIII. Anything that removes both is dropped.
    npf, gnorm = bool(a.get("no_pattern_features")), a.get("norm_mode") == "global"
    if npf and gnorm:
        return None
    if npf:
        return net, "nopattern"
    if gnorm:
        return net, "globalnorm"
    if a.get("lambda_expert") == 0.0:
        return net, "noexpert"
    return net, "final"


def load_runs():
    g: dict[tuple[str, str], dict[int, dict]] = {}
    for d in sorted(RUNS.glob("2026*")):
        ap, tp = d / "args.json", d / "test_results.json"
        if not (ap.exists() and tp.exists()):
            continue
        a = json.load(open(ap))
        key = config_of(a)
        if key is None:
            continue
        r = json.load(open(tp))
        r["_args"], r["_dir"] = a, d
        g.setdefault(key, {})[a["seed"]] = r
    return {k: [v[s] for s in sorted(v)] for k, v in g.items()}


f1s = lambda rr: [r["anomaly_detection"]["pressure"]["f1"] for r in rr]


def agg(v):
    if not v:
        return {"mean": float("nan"), "std": float("nan"), "n": 0}
    return {"mean": st.mean(v),
            "std": st.stdev(v) if len(v) > 1 else 0.0, "n": len(v)}


def f1s_key(r):
    return r["anomaly_detection"]["pressure"]["f1"]


def paired_p(base, variant, metric):
    """Wilcoxon signed-rank between two configurations on shared seeds.

    Both configurations are trained on the same seed list, so the
    comparison is paired; an unpaired test here would throw away most of
    the power and is not what the design supports.
    """
    from scipy import stats as _st
    bs = {r["_args"]["seed"]: r for r in base if "_args" in r}
    vs = {r["_args"]["seed"]: r for r in variant if "_args" in r}
    common = sorted(set(bs) & set(vs))
    if len(common) < 6:
        return float("nan")
    x = np.array([metric(bs[k]) for k in common], dtype=float)
    y = np.array([metric(vs[k]) for k in common], dtype=float)
    if np.allclose(x, y) or np.isnan(x).any() or np.isnan(y).any():
        return float("nan")
    return float(_st.wilcoxon(x, y).pvalue)


def delta_cell(delta, pval, num, key):
    """Render one ablation delta, emphasised only if it survives Holm.

    The paper runs one leave-one-out test per component per regime, so
    the raw p-values come from a family and cannot each be read at 0.05.
    Bold therefore tracks the corrected result; the raw p is still
    printed so a reader can apply their own correction.
    """
    holm = num.get("holm", {})
    adj = holm.get(str(key))
    survives = adj is not None and adj == adj and adj < 0.05
    txt = f"$\\mathbf{{{delta:+.3f}}}$" if survives else f"${delta:+.3f}$"
    if pval == pval:
        txt += f"\\,\\tiny{{{pval:.3f}}}"
    num.setdefault("family", {})[str(key)] = pval
    return txt


def holm_adjust(num):
    """Holm-Bonferroni over the whole leave-one-out ablation family.

    Every component-level claim in the paper comes from one of these
    tests, so they form a single family and controlling only the
    per-test error rate would let roughly one in twenty pass by chance.
    Holm controls the family-wise rate while being uniformly more
    powerful than plain Bonferroni. Benjamini-Hochberg is recorded
    alongside it because the weaker effects survive that and not Holm,
    and the paper says so rather than picking whichever is flattering.
    """
    fam = {k: v for k, v in num.get("family", {}).items() if v == v}
    if not fam:
        return
    keys = sorted(fam, key=lambda k: fam[k])
    m = len(keys)
    holm, run = {}, 0.0
    for i, k in enumerate(keys):
        run = max(run, fam[k] * (m - i))
        holm[k] = min(run, 1.0)
    bh, run = {}, 1.0
    for i, k in enumerate(reversed(keys)):
        run = min(run, fam[k] * m / (m - i))
        bh[k] = min(run, 1.0)
    num["holm"], num["bh"], num["family_size"] = holm, bh, m


def pm(a):
    """Spread of an aggregate, suppressed when a single seed makes it 0."""
    return "" if a["n"] < 2 else f"\\pm{a['std']:.3f}"


def per_attack(rr, key="f1"):
    return {c: agg([r["per_attack_pressure"][c][key] for r in rr
                    if c in r.get("per_attack_pressure", {})])
            for c in CLASSES
            if any(c in r.get("per_attack_pressure", {}) for r in rr)}


def write_table(path, colspec, header, rows):
    body = [f"\\begin{{tabular}}{{{colspec}}}", "\\toprule",
            " & ".join(header) + " \\\\", "\\midrule"]
    body += [r.rstrip().rstrip("\\").rstrip() + " \\\\" for r in rows]
    body += ["\\bottomrule", "\\end{tabular}"]
    path.write_text("\n".join(body) + "\n")


# ---------------------------------------------------------------------------
# tables
# ---------------------------------------------------------------------------

REGIMES = [
    ("data/v2_modena",          "Conventional"),
    ("data/staticsmall_modena", "Small attacks"),
    ("data/hard_modena",        "Near threshold"),
    ("data/hard_ltown",         "Near threshold, L-Town"),
]
COMPONENTS = [("notopo", "message passing"), ("notemporal", "temporal recurrence"),
              ("nomixture", "expert mixture")]


_DSIG_CACHE = ROOT / "runs" / "delta_sigma.json"


def delta_sigma(data_dir):
    """Signal movement over a replay lag, in units of the sensor noise.

    This used to be a hard-coded column, computed as 19.67 x the config's
    demand-pattern amplitude. That constant is a property of Modena's
    hydraulics, not of the quantity: the same amplitude on L-Town moves
    the pressure about a tenth as far, so a config-derived label cannot be
    compared across networks -- and comparing across networks is the whole
    reason the column exists.

    Measured instead, directly from the ground-truth hydraulics: the RMS
    of p_true(t) - p_true(t-k) over the lag distribution the generator
    draws from (k in 3..6, never crossing a scenario boundary), divided by
    the sensor noise. Taking it from the signal rather than from the
    executed attack keeps the quantity independent of which attacker model
    a dataset was built with, so the same number describes the regime for
    both columns of the replay sweep.
    """
    cache = json.load(open(_DSIG_CACHE)) if _DSIG_CACHE.exists() else {}
    if data_dir in cache:
        return cache[data_dir]
    d = ROOT / data_dir
    if not (d / "corrupted.pkl").exists():
        return float("nan")
    import pickle
    cfg = yaml.safe_load(open(d / "generate_config.yaml"))
    sig = float(cfg["corruption"]["noise_sigma_pressure"])
    snaps = pickle.load(open(d / "snapshots.pkl", "rb"))
    by_scen: dict = {}
    for s in snaps:
        by_scen.setdefault(getattr(s, "scenario_id", 0), []).append(
            np.asarray(s.pressure_true, dtype=float))
    devs = []
    for series in by_scen.values():
        for k in (3, 4, 5, 6):
            for t in range(k, len(series)):
                devs.append((series[t] - series[t - k]) / sig)
    v = float(np.sqrt((np.concatenate(devs) ** 2).mean())) if devs else float("nan")
    cache[data_dir] = v
    _DSIG_CACHE.parent.mkdir(parents=True, exist_ok=True)
    json.dump(cache, open(_DSIG_CACHE, "w"), indent=1)
    return v


_ATK_CACHE = ROOT / "runs" / "attack_sigma.json"


def attack_sigma(data_dir):
    """Median displacement of an attacked sensor, in units of sensor noise.

    The companion to delta_sigma, and typed by hand for the same reason
    and with the same consequence: the regime table's attack column read
    "6--33" while the data gives a median of 16.9 and a per-class span of
    6.0 to 35.8, and the two-network comparison quoted 52 against 31 sigma
    where the measurement gives 20.1 against 16.9. Both were plausible
    when written and neither reproduces now.

    Reported as the median rather than a range because the span is
    dominated by two families at opposite extremes -- replay contributes
    almost nothing at steady state, noise injection tens of sigma -- so a
    range describes the threat model's spread rather than the regime.
    """
    cache = json.load(open(_ATK_CACHE)) if _ATK_CACHE.exists() else {}
    if data_dir in cache:
        return cache[data_dir]
    d = ROOT / data_dir
    if not (d / "corrupted.pkl").exists():
        return float("nan")
    import pickle
    cfg = yaml.safe_load(open(d / "generate_config.yaml"))
    sig = float(cfg["corruption"]["noise_sigma_pressure"])
    corrupted = pickle.load(open(d / "corrupted.pkl", "rb"))
    snaps = pickle.load(open(d / "snapshots.pkl", "rb"))
    mags = []
    for c, s in zip(corrupted, snaps):
        m = (np.asarray(c.pressure_anomaly).astype(bool)
             & np.asarray(c.pressure_mask).astype(bool))
        if m.any():
            mags.append(np.abs(np.asarray(c.pressure_obs)[m]
                               - np.asarray(s.pressure_true)[m]) / sig)
    v = float(np.median(np.concatenate(mags))) if mags else float("nan")
    cache[data_dir] = v
    _ATK_CACHE.parent.mkdir(parents=True, exist_ok=True)
    json.dump(cache, open(_ATK_CACHE, "w"), indent=1)
    return v


def regime_cfg(a):
    """Which ablation a run is, within a regime (regimes differ by data)."""
    if not is_reported_run(a):
        return None
    if a.get("no_topology"):
        return "notopo"
    if a.get("num_experts") == 1:
        return "nomixture" if a.get("window_size") == 6 else None
    if a.get("window_size") == 1:
        return "notemporal"
    if a.get("no_pattern_features") or a.get("norm_mode") == "global" \
            or a.get("lambda_expert") == 0.0:
        return None
    return "final"



# The paper's core: the same ablation under two regimes and two attacker
# models. Row 1 is the configuration this literature would normally run;
# each of the other rows changes exactly one coordinate.
CORE = [
    ("data/v2_modena",     "Conventional",   "pre-noise"),
    ("data/rec_modena",    "Conventional",   "recorded"),
    ("data/hard_modena",   "Near threshold", "pre-noise"),
    ("data/rec_hard_modena", "Near threshold", "recorded"),
]




def attack_overlap(num):
    """How often consecutive snapshots attack the same sensors.

    Quoted in Section IV to justify saying the recurrence cannot be
    tracking an attack episode, so it is measured rather than typed.
    """
    import pickle, collections
    d = ROOT / "data" / "v2_modena"
    c = pickle.load(open(d / "corrupted.pkl", "rb"))
    s = pickle.load(open(d / "snapshots.pkl", "rb"))
    by = collections.defaultdict(list)
    for cc, ss in zip(c, s):
        by[getattr(ss, "scenario_id", 0)].append(cc)
    ov = []
    for seq in by.values():
        for t in range(1, len(seq)):
            a = set(np.where(np.asarray(seq[t].pressure_anomaly).astype(bool))[0])
            b = set(np.where(np.asarray(seq[t - 1].pressure_anomaly).astype(bool))[0])
            if a and b:
                ov.append(len(a & b) / len(a))
    if ov:
        num["atk_overlap"] = float(np.mean(ov) * 100)


def physics_probe(num):
    """Paired comparison of the misspecified physics term against nothing.

    Reported as a macro so the sentence in Section IV tracks however many
    seeds have finished, rather than freezing an early three-seed result
    that happened to land on the low end of the spread.
    """
    from scipy import stats as _st
    def grab(lam):
        out = {}
        for d in sorted(RUNS.glob("2026*")):
            ap, tp = d / "args.json", d / "test_results.json"
            if not (ap.exists() and tp.exists()):
                continue
            a = json.load(open(ap))
            if a.get("data_dir") != "data/v2_modena" or a.get("epochs") != 60:
                continue
            if a.get("window_size") != 6 or a.get("no_topology"):
                continue
            if a.get("num_experts") != 6 or a.get("norm_mode") != "per_node":
                continue
            if a.get("no_pattern_features") or a.get("lambda_expert") != 0.5:
                continue
            if a.get("lambda_physics", 0.1) != lam:
                continue
            out[a["seed"]] = json.load(open(tp))["anomaly_detection"]["pressure"]["f1"]
        return out
    on, off = grab(0.1), grab(0.0)
    sh = sorted(set(on) & set(off))
    if len(sh) < 3:
        return
    x = np.array([on[s] for s in sh]); y = np.array([off[s] for s in sh])
    num["physics"] = {"with": float(x.mean()), "without": float(y.mean()),
                      "p": float(_st.wilcoxon(x, y).pvalue), "n": len(sh)}

    # Does dropping the term change any verdict? Rebuilt all four cells
    # without it; this records the largest disagreement so the paper can
    # state the robustness result rather than assert it.
    def abl(dd, lam):
        G = {}
        for d in sorted(RUNS.glob("2026*")):
            ap, tp = d / "args.json", d / "test_results.json"
            if not (ap.exists() and tp.exists()):
                continue
            a = json.load(open(ap))
            if a.get("data_dir") != dd or a.get("epochs") != 60:
                continue
            if a.get("lambda_physics", 0.1) != lam:
                continue
            if a.get("norm_mode") != "per_node" or a.get("no_pattern_features"):
                continue
            if a.get("lambda_expert") != 0.5:
                continue
            cfg = ("notopo" if a.get("no_topology") else
                   "notemporal" if a.get("window_size") == 1 else
                   "nomixture" if a.get("num_experts", 0) <= 1 else "final")
            G.setdefault(cfg, {})[a["seed"]] = json.load(open(tp))[
                "anomaly_detection"]["pressure"]["f1"]
        return G

    worst, cells, agree = 0.0, 0, 0
    for dd, _, _ in CORE:
        g1, g0 = abl(dd, 0.1), abl(dd, 0.0)
        b1, b0 = g1.get("final", {}), g0.get("final", {})
        if len(b1) < 10 or len(b0) < 10:
            continue
        cells += 1
        for k in ("notopo", "notemporal", "nomixture"):
            v1, v0 = g1.get(k, {}), g0.get(k, {})
            s1 = sorted(set(v1) & set(b1)); s0 = sorted(set(v0) & set(b0))
            if len(s1) < 10 or len(s0) < 10:
                continue
            d1 = np.mean([v1[x] for x in s1]) - np.mean([b1[x] for x in s1])
            d0 = np.mean([v0[x] for x in s0]) - np.mean([b0[x] for x in s0])
            p1 = _st.wilcoxon([v1[x] for x in s1], [b1[x] for x in s1]).pvalue
            p0 = _st.wilcoxon([v0[x] for x in s0], [b0[x] for x in s0]).pvalue
            worst = max(worst, abs(d1 - d0))
            agree += int((p1 < 0.05) == (p0 < 0.05))
    if cells:
        num["physics_abl"] = {"cells": cells, "worst": worst, "agree": agree}


def ltown_family(num):
    """Register the L-Town near-threshold ablations in the same family.

    The paper draws a conclusion from them ("the same two components, the
    same direction"), so leaving them out of the multiplicity correction
    while correcting the Modena tests would be arbitrary.
    """
    data = {}
    for d in sorted(RUNS.glob("2026*")):
        ap, tp = d / "args.json", d / "test_results.json"
        if not (ap.exists() and tp.exists()):
            continue
        a = json.load(open(ap))
        if a.get("data_dir") != "data/hard_ltown":
            continue
        c = regime_cfg(a)
        if not c:
            continue
        r = json.load(open(tp))
        r["_args"] = a
        data.setdefault(c, []).append(r)
    base = data.get("final")
    if not base:
        return
    b = agg(f1s(base))
    for key, _ in COMPONENTS:
        rr = data.get(key)
        if not rr:
            continue
        delta = agg(f1s(rr))["mean"] - b["mean"]
        pv = paired_p(base, rr, f1s_key)
        num.setdefault("family", {})[str(("L-Town near", key))] = pv
        num.setdefault("ltnear", {})[key] = {"delta": delta, "p": pv}


def tab_core(num):
    """Regime x attacker model, one leave-one-out ablation in each cell."""
    data = {}
    for d in sorted(RUNS.glob("2026*")):
        ap, tp = d / "args.json", d / "test_results.json"
        if not (ap.exists() and tp.exists()):
            continue
        a = json.load(open(ap))
        if a.get("data_dir") not in {r[0] for r in CORE}:
            continue
        c = regime_cfg(a)
        if not c:
            continue
        r = json.load(open(tp))
        r["_args"] = a
        data.setdefault((a["data_dir"], c), []).append(r)

    rep = lambda r: r.get("per_attack_pressure", {}).get("replay", {}).get("f1")
    rows, store = [], {}
    for dd, regime, atk in CORE:
        base = data.get((dd, "final"))
        if not base:
            continue
        b = agg(f1s(base))
        br = agg([rep(r) for r in base if rep(r) is not None])
        cells = []
        for key, _ in COMPONENTS:
            rr = data.get((dd, key))
            if not rr:
                cells.append("---")
                continue
            delta = agg(f1s(rr))["mean"] - b["mean"]
            pval = paired_p(base, rr, f1s_key)
            cells.append(delta_cell(delta, pval, num, (regime, atk, key)))
            store.setdefault(f"{regime}|{atk}", {})[key] = {
                "delta": delta, "p": pval}
        au = agg([r["anomaly_detection"]["pressure"]["auroc"] for r in base])
        fa = agg([r["per_attack_pressure"]["clean"]["fpr"] for r in base
                  if "clean" in r.get("per_attack_pressure", {})])
        store.setdefault(f"{regime}|{atk}", {})["auroc"] = au["mean"]
        store[f"{regime}|{atk}"]["fa"] = fa["mean"] * 100
        store.setdefault(f"{regime}|{atk}", {})["final"] = b["mean"]
        store[f"{regime}|{atk}"]["replay"] = br["mean"]
        store[f"{regime}|{atk}"]["n"] = b["n"]
        rows.append(
            f"{regime} & \\emph{{{atk}}} & "
            f"${b['mean']:.3f}{{\\scriptstyle\\pm{b['std']:.3f}}}$ & "
            f"${br['mean']:.3f}$ & " + " & ".join(cells))
    if rows:
        write_table(TAB / "core.tex", "@{}ll rr ccc@{}",
                    ["\\textbf{Regime}", "\\textbf{Replay built from}",
                     "\\textbf{F1}", "\\textbf{replay F1}",
                     "\\textbf{$-$graph}", "\\textbf{$-$GRU}",
                     "\\textbf{$-$MoE}"], rows)
    num["core"] = store




def tab_families(num):
    """Per-family F1 for the four core cells.

    This is the mechanism behind the headline result. At conventional
    settings four families sit near 1.0 and one near 0, with nothing in
    between, so an ablation has no headroom to resolve anything. Near the
    threshold the families spread out and it does. It also shows that
    changing the attacker model moves exactly one family while moving the
    whole-model verdict.
    """
    FAM = ["random", "targeted", "noise", "stealthy", "replay"]
    rows, store = [], {}
    for dd, regime, atk in CORE:
        acc = {c: [] for c in FAM}
        for d in sorted(RUNS.glob("2026*")):
            ap, tp = d / "args.json", d / "test_results.json"
            if not (ap.exists() and tp.exists()):
                continue
            a = json.load(open(ap))
            if a.get("data_dir") != dd or regime_cfg(a) != "final":
                continue
            pa = json.load(open(tp))["per_attack_pressure"]
            for c in FAM:
                if c in pa:
                    acc[c].append(pa[c]["f1"])
        if not acc["replay"]:
            continue
        cells = [f"${st.mean(acc[c]):.3f}$" for c in FAM]
        rows.append(f"{regime} & \\emph{{{atk}}} & " + " & ".join(cells))
        store[f"{regime}|{atk}"] = {c: st.mean(acc[c]) for c in FAM}
    if rows:
        write_table(TAB / "families.tex", "@{}ll ccccc@{}",
                    ["\\textbf{Regime}", "\\textbf{Replay from}"] +
                    [f"\\textbf{{{c.capitalize()}}}" for c in FAM], rows)
    num["families"] = store


def tab_regime(num):
    """The paper's central table: the same ablation across three regimes.

    Going from the conventional regime to 'small attacks' changes only the
    attack magnitude; going from there to 'near threshold' changes only the
    signal dynamics. Whichever step revives a component identifies the
    condition that component needs.
    """
    data = {}
    for d in sorted(RUNS.glob("2026*")):
        ap, tp = d / "args.json", d / "test_results.json"
        if not (ap.exists() and tp.exists()):
            continue
        a = json.load(open(ap))
        dd = a.get("data_dir")
        if dd not in {r[0] for r in REGIMES}:
            continue
        c = regime_cfg(a)
        if c:
            r = json.load(open(tp))
            r["_args"] = a
            data.setdefault((dd, c), []).append(r)

    rows, store = [], {}
    for dd, label in REGIMES:
        sig = f"{delta_sigma(dd):.2f}"
        atk = f"{attack_sigma(dd):.1f}"
        base = data.get((dd, "final"))
        if not base:
            continue
        b = agg(f1s(base))
        cells = []
        for key, _ in COMPONENTS:
            rr = data.get((dd, key))
            if not rr:
                cells.append("---")
                continue
            v = agg(f1s(rr))
            delta = v["mean"] - b["mean"]
            pval = paired_p(base, rr, f1s_key)
            cells.append(delta_cell(delta, pval, num, (label, key)))
            store.setdefault(label, {})[key] = delta
            store[label][key + "_p"] = pval
        au = agg([r["anomaly_detection"]["pressure"]["auroc"] for r in base])
        fa = agg([r["per_attack_pressure"]["clean"]["fpr"] for r in base
                  if "clean" in r.get("per_attack_pressure", {})])
        rows.append(f"{label} & {sig} & {atk} & "
                    f"${b['mean']:.3f}{{\\scriptstyle\\pm{b['std']:.3f}}}$ & "
                    f"${au['mean']:.3f}$ & ${fa['mean']*100:.2f}$ & "
                    f"{b['n']} & " + " & ".join(cells))
        store.setdefault(label, {})["auroc"] = au["mean"]
        store[label]["fa"] = fa["mean"] * 100
        store[label]["std"] = b["std"]
        store.setdefault(label, {})["final"] = b["mean"]
        store[label]["n_seeds"] = b["n"]

    if rows:
        write_table(TAB / "regime.tex", "@{}lcc rccc ccc@{}",
                    ["\\textbf{Regime}", "$\\delta/\\sigma$",
                     "\\textbf{atk}", "\\textbf{F1}", "\\textbf{AUROC}",
                     "\\textbf{FA\\%}", "$n$",
                     "\\textbf{$-$graph}", "\\textbf{$-$GRU}",
                     "\\textbf{$-$MoE}"], rows)
    num["regime"] = store


# delta/sigma is measured per dataset, not listed here: it used to be a
# typed column equal to 19.67 x the config's pattern amplitude, a constant
# that holds only for Modena's hydraulics.
SNR_SETS_RAW = [
    ("data/v2_modena", "A"), ("data/snr_modena_003", "A"),
    ("data/snr_modena_006", "A"), ("data/snr_modena_012", "A"),
    ("data/snr_modena_025", "A"),
    ("data/rec_modena", "B"), ("data/snrB_modena_006", "B"),
    ("data/snrB_modena_012", "B"), ("data/snrB_modena_018", "B"),
    ("data/snrB_modena_025", "B"),
]


def tab_snr(num):
    """Replay detectability against signal-to-noise, for both attacker models.

    Attacker A replays the clean simulated value, so the forgery arrives
    without observation noise; attacker B replays the recorded measurement,
    which is what an adversary tapping the telemetry actually has. The
    difference between the two columns at delta/sigma = 0 is the size of
    the evaluation artifact.
    """
    D = {}
    for d in sorted(RUNS.glob("2026*")):
        ap, tp = d / "args.json", d / "test_results.json"
        if not (ap.exists() and tp.exists()):
            continue
        a = json.load(open(ap))
        if not is_reported_run(a) or a.get("window_size") != 6:
            continue
        if a.get("no_topology") or a.get("num_experts", 0) <= 1:
            continue
        if a.get("norm_mode") != "per_node" or a.get("no_pattern_features"):
            continue
        if a.get("lambda_expert") != 0.5:
            continue
        D.setdefault(a.get("data_dir"), []).append(json.load(open(tp)))

    get = lambda r, k: r.get("per_attack_pressure", {}).get("replay", {}).get(k)
    by = {}
    SNR_SETS = [(dd, atk, round(delta_sigma(dd), 2))
                for dd, atk in SNR_SETS_RAW]
    for dd, atk, sg in SNR_SETS:
        rr = D.get(dd)
        if not rr:
            continue
        # Reconstruction error at this SNR. VI-F's explanation of the
        # non-monotone clean column rests on tau growing with the signal,
        # so it has to come from the runs and not from a note.
        tau = [r["reconstruction"]["pressure_all"]["mae"] for r in rr
               if "reconstruction" in r]
        if tau:
            num.setdefault("snr_tau", {})[f"{atk}_{sg}"] = st.mean(tau)
        raw = [get(r, "auroc") for r in rr if get(r, "auroc") is not None]
        f = agg([get(r, "f1") for r in rr if get(r, "f1") is not None])
        au = agg(raw)
        by[(atk, sg)] = (f, au)
        # Is the ranking better than chance at all? Paired against 0.5
        # rather than eyeballed, because the claim in VI-F rests on it.
        if len(raw) > 5:
            from scipy import stats
            num.setdefault("snr_chance_p", {})[f"{atk}_{sg}"] = float(
                stats.wilcoxon(np.array(raw) - 0.5).pvalue)

    rows = []
    for sg in sorted({s for _, _, s in SNR_SETS}):
        cells = []
        for atk in ("A", "B"):
            v = by.get((atk, sg))
            cells.append("--- & ---" if not v else
                         f"${v[0]['mean']:.3f}$ & "
                         f"${v[1]['mean']:.3f}{pm(v[1])}$")
        rows.append(f"${sg:.2f}$ & " + " & ".join(cells))
    if rows:
        body = ["\\begin{tabular}{@{}lcccc@{}}", "\\toprule",
                "& \\multicolumn{2}{c}{\\textbf{replay: pre-noise}}",
                "& \\multicolumn{2}{c}{\\textbf{replay: recorded}}\\\\",
                "\\cmidrule(lr){2-3}\\cmidrule(lr){4-5}",
                "$\\delta/\\sigma$ & \\textbf{F1} & \\textbf{AUROC} & "
                "\\textbf{F1} & \\textbf{AUROC} \\\\", "\\midrule"]
        body += [r.rstrip().rstrip("\\").rstrip() + " \\\\" for r in rows]
        body += ["\\bottomrule", "\\end{tabular}"]
        (TAB / "snr.tex").write_text("\n".join(body) + "\n")
    num["snr"] = {f"{a}_{s}": {"f1": v[0]["mean"], "auroc": v[1]["mean"]}
                  for (a, s), v in by.items()}
    # Seed count per attacker column, so the caption cannot go stale.
    for atk in ("A", "B"):
        ns = [v[1]["n"] for (a, _), v in by.items() if a == atk]
        if ns:
            num.setdefault("snr_n", {})[atk] = min(ns)


def paired_topology_test(G, num):
    """Paired test for the biggest claim: does message passing matter?

    The routing comparison is tested; the topology ablation was not, even
    though it is the largest effect in the paper and the seeds are paired.
    """
    from scipy import stats
    for net, dd in (("Modena", "data/v2_modena"), ("L-Town", "data/v2_ltown")):
        b, n = G.get((net, "final")), G.get((net, "notopo"))
        if not (b and n and len(b) == len(n)):
            continue
        x = np.array(f1s(b))
        y = np.array(f1s(n))
        p = float(stats.wilcoxon(x, y).pvalue)
        num.setdefault("topology_test", {})[net] = {
            "mean_diff": float((x - y).mean()), "wilcoxon_p": p, "n": len(x)}
        # Only L-Town joins the family here. Modena's topology test is the
        # same comparison as the Conventional/notopo cell of the regime
        # table, and counting it twice would inflate the family size.
        if net != "Modena":
            num.setdefault("family", {})[str((net, "notopo"))] = p


def tab_replaycomp(num):
    """The two replay-specific components, tested where replay is detectable.

    Section VI-D explains their failure at conventional settings by noting
    that replay is undetected there, so neither has anything to amplify.
    That is an assertion about a mechanism; running the same ablation in
    the near-threshold regime, where replay *is* detectable, tests it. The
    replay-slice delta is reported separately because that is where the
    mechanism is supposed to act.
    """
    def grab(dd, pred):
        out = []
        for d in sorted(RUNS.glob("2026*")):
            ap, tp = d / "args.json", d / "test_results.json"
            if not (ap.exists() and tp.exists()):
                continue
            a = json.load(open(ap))
            if a.get("data_dir") != dd or not is_reported_run(a):
                continue
            if a.get("window_size") != 6 or a.get("no_topology"):
                continue
            if a.get("num_experts", 0) <= 1:
                continue
            if pred(a):
                r = json.load(open(tp))
                r["_args"] = a          # paired tests need the seed
                out.append(r)
        return out

    full = lambda a: (a.get("norm_mode") == "per_node"
                      and not a.get("no_pattern_features")
                      and a.get("lambda_expert") == 0.5)
    gn = lambda a: a.get("norm_mode") == "global" and not a.get("no_pattern_features")
    npf = lambda a: a.get("norm_mode") == "per_node" and a.get("no_pattern_features")
    rep = lambda r: r.get("per_attack_pressure", {}).get("replay", {}).get("f1")

    rows, store = [], {}
    for dd, lbl in (("data/v2_modena", "Conventional"),
                    ("data/hard_modena", "Near threshold")):
        base = grab(dd, full)
        if not base:
            continue
        b, br = agg(f1s(base)), agg([rep(r) for r in base if rep(r) is not None])
        rows.append(f"\\emph{{{lbl}}} & ${b['mean']:.3f}$ & ${br['mean']:.3f}$ & & ")
        for pred, name in ((gn, "$-$ per-sensor normalisation"),
                           (npf, "$-$ pattern features")):
            rr = grab(dd, pred)
            if not rr:
                continue
            v = agg(f1s(rr))
            vr = agg([rep(r) for r in rr if rep(r) is not None])
            d, dr = v["mean"] - b["mean"], vr["mean"] - br["mean"]
            # These deltas used to be emphasised by magnitude alone, which
            # reads as significance without being it. Both metrics get the
            # same paired test as every other ablation, and the emphasis
            # now tracks the multiplicity-corrected result.
            pf = paired_p(base, rr, f1s_key)
            pr = paired_p(base, rr, rep)
            store.setdefault(lbl, {})[name] = {
                "d_f1": d, "d_replay": dr, "p_f1": pf, "p_replay": pr}
            kf, kr = (lbl, name, "F1"), (lbl, name, "replay F1")
            rows.append(f"\\quad {name} & ${v['mean']:.3f}$ & ${vr['mean']:.3f}$ & "
                        f"{delta_cell(d, pf, num, kf)} & "
                        f"{delta_cell(dr, pr, num, kr)}")
    if rows:
        write_table(TAB / "replaycomp.tex", "@{}lcccc@{}",
                    ["\\textbf{Configuration}", "\\textbf{F1}",
                     "\\textbf{replay F1}", "\\textbf{$\\Delta$F1}",
                     "\\textbf{$\\Delta$replay}"], rows)
    num["replaycomp"] = store


def tab_architecture(G, num):
    """Per-module parameter budget, introspected from the real model."""
    import sys as _s
    _s.path.insert(0, str(ROOT / "src"))
    from wdn.models.temporal_moe import TemporalMixtureOfExpertsGNN
    K = len(CLASSES)
    m = TemporalMixtureOfExpertsGNN(
        node_in_dim=7, edge_in_dim=8, hidden_dim=64, num_experts=K,
        router_hidden_dim=24, num_layers=2, num_temporal_layers=1,
        window_size=6, gnn_type="GraphSAGE", use_pattern_features=True)
    n = lambda mod: sum(p.numel() for p in mod.parameters())
    e = m.experts[0]
    rows = [f"\\textbf{{Expert}} (one of $K{{=}}{K}$) & & \\textbf{{{n(e):,}}}"]
    for label, out, mod in [
        ("Node encoder (linear $7\\!\\to\\!64$)", "$N\\times64$", e.node_encoder),
        ("GraphSAGE $\\times2$ (spatial)", "$N\\times64$", e.temporal_gnn.spatial),
        ("GRU, 1 layer (temporal)", "$N\\times64$", e.temporal_gnn.gru),
    ]:
        rows.append(f"\\quad {label} & {out} & {n(mod):,}")
    rows.append(f"\\quad Reconstruction heads & $N,\\,N_E$ & "
                f"{n(e.pressure_head) + n(e.flow_head):,}")
    rows.append(f"\\quad Anomaly heads & $N,\\,N_E$ & "
                f"{n(e.pressure_anomaly_head) + n(e.flow_anomaly_head):,}")
    rows.append(f"Experts, total ($\\times{K}$) & & {n(e)*K:,}")
    rows.append(f"Router (small GNN, width 24) & {K} logits & {n(m.router):,}")
    rows.append(f"\\textbf{{Full model}} & & \\textbf{{{n(m):,}}}")
    write_table(TAB / "arch_params.tex", "@{}lcr@{}",
                ["\\textbf{Component}", "\\textbf{Output}", "\\textbf{Params}"],
                rows)
    num["architecture"] = {"expert": n(e), "router": n(m.router),
                           "total": n(m), "K": K}


def tab_calibration(G, num):
    rr = G.get(("Modena", "final"))
    if not rr:
        return
    num["calibration"] = {
        "calibrated": agg(f1s(rr)),
        "uncalibrated": agg([r["uncalibrated"]["pressure_f1"] for r in rr
                             if r.get("uncalibrated")]),
        "threshold": agg([r["threshold"] for r in rr])}


def tab_per_attack(G, num):
    """Per-attack F1 on both networks."""
    rows = []
    for c in CLASSES:
        cells = []
        for net in ("Modena", "L-Town"):
            rr = G.get((net, "final"))
            if not rr:
                cells += ["---", "---"]
                continue
            pf, pr = per_attack(rr, "f1"), per_attack(rr, "fpr")
            if c == "clean":
                cells += ["---", f"${pr[c]['mean']*100:.2f}$"]
            else:
                cells += [f"${pf[c]['mean']:.3f}$", f"${pr[c]['mean']*100:.2f}$"]
        rows.append(f"{ALABEL[c]} & " + " & ".join(cells))
    body = ["\\begin{tabular}{@{}lcccc@{}}", "\\toprule",
            "& \\multicolumn{2}{c}{\\textbf{Modena}} & "
            "\\multicolumn{2}{c}{\\textbf{L-Town}}\\\\",
            "\\cmidrule(lr){2-3}\\cmidrule(lr){4-5}",
            "\\textbf{Class} & \\textbf{F1} & \\textbf{FA\\%} & "
            "\\textbf{F1} & \\textbf{FA\\%} \\\\", "\\midrule"]
    body += [r.rstrip().rstrip("\\").rstrip() + " \\\\" for r in rows]
    body += ["\\bottomrule", "\\end{tabular}"]
    (TAB / "per_attack.tex").write_text("\n".join(body) + "\n")
    for net in ("Modena", "L-Town"):
        if G.get((net, "final")):
            num.setdefault("per_attack", {})[net] = {
                "f1": per_attack(G[(net, "final")], "f1"),
                "fpr": per_attack(G[(net, "final")], "fpr")}


def tab_networks(G, num):
    """Headline numbers per topology, plus the baselines."""
    rows = []
    for net, dd in (("Modena", "data/v2_modena"), ("L-Town", "data/v2_ltown")):
        rr = G.get((net, "final"))
        if not rr:
            continue
        f, au = agg(f1s(rr)), agg([r["anomaly_detection"]["pressure"]["auroc"]
                                   for r in rr])
        mae = agg([r["reconstruction"]["pressure_unobs"]["mae"] for r in rr])
        nodes = {"Modena": 272, "L-Town": 785}[net]
        rows.append(f"{net} ({nodes} nodes) & ${f['mean']:.3f} \\pm "
                    f"{f['std']:.3f}$ & ${au['mean']:.3f}$ & ${mae['mean']:.3f}$")
        num.setdefault("net", {})[net] = {
            "f1": f, "auroc": au, "p_mae": mae, "n_seeds": len(rr)}
    write_table(TAB / "networks.tex", "@{}lccc@{}",
                ["\\textbf{Network}", "\\textbf{F1}", "\\textbf{AUROC}",
                 "\\textbf{P-MAE (m)}"], rows)


def tab_baselines(G, num):
    """Learning-free rules and a topology-free model vs the detector."""
    rows = []
    for net, dd in (("Modena", "v2_modena"), ("L-Town", "v2_ltown")):
        hp = RUNS / f"baselines_heuristic_{dd}.json"
        if not hp.exists() or not G.get((net, "final")):
            continue
        h = json.load(open(hp))["results"]
        full = agg(f1s(G[(net, "final")]))
        nt = G.get((net, "notopo"))
        cells = [
            ("Neighbour residual (no learning)", h["spatial"]["f1"], None),
            ("Temporal residual (no learning)", h["temporal"]["f1"], None),
            ("Both, combined (no learning)", h["combined"]["f1"], None),
            ("Mass-balance residual (no learning)", h["massbalance"]["f1"], None),
        ]
        if nt:
            a = agg(f1s(nt))
            cells.append(("Topology-free (same capacity)", a["mean"], a["std"]))
        cells.append(("\\textbf{This work}", full["mean"], full["std"]))
        rows.append(f"\\multicolumn{{2}}{{@{{}}l}}{{\\emph{{{net}}}}}")
        for name, m, s in cells:
            v = f"${m:.3f}$" if s is None else f"${m:.3f} \\pm {s:.3f}$"
            if name.startswith("\\textbf"):
                v = f"$\\mathbf{{{m:.3f}}}$"
            rows.append(f"\\quad {name} & {v}")
        num.setdefault("baselines", {})[net] = {
            k: h[k]["f1"] for k in h}
    write_table(TAB / "baselines.tex", "@{}lc@{}",
                ["\\textbf{Detector}", "\\textbf{F1}"], rows)


def tab_ablation(G, num):
    rows = []
    base = agg(f1s(G[("Modena", "final")]))
    rows.append(f"\\textbf{{Full model}} & $\\mathbf{{{base['mean']:.3f} \\pm "
                f"{base['std']:.3f}}}$ & ---")
    for label, key in [("$-$ temporal recurrence (GRU)", "notemporal"),
                       ("$-$ expert mixture (single net)", "nomixture"),
                       ("$-$ direct expert supervision", "noexpert"),
                       ("$-$ per-sensor normalisation", "globalnorm"),
                       ("$-$ pattern features", "nopattern"),
                       ("$-$ graph topology", "notopo")]:
        rr = G.get(("Modena", key))
        if not rr:
            continue
        v = agg(f1s(rr))
        d = v["mean"] - base["mean"]
        rows.append(f"{label} & ${v['mean']:.3f} \\pm {v['std']:.3f}$ & ${d:+.3f}$")
        num.setdefault("ablation", {})[key] = {**v, "delta": d}
    write_table(TAB / "ablation.tex", "@{}lcc@{}",
                ["\\textbf{Configuration}", "\\textbf{F1}", "\\textbf{$\\Delta$}"],
                rows)



def tab_setup(num):
    """Everything needed to regenerate the data, read from the configs.

    Requested in review: a five-page paper cannot defer the generator's
    parameters to a repository. Built from the config files rather than
    typed, for the same reason delta/sigma is measured rather than typed.
    """
    import itertools
    base = yaml.safe_load(open(ROOT / "configs" / "generate_v2_modena.yaml"))
    c = base["corruption"]
    # Steps per scenario is counted, not taken from duration_hours: a
    # 24-hour run at hourly resolution yields 25 snapshots, not 24.
    import pickle, collections
    snaps = pickle.load(open(ROOT / "data" / "v2_modena" / "snapshots.pkl", "rb"))
    per = collections.Counter(getattr(x, "scenario_id", 0) for x in snaps)
    nsc, nst = len(per), max(per.values())
    rows = [
        f"Scenarios $\\times$ steps & ${nsc}\\times{nst}$ hourly, "
        f"split $70/15/15$ by scenario",
        f"Window & $T{{=}}6$ snapshots; label and decision at the last step",
        f"Missing rate & ${c['missing_rate_pressure']:.2f}$ pressure, "
        f"${c['missing_rate_flow']:.2f}$ flow, redrawn i.i.d.\\ per snapshot",
        f"Sensor noise & $\\sigma_p={c['noise_sigma_pressure']}$~m; "
        f"$\\sigma_q={c['noise_sigma_flow']}$ (network units), which exceeds "
        f"the median link flow, so the flow channel is noise-dominated and "
        f"every result we report is on pressure",
        f"Demand & base $\\times\\,\\mathcal{{U}}(1\\pm"
        f"{base['demand_variation']})$ per scenario",
        f"Attacked fraction & ${c['attack_fraction']:.2f}$ of reporting "
        f"sensors, redrawn per snapshot",
        f"Attack draw & one family per snapshot, uniform over the five "
        f"plus a clean class",
        f"Replay lag & $k\\sim\\mathcal{{U}}\\{{3,\\dots,6\\}}$ "
        f"snapshots, never crossing a scenario",
        f"Normalisation & per-sensor, fitted on the training split only",
        f"Optimiser & Adam, lr $10^{{-3}}$, batch $8$, $60$ epochs",
    ]
    write_table(TAB / "setup.tex", "@{}lp{5.3cm}@{}",
                ["\\textbf{Setting}", "\\textbf{Value}"], rows)


def tab_unseen(num):
    rows = []
    for net, dd in (("Modena", "v2_modena"), ("L-Town", "v2_ltown")):
        p = RUNS / f"unseen_{dd}.json"
        if not p.exists():
            continue
        js = json.load(open(p))
        s = js["summary"]
        # Stated rather than rounded up: this table is 3 seeds, not 10.
        num.setdefault("unseen_n", {})[net] = len(js.get("runs", []))
        for kind, lbl in (("sinusoidal", "Sinusoidal injection"),
                          ("swap", "Sensor swap"),
                          ("slowdrift", "Slow drift (out of range)")):
            if kind in s:
                rows.append(f"{lbl} ({net}) & ${s[kind]['f1_mean']:.3f}$ & "
                            f"${s[kind]['auroc_mean']:.3f}$")
        num.setdefault("unseen", {})[net] = s
    if rows:
        write_table(TAB / "unseen.tex", "@{}lcc@{}",
                    ["\\textbf{Unseen attack family}", "\\textbf{F1}",
                     "\\textbf{AUROC}"], rows)


# ---------------------------------------------------------------------------
# figures
# ---------------------------------------------------------------------------

def fig_degradation(num):
    """Cascade gain over top-1 as the router degrades."""
    p = RUNS / "cascade_diagnosis.json"
    if not p.exists():
        return
    R = json.load(open(p))["runs"]
    keys = sorted(R[0]["router_degradation"],
                  key=lambda k: -float(k.replace("noise", "")))
    acc = [np.mean([r["router_degradation"][k]["router_acc"] for r in R])
           for k in keys]
    gain = [np.mean([r["router_degradation"][k]["gain"] for r in R])
            for k in keys]
    sd = [np.std([r["router_degradation"][k]["gain"] for r in R], ddof=1)
          for k in keys]

    fig, ax = plt.subplots(figsize=(COL, 1.95))
    ax.axhline(0, color=INK, lw=0.8)
    ax.errorbar(acc, gain, yerr=sd, fmt="-o", ms=3.2, lw=1.4, color=PURPLE,
                ecolor="#c3b6e8", capsize=2)
    ax.fill_between(acc, 0, gain, where=np.array(gain) > 0,
                    color=GREEN, alpha=0.14, interpolate=True)
    ax.fill_between(acc, 0, gain, where=np.array(gain) <= 0,
                    color=RED, alpha=0.10, interpolate=True)
    ax.set_xlabel("router accuracy")
    ax.set_ylabel("cascade $-$ top-1 (F1)")
    ax.invert_xaxis()
    idx = int(np.argmin(np.abs(np.array(gain))))
    ax.annotate(f"break-even\n$\\approx${acc[idx]:.2f}",
                xy=(acc[idx], 0), xytext=(acc[idx], max(gain) * 0.55),
                ha="center", fontsize=6.5, color=MUTED,
                arrowprops=dict(arrowstyle="-", lw=0.6, color=MUTED))
    fig.savefig(FIG / "degradation.pdf")
    plt.close(fig)
    num["degradation"] = {"router_acc": acc, "gain": gain}


def fig_routing(num):
    p = RUNS / "workshop_routing_v2.json"
    if not p.exists():
        return
    R = json.load(open(p))["runs"]
    order = [("soft", "Soft\nmixture"), ("router_top1", "Router\ntop-1"),
             ("cascade", "Cascade\n(feedback)"), ("oracle", "Oracle\n(ceiling)")]
    cols = [BLUE, MUTED, PURPLE, GREEN]
    m = [np.mean([r[k]["f1"] for r in R]) for k, _ in order]
    s = [np.std([r[k]["f1"] for r in R], ddof=1) for k, _ in order]
    fig, ax = plt.subplots(figsize=(COL, 1.95))
    ax.bar(np.arange(4), m, color=cols, width=0.6, yerr=s, capsize=2.5,
           error_kw=dict(ecolor="#7b8494", lw=0.8))
    for i, (mi, si) in enumerate(zip(m, s)):
        ax.text(i, mi + si + 0.004, f"{mi:.3f}", ha="center", va="bottom",
                fontsize=7, fontweight="bold")
    ax.set_xticks(range(4))
    ax.set_xticklabels([l for _, l in order], fontsize=7)
    ax.set_ylabel("Detection F1")
    ax.set_ylim(min(m) - 0.05, max(m) + max(s) + 0.03)
    fig.savefig(FIG / "routing.pdf")
    plt.close(fig)
    num["routing"] = {k: {"f1": mi, "std": si}
                      for (k, _), mi, si in zip(order, m, s)}


# ---------------------------------------------------------------------------

def write_macros(num):
    # Defined up front so a partially-complete grid still compiles and any
    # gap is visible in the PDF rather than breaking the build.
    m: dict[str, str] = {k: "??" for k in [
        "MdFone", "MdFoneStd", "MdAUROC", "MdPMAE", "MdCleanFPR",
        "LtFone", "LtFoneStd", "LtAUROC", "LtPMAE", "LtCleanFPR",
        "BaseSpatial", "BaseTemporal", "BaseCombined", "BaseMass",
        "BaseNoTopo", "AblTemporal", "AblMixture", "AblExpert", "AblNorm",
        "AblPattern", "AblTopo", "DelTemporal", "DelMixture", "DelExpert",
        "DelNorm", "DelPattern", "DelTopo",
        "RoutSoft", "RoutTopOne", "RoutCascade", "RoutOracle", "RoutGap",
        "PSoftCasc", "PCascTop", "POracleCasc", "FbAcc", "RouterAcc",
        "BreakEvenAcc", "MaxCascGain", "WorstRouterAcc",
        "UnseenSin", "UnseenSwap", "UnseenDrift",
        "UnseenAurocLo", "UnseenAurocHi", "UnseenFoneLo",
        "UnseenFoneHi", "UnseenBelow", "UnseenTotal", "UnseenSeeds",
        "SnrAzero", "SnrBzero", "SnrArtifact", "SnrBhigh",
        "SnrBloA", "SnrBloF", "SnrBhiA", "SnrBhiF", "SnrBzeroF",
        "SnrBloP", "SnrBhiP", "SnrSeedsA", "SnrSeedsB",
        "SnrBloX", "SnrBhiX", "SnrBhighX", "NearDS", "LtNearDS", "ConvDS",
        "MdAtk", "LtAtk", "ConvGRUP", "ConvMoEP",
        "FamCpEasyLo", "FamCpEasyHi", "FamCpReplay", "FamNpLo",
        "FamNpHi", "FamShiftMax", "FamShiftNear",
        "PhysWith", "PhysWithout", "PhysP", "PhysN", "PhysDiff", "AtkOverlap",
        "NoPhysCells", "NoPhysWorst", "NoPhysAgree",
        "CpAUROC", "CpFA", "CrAUROC", "CrFA", "NpAUROC", "NpFA", "NrAUROC", "NrFA",
        "CpGraphAbs", "CpGRUAbs", "CpMoEAbs", "CrGraphAbs", "CrGRUAbs", "CrMoEAbs", "NpGraphAbs", "NpGRUAbs", "NpMoEAbs", "NrGraphAbs", "NrGRUAbs", "NrMoEAbs",
        "CpGraphPct", "CpGRUPct", "CpMoEPct", "CrGraphPct", "CrGRUPct", "CrMoEPct", "NpGraphPct", "NpGRUPct", "NpMoEPct", "NrGraphPct", "NrGRUPct", "NrMoEPct",
        "CpFone", "CpRep", "CpGraph", "CpGraphP", "CpGraphQ", "CpGRU", "CpGRUP", "CpGRUQ", "CpMoE", "CpMoEP", "CpMoEQ", "CrFone", "CrRep", "CrGraph", "CrGraphP", "CrGraphQ", "CrGRU", "CrGRUP", "CrGRUQ", "CrMoE", "CrMoEP", "CrMoEQ", "NpFone", "NpRep", "NpGraph", "NpGraphP", "NpGraphQ", "NpGRU", "NpGRUP", "NpGRUQ", "NpMoE", "NpMoEP", "NpMoEQ", "NrFone", "NrRep", "NrGraph", "NrGraphP", "NrGraphQ", "NrGRU", "NrGRUP", "NrGRUQ", "NrMoE", "NrMoEP", "NrMoEQ",
        "LtNearFone", "LtNearTopo", "LtNearGRU", "LtNearMoE",
        "LtNearTopoQ", "LtNearGRUQ", "LtNearMoEQ",
        "SnrAlo", "SnrAhi", "TauLo", "TauHi",
        "FamilySize", 
        
        "MdAttReplay", "MdAttStealthy", "UnseenSinAUROC",
        "NearTopo", "NearGRU", "NearMoE", "NearFone",
        "SmallTopo", "SmallGRU", "SmallMoE", "SmallFone",
        "NearSeeds", "SmallSeeds", "NearAUROC", "NearFA",
        "RcNormF", "RcNormR", "RcPattF", "RcPattR",
        "SmallMoEP", "NearGRUP", "NearTopoP", "SmallTopoP", "NearMoEP",
        "PTopo", "CalGain", "CalUncal", "BaseBest",
        "FinalParams", "ExpertParams", "RouterParams", "NSeeds",
        "FinalFone", "FoneUncal", "ThrCal", "NumExperts",
    ]}

    def put(k, v, f="{:.3f}"):
        m[k] = f.format(v) if isinstance(v, float) else str(v)

    for net, mac in (("Modena", "Md"), ("L-Town", "Lt")):
        n = num.get("net", {}).get(net)
        if not n:
            continue
        put(f"{mac}Fone", n["f1"]["mean"]); put(f"{mac}FoneStd", n["f1"]["std"])
        put(f"{mac}AUROC", n["auroc"]["mean"]); put(f"{mac}PMAE", n["p_mae"]["mean"])
        put(f"{mac}Seeds", n["n_seeds"])
        pa = num.get("per_attack", {}).get(net, {})
        for c, v in pa.get("f1", {}).items():
            if c != "clean":
                put(f"{mac}Att{c.capitalize()}", v["mean"])
        if "clean" in pa.get("fpr", {}):
            put(f"{mac}CleanFPR", pa["fpr"]["clean"]["mean"] * 100, "{:.2f}")

    a = num.get("architecture")
    if a:
        put("FinalParams", f"{a['total']:,}")
        put("ExpertParams", f"{a['expert']:,}")
        put("RouterParams", f"{a['router']:,}")
        put("NumExperts", a["K"])
    c = num.get("calibration")
    if c:
        put("FinalFone", c["calibrated"]["mean"])
        put("NSeeds", c["calibrated"]["n"])
        if c["uncalibrated"]["n"]:
            put("FoneUncal", c["uncalibrated"]["mean"])
        put("ThrCal", c["threshold"]["mean"], "{:.2f}")

    bl = num.get("baselines", {}).get("Modena", {})
    for k, mac in (("spatial", "BaseSpatial"), ("temporal", "BaseTemporal"),
                   ("combined", "BaseCombined"), ("massbalance", "BaseMass")):
        if k in bl:
            put(mac, bl[k])
    nt = num.get("ablation", {}).get("notopo")
    if nt:
        put("BaseNoTopo", nt["mean"])

    abl = {"notemporal": "Temporal", "nomixture": "Mixture",
           "noexpert": "Expert", "globalnorm": "Norm",
           "nopattern": "Pattern", "notopo": "Topo"}
    for k, mac in abl.items():
        v = num.get("ablation", {}).get(k)
        if v:
            put("Abl" + mac, v["mean"]); put("Del" + mac, abs(v["delta"]))

    rn = {"soft": "Soft", "router_top1": "TopOne", "cascade": "Cascade",
          "oracle": "Oracle"}
    for k, v in num.get("routing", {}).items():
        put("Rout" + rn[k], v["f1"])
    if {"soft", "cascade"} <= set(num.get("routing", {})):
        put("RoutGap", num["routing"]["soft"]["f1"]
            - num["routing"]["cascade"]["f1"])

    t = num.get("tests", {})
    for key, mac in (("soft_vs_cascade", "PSoftCasc"),
                     ("cascade_vs_router_top1", "PCascTop"),
                     ("oracle_vs_cascade", "POracleCasc")):
        if key in t:
            put(mac, t[key]["wilcoxon_p"], "{:.3f}")

    diag = RUNS / "cascade_diagnosis_v2.json"
    if diag.exists():
        D = json.load(open(diag))["runs"]
        put("FbAcc", float(np.mean([r["feedback_acc"] for r in D])) * 100,
            "{:.1f}")
        put("RouterAcc", float(np.mean([r["router_acc"] for r in D])) * 100,
            "{:.1f}")

    d = num.get("degradation")
    if d:
        g = np.array(d["gain"]); a = np.array(d["router_acc"])
        put("BreakEvenAcc", float(a[int(np.argmin(np.abs(g)))]), "{:.2f}")
        put("MaxCascGain", float(g.max()))
        put("WorstRouterAcc", float(a.min()), "{:.2f}")

    # Range across every unseen family and both networks, so the prose
    # cannot claim "below chance everywhere" when two thirds of the grid
    # sits modestly above it.
    ua = [v["auroc_mean"] for net in num.get("unseen", {}).values()
          for v in net.values() if v.get("auroc_mean") == v.get("auroc_mean")]
    uf = [v["f1_mean"] for net in num.get("unseen", {}).values()
          for v in net.values() if v.get("f1_mean") == v.get("f1_mean")]
    un = num.get("unseen_n", {})
    if un:
        put("UnseenSeeds", min(un.values()), "{:.0f}")
    if ua:
        put("UnseenAurocLo", min(ua)); put("UnseenAurocHi", max(ua))
        put("UnseenFoneLo", min(uf)); put("UnseenFoneHi", max(uf))
        put("UnseenBelow", sum(1 for a in ua if a < 0.5), "{:.0f}")
        put("UnseenTotal", len(ua), "{:.0f}")
    for kind, mac in (("sinusoidal", "UnseenSin"), ("swap", "UnseenSwap"),
                      ("slowdrift", "UnseenDrift")):
        u = num.get("unseen", {}).get("Modena", {}).get(kind)
        if u:
            put(mac, u["f1_mean"]); put(mac + "AUROC", u["auroc_mean"])
    pa = num.get("per_attack", {}).get("Modena", {}).get("f1", {})
    for c, mac in (("replay", "MdAttReplay"), ("stealthy", "MdAttStealthy")):
        if c in pa:
            put(mac, pa[c]["mean"])

    # Holm-adjusted p for every claim the prose cites by name, so a
    # sentence can never quote a raw p that the correction has killed.
    holm = num.get("holm", {})
    put("FamilySize", num.get("family_size", float("nan")), "{:.0f}")

    # The regime coordinate of the two near-threshold datasets, measured.
    put("NearDS", delta_sigma("data/hard_modena"), "{:.2f}")
    put("LtNearDS", delta_sigma("data/hard_ltown"), "{:.2f}")
    put("ConvDS", delta_sigma("data/v2_modena"), "{:.2f}")
    put("MdAtk", attack_sigma("data/v2_modena"), "{:.1f}")
    put("LtAtk", attack_sigma("data/v2_ltown"), "{:.1f}")

    for k, mac in (("notopo", "LtNearTopo"), ("notemporal", "LtNearGRU"),
                   ("nomixture", "LtNearMoE")):
        v = num.get("ltnear", {}).get(k)
        if v:
            put(mac, abs(v["delta"]))
            q = holm.get(str(("L-Town near", k)))
            if q is not None:
                put(mac + "Q", q)

    # Core 2x2 cells, so every sentence in the results section is a macro.
    CK = {("Conventional", "pre-noise"): "Cp", ("Conventional", "recorded"): "Cr",
          ("Near threshold", "pre-noise"): "Np", ("Near threshold", "recorded"): "Nr"}
    CC = {"notopo": "Graph", "notemporal": "GRU", "nomixture": "MoE"}
    for (reg, atk), pre in CK.items():
        c = num.get("core", {}).get(f"{reg}|{atk}")
        if not c:
            continue
        put(pre + "Fone", c["final"]); put(pre + "Rep", c["replay"])
        put(pre + "AUROC", c["auroc"]); put(pre + "FA", c["fa"], "{:.2f}")
        for k, suf in CC.items():
            if k in c:
                put(pre + suf, c[k]["delta"]); put(pre + suf + "P", c[k]["p"])
                # relative size, so the prose never has to divide by hand
                put(pre + suf + "Pct", abs(c[k]["delta"]) / c["final"] * 100,
                    "{:.0f}")
                # unsigned, for sentences that carry the direction in a verb
                put(pre + suf + "Abs", abs(c[k]["delta"]))
                q = holm.get(str((reg, atk, k)))
                if q is not None:
                    put(pre + suf + "Q", q)

    fm = num.get("families", {})
    cp, cr = fm.get("Conventional|pre-noise"), fm.get("Conventional|recorded")
    npn = fm.get("Near threshold|pre-noise")
    if cp:
        put("FamCpEasyLo", min(cp[c] for c in ("random", "targeted", "noise", "stealthy")))
        put("FamCpEasyHi", max(cp[c] for c in ("random", "targeted", "noise", "stealthy")))
        put("FamCpReplay", cp["replay"])
    if npn:
        put("FamNpLo", min(npn.values())); put("FamNpHi", max(npn.values()))
    if cp and cr:
        put("FamShiftMax", max(abs(cp[c] - cr[c])
                               for c in ("random", "targeted", "noise", "stealthy")))
    nr = fm.get("Near threshold|recorded")
    if npn and nr:
        put("FamShiftNear", max(abs(npn[c] - nr[c])
                                for c in ("random", "targeted", "noise", "stealthy")))

    ph = num.get("physics")
    if ph:
        put("PhysWith", ph["with"]); put("PhysWithout", ph["without"])
        put("PhysP", ph["p"]); put("PhysN", ph["n"], "{:.0f}")
        put("PhysDiff", abs(ph["without"] - ph["with"]))
    pa = num.get("physics_abl")
    if pa:
        put("NoPhysCells", pa["cells"], "{:.0f}")
        put("NoPhysWorst", pa["worst"])
        put("NoPhysAgree", pa["agree"], "{:.0f}")
    if "atk_overlap" in num:
        put("AtkOverlap", num["atk_overlap"], "{:.0f}")

    sn = num.get("snr", {})
    if "A_0.0" in sn and "B_0.0" in sn:
        put("SnrAzero", sn["A_0.0"]["auroc"]); put("SnrBzero", sn["B_0.0"]["auroc"])
        put("SnrArtifact", sn["A_0.0"]["auroc"] - sn["B_0.0"]["auroc"])
    bkeys = sorted((float(k[2:]) for k in sn if k.startswith("B_")))
    akeys = sorted((float(k[2:]) for k in sn if k.startswith("A_")))
    if bkeys:
        put("SnrBhigh", sn[f"B_{bkeys[-1]}"]["auroc"])
        put("SnrBhighX", bkeys[-1], "{:.2f}")
    # The two measured points that bracket the transition from "ranks
    # slightly better than chance" to "usable as an alarm". Quoted as a
    # bracket, not interpolated: we only know what we measured.
    if "B_0.0" in sn:
        put("SnrBzeroF", sn["B_0.0"]["f1"])
    for sg, mac in (zip(bkeys[1:3], ("SnrBlo", "SnrBhi"))
                    if len(bkeys) > 2 else ()):
        k = f"B_{sg}"
        if k in sn:
            put(mac + "A", sn[k]["auroc"]); put(mac + "F", sn[k]["f1"])
            put(mac + "X", sg, "{:.2f}")
        if k in num.get("snr_chance_p", {}):
            put(mac + "P", num["snr_chance_p"][k])
    for sg, mac in ((akeys[2], "SnrAlo"), (akeys[-1], "SnrAhi")) if len(akeys) > 2 else ():
        if f"A_{sg}" in sn:
            put(mac, sn[f"A_{sg}"]["auroc"])
    tau = num.get("snr_tau", {})
    for sg, mac in ((akeys[0], "TauLo"), (akeys[-1], "TauHi")) if akeys else ():
        if f"A_{sg}" in tau:
            put(mac, tau[f"A_{sg}"])
    if "snr_n" in num:
        put("SnrSeedsA", num["snr_n"]["A"], "{:.0f}")
        put("SnrSeedsB", num["snr_n"]["B"], "{:.0f}")
    # Regime-specific deltas. The conventional-regime macros (DelTopo etc.)
    # must never be used in a sentence about another regime.
    rg = num.get("regime", {})
    lt = rg.get("Near threshold, L-Town")
    if lt:
        put("LtNearFone", lt["final"])
        for k, mac in (("notopo", "LtNearTopo"), ("notemporal", "LtNearGRU"),
                       ("nomixture", "LtNearMoE")):
            put(mac, abs(lt[k]))
            q = holm.get(str(("Near threshold, L-Town", k)))
            if q is not None:
                put(mac + "Q", q)
    conv = rg.get("Conventional")
    if conv:
        put("ConvGRUP", conv["notemporal_p"])
        put("ConvMoEP", conv["nomixture_p"])
    for lbl, pre in (("Near threshold", "Near"), ("Small attacks", "Small")):
        r = rg.get(lbl)
        if not r:
            continue
        put(pre + "Topo", abs(r["notopo"])); put(pre + "GRU", abs(r["notemporal"]))
        put(pre + "MoE", abs(r["nomixture"])); put(pre + "Fone", r["final"])
        if "auroc" in r: put(pre + "AUROC", r["auroc"])
        for k, mac in (("nomixture", "MoEP"), ("notemporal", "GRUP"), ("notopo", "TopoP")):
            if k + "_p" in r and r[k + "_p"] == r[k + "_p"]:
                put(pre + mac, r[k + "_p"], "{:.3f}")
        if "fa" in r: put(pre + "FA", r["fa"], "{:.2f}")
        put(pre + "Seeds", r["n_seeds"])

    rc = num.get("replaycomp", {}).get("Near threshold", {})
    for k, (a, b) in (("$-$ per-sensor normalisation", ("RcNormF", "RcNormR")),
                      ("$-$ pattern features", ("RcPattF", "RcPattR"))):
        if k in rc:
            put(a, abs(rc[k]["d_f1"])); put(b, abs(rc[k]["d_replay"]))
    pa2 = num.get("per_attack", {})
    tt = num.get("topology_test", {}).get("Modena")
    if tt:
        put("PTopo", tt["wilcoxon_p"], "{:.4f}")
    c = num.get("calibration")
    if c and c["uncalibrated"]["n"]:
        put("CalUncal", c["uncalibrated"]["mean"])
        put("CalGain", c["calibrated"]["mean"] - c["uncalibrated"]["mean"])
    bl = num.get("baselines", {}).get("Modena", {})
    if bl:
        put("BaseBest", max(bl.values()))

    lines = ["% Generated by scripts/build_v2_results.py — do not edit.",
             "% Every result quoted in the paper resolves through these macros."]
    lines += [f"\\newcommand{{\\{k}}}{{{v}}}" for k, v in sorted(m.items())]
    (TAB / "numbers.tex").write_text("\n".join(lines) + "\n")
    return m


def ensure_placeholders():
    """Emit stand-ins for artifacts whose runs have not finished.

    The paper \\inputs a fixed set of tables and figures; a missing file
    breaks the build entirely, which makes it impossible to check layout
    while experiments are still running. A visible "pending" stand-in keeps
    the document compiling and makes the gap obvious in the PDF.
    """
    for name, colspec, header in [
        ("networks", "@{}lccc@{}", ["\\textbf{Network}", "\\textbf{F1}",
                                    "\\textbf{AUROC}", "\\textbf{P-MAE (m)}"]),
        ("per_attack", "@{}lcccc@{}", ["\\textbf{Class}", "\\textbf{F1}",
                                       "\\textbf{FA\\%}", "\\textbf{F1}",
                                       "\\textbf{FA\\%}"]),
        ("baselines", "@{}lc@{}", ["\\textbf{Detector}", "\\textbf{F1}"]),
        ("ablation", "@{}lcc@{}", ["\\textbf{Configuration}", "\\textbf{F1}",
                                   "\\textbf{$\\Delta$}"]),
        ("unseen", "@{}lcc@{}", ["\\textbf{Unseen attack family}",
                                 "\\textbf{F1}", "\\textbf{AUROC}"]),
        ("snr", "@{}lcccc@{}", ["$\\delta/\\sigma$", "\\textbf{F1}",
                                 "\\textbf{AUROC}", "\\textbf{F1}",
                                 "\\textbf{AUROC}"]),
        ("regime", "@{}lccccccc@{}", ["\\textbf{Regime}", "$\\delta/\\sigma$",
                                      "\\textbf{atk}", "\\textbf{F1}",
                                      "\\textbf{$-$graph}", "\\textbf{$-$GRU}",
                                      "\\textbf{$-$MoE}"]),
    ]:
        p = TAB / f"{name}.tex"
        if not p.exists():
            n = len(header)
            write_table(p, colspec, header,
                        ["\\emph{pending}" + " & ---" * (n - 1)])

    for name in ("degradation", "routing", "interpretability"):
        p = FIG / f"{name}.pdf"
        if not p.exists():
            fig, ax = plt.subplots(figsize=(COL, 1.6))
            ax.text(0.5, 0.5, f"{name}\n(pending)", ha="center", va="center",
                    fontsize=9, color=MUTED)
            ax.set_axis_off()
            fig.savefig(p)
            plt.close(fig)


def main():
    G = load_runs()
    print("Runs found:")
    for k in sorted(G, key=str):
        print(f"  {k[0]:<8} {k[1]:<12} {len(G[k]):2d} seeds  "
              f"F1={agg(f1s(G[k]))['mean']:.4f}")
    if ("Modena", "final") not in G:
        raise SystemExit("Modena final configuration has no runs yet")

    num: dict = {}
    tp = RUNS / "workshop_routing_v2_tests.json"
    if tp.exists():
        num["tests"] = json.load(open(tp))

    # Two passes: the first collects every ablation p-value, the second
    # renders now that the family size is known and the correction can
    # decide what may be emphasised. Both are pure functions of the runs.
    tab_core(num)
    ltown_family(num)
    physics_probe(num)
    attack_overlap(num)
    holm_adjust(num)
    tab_core(num)
    tab_families(num)
    tab_regime(num)
    tab_replaycomp(num)
    paired_topology_test(G, num)
    tab_snr(num)
    tab_architecture(G, num)
    tab_calibration(G, num)
    tab_networks(G, num)
    tab_per_attack(G, num)
    tab_baselines(G, num)
    tab_ablation(G, num)
    tab_unseen(num)
    tab_setup(num)
    fig_degradation(num)
    fig_routing(num)
    ensure_placeholders()
    write_macros(num)
    json.dump(num, open(OUT / "numbers.json", "w"), indent=2, default=str)
    print(f"\nWrote tables -> {TAB}\n      figures -> {FIG}")


if __name__ == "__main__":
    main()
