#!/usr/bin/env bash
# Two jobs. First: finish characterising the physics term at ten seeds so
# the claim about it rests on a real test rather than three runs. Second:
# rebuild the core 2x2 without the term, since it is misspecified
# (||Bq||^2 with no demand vector) and cannot be defended as written.
set -u
ROOT="/Users/ozanbabac5/wdn_thesis"; cd "$ROOT"; export PYTHONPATH=src
LOG="/tmp/wdn_np"; mkdir -p "$LOG"
C="--gnn_type GraphSAGE --hidden_dim 64 --router_hidden_dim 24 --epochs 60 \
   --batch_size 8 --lr 0.001 --norm_mode per_node --lambda_physics 0"
# (1) seeds 4-10 of the probe, so the conventional 'final' cell has ten
for s in 4 5 6 7 8 9 10; do
  t="probe_s$s"; [ -f "$LOG/$t.done" ] && continue
  echo "[np] $(date +%H:%M:%S) $t"
  python3 -u -m wdn.train_temporal_moe $C --data_dir data/v2_modena --window_size 6 \
      --seed $s > "$LOG/$t.log" 2>&1 && touch "$LOG/$t.done"
done
echo "[np] ===== probe complete $(date +%H:%M:%S) ====="
# (2) the full 2x2 without the physics term
for D in v2_modena rec_modena hard_modena rec_hard_modena; do
  for s in 1 2 3 4 5 6 7 8 9 10; do
    for cfg in final notopo notemporal nomixture; do
      t="${D}_${cfg}_s${s}"; [ -f "$LOG/$t.done" ] && continue
      case $cfg in
        final)      X="--window_size 6" ;;
        notopo)     X="--window_size 6 --no_topology" ;;
        notemporal) X="--window_size 1" ;;
        nomixture)  X="--window_size 6 --num_experts 1" ;;
      esac
      echo "[np] $(date +%H:%M:%S) $t"
      python3 -u -m wdn.train_temporal_moe $C --data_dir "data/$D" $X --seed $s \
          > "$LOG/$t.log" 2>&1 && touch "$LOG/$t.done"
    done
  done
  echo "[np] ===== $D complete $(date +%H:%M:%S) ====="
done
echo "[np] ALL DONE $(date +%H:%M:%S)"
