#!/usr/bin/env bash
# The obvious follow-up to the ablation: drop BOTH components that fail to
# pay for themselves (per-sensor normalisation and the pattern features) and
# measure the result directly, rather than inferring it from two separate
# one-at-a-time ablations.
set -u
ROOT="/Users/ozanbabac5/wdn_thesis"; cd "$ROOT"; export PYTHONPATH=src
LOG="/tmp/wdn_v2"; mkdir -p "$LOG"
for s in $(seq 1 10); do
    [ -f "$LOG/md_lean_s${s}.done" ] && continue
    echo "[md_lean] $(date +%H:%M:%S) start seed$s"
    PYTHONUNBUFFERED=1 python3 -u -m wdn.train_temporal_moe \
        --data_dir data/v2_modena --gnn_type GraphSAGE --hidden_dim 64 \
        --router_hidden_dim 24 --window_size 6 --epochs 60 --batch_size 8 \
        --lr 0.001 --seed "$s" --norm_mode global --no_pattern_features \
        > "$LOG/md_lean_s${s}.log" 2>&1 && touch "$LOG/md_lean_s${s}.done"
    echo "[md_lean] $(date +%H:%M:%S) done  seed$s"
done
echo "[md_lean] COMPLETE $(date +%H:%M:%S)"
