"""One-time, lossless writing handoff. No experiments or results are rerun."""
from pathlib import Path
import hashlib
import json
import os
import shutil

ROOT = Path(__file__).resolve().parents[1]
ARCHIVE = ROOT / 'archive/2026-09-08-writing-handoff'


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def inventory(path):
    paths = [path] if path.is_file() or path.is_symlink() else sorted(path.rglob('*'))
    return [{
        'relative': '.' if p == path else str(p.relative_to(path)),
        **({'symlink': os.readlink(p)} if p.is_symlink() else
           {'sha256': digest(p), 'bytes': p.stat().st_size})
    } for p in paths if p.is_file() or p.is_symlink()]


def main():
    assert not ARCHIVE.exists(), 'Handoff already started; inspect its manifest instead of repeating.'
    ARCHIVE.mkdir(parents=True)
    records = []

    def save():
        (ARCHIVE / 'move_manifest.json').write_text(json.dumps({
            'status': 'in_progress', 'deleted_files': 0,
            'records': records,
            'protected_in_place': ['src', 'configs', 'data', 'runs', 'tests',
                                   'thesis_v2/experiments', 'thesis_v2/evidence',
                                   'thesis_v2/outputs', 'thesis_v2/manuscript'],
        }, indent=2) + '\n')

    def relocate(relative, link=False, backup=False):
        source = ROOT / relative
        if not source.exists():
            return
        assert not source.is_symlink(), relative
        target = ARCHIVE / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        assert not target.exists(), target
        before = inventory(source)
        records.append({'original': relative, 'archived': str(target.relative_to(ROOT)),
                        'action': 'backup_before_document_refresh' if backup else 'move',
                        'compatibility_link': link, 'files': before, 'verified': False})
        save()
        if backup:
            shutil.copy2(source, target)
        else:
            source.rename(target)
        assert inventory(target) == before, relative
        if link:
            source.symlink_to(os.path.relpath(target, source.parent), target_is_directory=target.is_dir())
            assert source.exists(), relative
        records[-1]['verified'] = True
        save()

    # Keep original paths for historical figure builders and document references.
    for relative in ['thesis', 'results_package', 'thesis_v2/presentation',
                     'thesis_v2/Supervisor_Email_Package_2026-09-03']:
        relocate(relative, link=True)
    for relative in ['results_package.zip', 'thesis_v2/Supervisor_Email_Package_2026-09-03.zip',
                     'tmp', '.codex_tmp', '.pytest_cache', 'temp.bin', 'temp.inp', 'temp.rpt']:
        relocate(relative)
    # Original documents are immutable historical records, including failed experiments.
    # Links retain exact original bytes and paths used by frozen protocols and reports.
    for source in sorted((ROOT / 'thesis_v2').glob('*.md')):
        relative = str(source.relative_to(ROOT))
        if source.name in {'README.md', 'STATUS.md', 'CLAIMS_LEDGER.md'}:
            relocate(relative, backup=True)
        else:
            relocate(relative, link=True)
    for relative in ['README.md', 'REPRODUCE.md']:
        relocate(relative, backup=True)
    record = json.loads((ARCHIVE / 'move_manifest.json').read_text())
    record['status'] = 'archive_verified'
    record['archived_bytes'] = sum(f.get('bytes', 0) for r in records for f in r['files'])
    record['archived_file_entries'] = sum(len(r['files']) for r in records)
    (ARCHIVE / 'move_manifest.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({k: v for k, v in record.items() if k != 'records'}, indent=2))


if __name__ == '__main__':
    main()
