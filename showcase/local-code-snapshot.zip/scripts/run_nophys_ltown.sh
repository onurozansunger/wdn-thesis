#!/usr/bin/env bash
# L-Town near threshold without the physics term.
#
# If the core table moves to physics-free runs, the L-Town replication has
# to move with it or the paper compares a physics-free Modena against a
# physics-trained L-Town. At the current four-worker rate this is under an
# hour, so there is no reason to leave that mismatch in.
#
# Waits for the Modena queue so the two do not contend.
set -u
ROOT="/Users/ozanbabac5/wdn_thesis"; cd "$ROOT"; export PYTHONPATH=src
export OMP_NUM_THREADS=3 MKL_NUM_THREADS=3
LOG="/tmp/wdn_np"; mkdir -p "$LOG"
while pgrep -f run_nophys_par.sh >/dev/null; do sleep 30; done
C="--gnn_type GraphSAGE --hidden_dim 64 --router_hidden_dim 24 --epochs 60 \
   --batch_size 8 --lr 0.001 --norm_mode per_node --lambda_physics 0"
job() {
  local cfg=$1 s=$2
  local t="hard_ltown_${cfg}_s${s}"; [ -f "$LOG/$t.done" ] && return
  local X
  case $cfg in
    final)      X="--window_size 6" ;;
    notopo)     X="--window_size 6 --no_topology" ;;
    notemporal) X="--window_size 1" ;;
    nomixture)  X="--window_size 6 --num_experts 1" ;;
  esac
  python3 -u -m wdn.train_temporal_moe $C --data_dir data/hard_ltown $X --seed $s \
      > "$LOG/$t.log" 2>&1 && touch "$LOG/$t.done"
}
export -f job; export LOG C ROOT
for cfg in final notopo notemporal nomixture; do
  for s in 1 2 3 4 5 6 7 8 9 10; do echo "$cfg $s"; done
done | xargs -P 4 -n 2 bash -c 'job "$0" "$1"'
echo "[lt] ALL DONE $(date +%H:%M:%S)"
